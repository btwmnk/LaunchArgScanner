using System;
using System.Buffers.Binary;
using System.Text;

namespace LaunchArgScanner.Core;

public static class StringExtractor
{
    private static bool IsPrintable(byte b) => b >= 0x20 && b < 0x7F;

    public static void Extract(byte[] data, int minLen, int maxLen, Action<string> sink, Func<bool>? cancelled = null)
    {
        ExtractAscii(data, minLen, maxLen, sink, cancelled);
        ExtractUtf16(data, minLen, maxLen, sink, cancelled);
    }

    private static void ExtractAscii(byte[] data, int minLen, int maxLen, Action<string> sink, Func<bool>? cancelled)
    {
        int n = data.Length;
        int start = -1;
        for (int i = 0; i <= n; i++)
        {
            bool p = i < n && IsPrintable(data[i]);
            if (p)
            {
                if (start < 0) start = i;
                continue;
            }
            if (start >= 0)
            {
                int len = i - start;
                if (len >= minLen && len <= maxLen)
                    sink(Encoding.ASCII.GetString(data, start, len));
                start = -1;
            }
            if ((i & 0xFFFFF) == 0 && cancelled?.Invoke() == true) return;
        }
    }

    private static void ExtractUtf16(byte[] data, int minLen, int maxLen, Action<string> sink, Func<bool>? cancelled)
    {
        int n = data.Length;
        var buf = new char[maxLen];
        int k = 0;
        int nextCheck = 0x100000;
        while (k < n - 1)
        {
            if (k >= nextCheck)
            {
                nextCheck += 0x100000;
                if (cancelled?.Invoke() == true) return;
            }

            if (IsPrintable(data[k]) && data[k + 1] == 0)
            {
                int j = k;
                int len = 0;
                while (j < n - 1 && IsPrintable(data[j]) && data[j + 1] == 0)
                {
                    if (len < maxLen) buf[len] = (char)data[j];
                    len++;
                    j += 2;
                }
                if (len >= minLen && len <= maxLen)
                    sink(new string(buf, 0, len));
                k = j;
            }
            else
            {
                k++;
            }
        }
    }

    public static bool ExtractIl2CppLiterals(byte[] data, int minLen, int maxLen, Action<string> sink)
    {
        if (data.Length < 64) return false;
        uint sanity = BinaryPrimitives.ReadUInt32LittleEndian(data);
        if (sanity != 0xFAB11BAF) return false;
        int version = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(4));
        if (version < 16 || version > 31) return false;

        int litOffset = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(8));
        int litSize = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(12));
        int dataOffset = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(16));
        int dataSize = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(20));

        if (litOffset <= 0 || litSize <= 0 || dataOffset <= 0 || dataSize <= 0) return false;
        if ((long)litOffset + litSize > data.Length || (long)dataOffset + dataSize > data.Length) return false;

        int count = litSize / 8;
        int bad = 0;
        for (int i = 0; i < count; i++)
        {
            int entry = litOffset + i * 8;
            uint length = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(entry));
            int index = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(entry + 4));
            if (index < 0 || (long)index + length > dataSize)
            {
                if (++bad > count / 10 + 10) return false;
                continue;
            }
            if (length < minLen || length > maxLen) continue;
            sink(Encoding.UTF8.GetString(data, dataOffset + index, (int)length));
        }
        return true;
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace LaunchArgScanner.Core;

public static partial class RuntimeCapture
{
    [GeneratedRegex(@"(?<![\w/\\.:-])(--?|\+)[A-Za-z][A-Za-z0-9_.\-]{1,40}=?")]
    private static partial Regex TokenRx();

    public sealed class Result
    {
        public bool Launched;
        public string? LogPath;
        public string? CommandLine;
        public List<string> Tokens = new();
        public List<string> UnknownOrErrors = new();
        public string? Excerpt;
        public string? Note;
    }

    public static Process? Launch(string exe, string args, EngineFamily family, out string effectiveArgs)
    {
        effectiveArgs = args ?? "";
        if (family == EngineFamily.Unreal && !effectiveArgs.Contains("-log", StringComparison.OrdinalIgnoreCase))
            effectiveArgs = (effectiveArgs + " -log").Trim();

        var psi = new ProcessStartInfo(exe, effectiveArgs)
        {
            WorkingDirectory = Path.GetDirectoryName(exe)!,
            UseShellExecute = true
        };
        return Process.Start(psi);
    }

    public static async Task<Result> ReadLogAsync(string root, string exe, EngineFamily family,
                                                  DateTime launchedAt, CancellationToken ct)
    {
        var res = new Result { Launched = true };
        string? log = null;

        for (int i = 0; i < 40 && !ct.IsCancellationRequested; i++)
        {
            log = FindLatestLog(root, exe, family, launchedAt);
            if (log != null) break;
            await Task.Delay(500, ct);
        }

        if (log == null)
        {
            res.Note = "Свежий лог не найден. Возможно, движок пишет лог в другое место или игра ещё не создала его.";
            return res;
        }

        res.LogPath = log;
        string text;
        try
        {

            using var fs = new FileStream(log, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var sr = new StreamReader(fs);
            text = await sr.ReadToEndAsync(ct);
        }
        catch (Exception ex)
        {
            res.Note = "Не удалось прочитать лог: " + ex.Message;
            return res;
        }

        Parse(text, res);
        return res;
    }

    private static void Parse(string text, Result res)
    {
        var lines = text.Split('\n');

        foreach (var raw in lines)
        {
            var line = raw.TrimEnd('\r');

            if (res.CommandLine == null &&
                (line.Contains("Command Line", StringComparison.OrdinalIgnoreCase) ||
                 line.Contains("CommandLine", StringComparison.OrdinalIgnoreCase) ||
                 line.Contains("Command-line", StringComparison.OrdinalIgnoreCase)))
            {
                int colon = line.IndexOf(':');
                res.CommandLine = colon >= 0 ? line[(colon + 1)..].Trim() : line.Trim();
            }

            if (line.Contains("unknown", StringComparison.OrdinalIgnoreCase) &&
                (line.Contains("command", StringComparison.OrdinalIgnoreCase) ||
                 line.Contains("switch", StringComparison.OrdinalIgnoreCase) ||
                 line.Contains("param", StringComparison.OrdinalIgnoreCase) ||
                 line.Contains("argument", StringComparison.OrdinalIgnoreCase)))
            {
                if (res.UnknownOrErrors.Count < 50) res.UnknownOrErrors.Add(line.Trim());
            }
        }

        var tokenSource = res.CommandLine ?? "";
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (Match m in TokenRx().Matches(tokenSource))
            set.Add(m.Value);
        res.Tokens = set.OrderBy(s => s, StringComparer.OrdinalIgnoreCase).ToList();

        var head = string.Join("\n", lines.Take(60).Select(l => l.TrimEnd('\r')));
        res.Excerpt = head.Length > 4000 ? head[..4000] + "\n…" : head;
    }

    private static string? FindLatestLog(string root, string exe, EngineFamily family, DateTime after)
    {
        var candidates = new List<string>();

        void AddFrom(string dir)
        {
            if (!Directory.Exists(dir)) return;
            try
            {
                candidates.AddRange(Directory.EnumerateFiles(dir, "*.log", SearchOption.AllDirectories));
                candidates.AddRange(Directory.EnumerateFiles(dir, "output_log*.txt", SearchOption.AllDirectories));
            }
            catch {  }
        }

        AddFrom(root);

        if (family == EngineFamily.Unity)
        {
            var lowRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "AppData", "LocalLow");
            AddFrom(lowRoot);
        }

        return candidates
            .Select(f => { try { return (f, new FileInfo(f).LastWriteTime); } catch { return (f, DateTime.MinValue); } })
            .Where(t => t.Item2 >= after.AddSeconds(-2))
            .OrderByDescending(t => t.Item2)
            .Select(t => t.f)
            .FirstOrDefault();
    }
}

using System;
using System.Buffers.Binary;
using System.Collections.Generic;

namespace LaunchArgScanner.Core;

public sealed class PeImage
{
    public readonly record struct Section(string Name, uint VirtualAddress, uint VirtualSize, uint RawPointer, uint RawSize, uint Characteristics)
    {
        public bool IsExecutable => (Characteristics & 0x20000000) != 0;
        public bool ContainsRva(uint rva) => rva >= VirtualAddress && rva < VirtualAddress + Math.Max(VirtualSize, RawSize);
    }

    public bool Is64Bit { get; private init; }
    public ulong ImageBase { get; private init; }
    public uint EntryPointRva { get; private init; }
    public uint TimeDateStamp { get; private init; }
    public uint ImportDirRva { get; private init; }
    public IReadOnlyList<Section> Sections { get; private init; } = Array.Empty<Section>();

    public DateTime? BuildDateUtc =>
        TimeDateStamp is > 0 and < 0xF0000000
            ? DateTimeOffset.FromUnixTimeSeconds(TimeDateStamp).UtcDateTime
            : null;

    private readonly byte[] _data;

    private PeImage(byte[] data) => _data = data;

    public static bool TryParse(byte[] data, out PeImage image)
    {
        image = null!;
        try
        {
            if (data.Length < 0x40) return false;
            if (data[0] != (byte)'M' || data[1] != (byte)'Z') return false;
            int e_lfanew = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(0x3C));
            if (e_lfanew <= 0 || e_lfanew + 0x18 > data.Length) return false;
            if (BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(e_lfanew)) != 0x00004550) return false;

            int coff = e_lfanew + 4;
            ushort machine = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(coff));
            ushort numSections = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(coff + 2));
            ushort optSize = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(coff + 16));
            int opt = coff + 20;
            if (opt + 2 > data.Length) return false;

            ushort magic = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(opt));
            bool is64 = magic == 0x20b;
            if (magic != 0x10b && magic != 0x20b) return false;

            uint entry = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(opt + 16));
            ulong imageBase = is64
                ? BinaryPrimitives.ReadUInt64LittleEndian(data.AsSpan(opt + 24))
                : BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(opt + 28));
            uint timeStamp = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(coff + 4));

            int dirBase = opt + (is64 ? 112 : 96);
            uint importRva = dirBase + 12 <= data.Length
                ? BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(dirBase + 8))
                : 0;

            int secTable = opt + optSize;
            var sections = new List<Section>(numSections);
            for (int i = 0; i < numSections; i++)
            {
                int s = secTable + i * 40;
                if (s + 40 > data.Length) break;
                var name = System.Text.Encoding.ASCII.GetString(data, s, 8).TrimEnd('\0');
                sections.Add(new Section(
                    name,
                    BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(s + 12)),
                    BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(s + 8)),
                    BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(s + 20)),
                    BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(s + 16)),
                    BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(s + 36))));
            }

            image = new PeImage(data)
            {
                Is64Bit = is64,
                ImageBase = imageBase,
                EntryPointRva = entry,
                TimeDateStamp = timeStamp,
                ImportDirRva = importRva,
                Sections = sections
            };
            _ = machine;
            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool TryRvaToOffset(uint rva, out int offset)
    {
        foreach (var s in Sections)
        {
            if (rva >= s.VirtualAddress && rva < s.VirtualAddress + Math.Max(s.VirtualSize, s.RawSize))
            {
                long o = (long)s.RawPointer + (rva - s.VirtualAddress);
                if (o >= 0 && o < _data.Length)
                {
                    offset = (int)o;
                    return true;
                }
            }
        }
        offset = 0;
        return false;
    }

    public bool TryVaToOffset(ulong va, out int offset)
    {
        offset = 0;
        if (va < ImageBase) return false;
        ulong rva = va - ImageBase;
        return rva <= uint.MaxValue && TryRvaToOffset((uint)rva, out offset);
    }

    public string? ReadStringAtVa(ulong va, int maxLen = 128)
    {
        if (!TryVaToOffset(va, out int off)) return null;
        return ReadStringAtOffset(off, maxLen);
    }

    public string? ReadStringAtOffset(int off, int maxLen = 128)
    {

        if (off + 1 < _data.Length && IsPrintable(_data[off]) && _data[off + 1] == 0)
        {
            int len = 0, p = off;
            var sb = new System.Text.StringBuilder();
            while (p + 1 < _data.Length && IsPrintable(_data[p]) && _data[p + 1] == 0 && len < maxLen)
            {
                sb.Append((char)_data[p]);
                p += 2;
                len++;
            }
            if (len >= 2) return sb.ToString();
        }

        if (off < _data.Length && IsPrintable(_data[off]))
        {
            int len = 0, p = off;
            var sb = new System.Text.StringBuilder();
            while (p < _data.Length && IsPrintable(_data[p]) && len < maxLen)
            {
                sb.Append((char)_data[p]);
                p++;
                len++;
            }
            if (len >= 2) return sb.ToString();
        }
        return null;
    }

    public List<string> ReadImportDllNames()
    {
        var names = new List<string>();
        if (ImportDirRva == 0 || !TryRvaToOffset(ImportDirRva, out int off)) return names;
        try
        {

            for (int i = 0; i < 4096; i++)
            {
                int entry = off + i * 20;
                if (entry + 20 > _data.Length) break;
                uint nameRva = BinaryPrimitives.ReadUInt32LittleEndian(_data.AsSpan(entry + 12));
                uint firstThunk = BinaryPrimitives.ReadUInt32LittleEndian(_data.AsSpan(entry + 16));
                if (nameRva == 0 && firstThunk == 0) break;
                if (nameRva == 0) continue;
                if (TryRvaToOffset(nameRva, out int nameOff))
                {
                    var s = ReadAsciiZ(nameOff, 64);
                    if (!string.IsNullOrEmpty(s)) names.Add(s);
                }
            }
        }
        catch {  }
        return names;
    }

    private string ReadAsciiZ(int off, int max)
    {
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < max && off + i < _data.Length; i++)
        {
            byte b = _data[off + i];
            if (b == 0) break;
            if (b < 0x20 || b >= 0x7F) return "";
            sb.Append((char)b);
        }
        return sb.ToString();
    }

    public byte[] RawSlice(int off, int len)
    {
        if (off < 0 || off >= _data.Length) return Array.Empty<byte>();
        int n = Math.Min(len, _data.Length - off);
        var b = new byte[n];
        Array.Copy(_data, off, b, 0, n);
        return b;
    }

    public ReadOnlySpan<byte> SectionBytes(Section s)
    {
        long start = s.RawPointer;
        long len = Math.Min(s.RawSize, (uint)Math.Max(0, _data.Length - start));
        if (start < 0 || start >= _data.Length || len <= 0) return ReadOnlySpan<byte>.Empty;
        return _data.AsSpan((int)start, (int)len);
    }

    private static bool IsPrintable(byte b) => b >= 0x20 && b < 0x7F;
}

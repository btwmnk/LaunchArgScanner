using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace LaunchArgScanner.Core;

public enum PakCompression { None, Zlib, Gzip, Oodle, LZ4, Zstd, Unknown }

public sealed class PakEntry
{
    public string Path = "";
    public long Offset;
    public long CompressedSize;
    public long UncompressedSize;
    public PakCompression Method;
    public bool Encrypted;
    public uint CompressionBlockSize;
    public int StructSize;
    public (long Start, long End)[] Blocks = Array.Empty<(long, long)>();

    public bool IsCompressed => Method != PakCompression.None && Blocks.Length > 0;
    public string Name => System.IO.Path.GetFileName(Path);
    public string Ext => System.IO.Path.GetExtension(Path).TrimStart('.');

    public string SizeText
    {
        get
        {
            double v = UncompressedSize; string[] u = { "Б", "КБ", "МБ", "ГБ" }; int i = 0;
            while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
            return $"{v:0.#} {u[i]}";
        }
    }
    public string MethodText => Method == PakCompression.None ? "—" : Method.ToString();
    public string EncText => Encrypted ? "🔒" : "";
    public bool CanExtract => Method is PakCompression.None or PakCompression.Zlib or PakCompression.Gzip;
}

public sealed class PakNode
{
    public string Name { get; set; } = "";
    public bool IsFolder { get; set; }
    public string FullDir { get; set; } = "";
    public PakEntry? Entry { get; set; }

    public string IconGlyph => IsFolder ? "" : "";
    public string SizeText => IsFolder ? "" : Entry?.SizeText ?? "";
    public string MethodText => IsFolder ? "" : Entry?.MethodText ?? "";
    public string EncText => IsFolder ? "" : Entry?.EncText ?? "";
}

public sealed class PakArchive
{
    private const uint Magic = 0x5A6F12E1;
    private const int FlatDirMagic = unchecked((int)0x49445046);

    public string FilePath { get; }
    public int Version { get; private set; }
    public bool EncryptedIndex { get; private set; }
    public long IndexOffset { get; private set; }
    public long IndexSize { get; private set; }
    public string MountPoint { get; private set; } = "";
    public List<PakEntry> Entries { get; } = new();
    private PakCompression[] _methods = { PakCompression.None };
    private readonly byte[]? _key;

    private PakArchive(string path, byte[]? key) { FilePath = path; _key = key; }

    public static PakArchive Open(string path, byte[]? key)
    {
        var pak = new PakArchive(path, key);
        pak.ReadFooter();
        pak.ReadIndex();
        return pak;
    }

    private void ReadFooter()
    {
        using var fs = File.OpenRead(FilePath);
        long len = fs.Length;
        int tail = (int)Math.Min(4096, len);
        var buf = new byte[tail];
        fs.Seek(-tail, SeekOrigin.End);
        fs.ReadExactly(buf, 0, tail);

        for (int p = tail - 4; p >= 17; p--)
        {
            if (BitConverter.ToUInt32(buf, p) != Magic) continue;
            if (p + 24 > tail) continue;
            int version = BitConverter.ToInt32(buf, p + 4);
            long idxOff = BitConverter.ToInt64(buf, p + 8);
            long idxSize = BitConverter.ToInt64(buf, p + 16);
            if (idxOff <= 0 || idxSize <= 0 || idxOff + idxSize > len) continue;

            Version = version;
            EncryptedIndex = buf[p - 1] != 0;
            IndexOffset = idxOff;
            IndexSize = idxSize;

            int namesStart = p + 44;
            if (version == 9) namesStart += 1;
            if (version >= 8)
            {
                var methods = new List<PakCompression> { PakCompression.None };
                for (int o = namesStart; o + 32 <= tail; o += 32)
                {
                    var name = Encoding.ASCII.GetString(buf, o, 32).TrimEnd('\0', ' ');
                    if (name.Length == 0) continue;
                    methods.Add(ParseMethod(name));
                }
                _methods = methods.ToArray();
            }
            else
            {
                _methods = new[] { PakCompression.None, PakCompression.Zlib, PakCompression.Gzip,
                                   PakCompression.Oodle, PakCompression.LZ4, PakCompression.Zstd };
            }
            return;
        }
        throw new InvalidDataException("Футер pak не найден (неподдерживаемая версия или не pak).");
    }

    private static PakCompression ParseMethod(string n) => n.ToLowerInvariant() switch
    {
        "zlib" => PakCompression.Zlib,
        "gzip" => PakCompression.Gzip,
        "oodle" => PakCompression.Oodle,
        "lz4" => PakCompression.LZ4,
        "zstd" => PakCompression.Zstd,
        _ => PakCompression.Unknown
    };

    private void ReadIndex()
    {
        byte[] index = ReadAndDecrypt(IndexOffset, (int)IndexSize, EncryptedIndex);
        var r = new BinReader(index);

        if (Version >= 10) ReadIndexUpdated(r);
        else ReadIndexLegacy(r);
    }

    private void ReadIndexLegacy(BinReader r)
    {
        MountPoint = ValidateMount(r.ReadFString());
        int count = r.ReadInt();
        if (count < 0 || count > 5_000_000) throw new InvalidDataException("Повреждённый индекс (неверный AES-ключ?).");
        for (int i = 0; i < count; i++)
        {
            var path = MountPoint + r.ReadFString();
            var e = ReadFullEntry(r, path);
            if (e != null) Entries.Add(e);
        }
    }

    private void ReadIndexUpdated(BinReader r)
    {
        MountPoint = ValidateMount(r.ReadFString());
        int fileCount = r.ReadInt();
        r.Skip(8);
        if (!r.ReadBool()) throw new InvalidDataException("Нет path hash index (неверный ключ?).");
        r.Skip(36);
        if (!r.ReadBool()) throw new InvalidDataException("Нет directory index.");
        long dirOffset = r.ReadLong();
        long dirSize = r.ReadLong();
        r.Skip(20);
        int encodedSize = r.ReadInt();
        if (encodedSize < 0 || encodedSize > 200_000_000) throw new InvalidDataException("Повреждённый индекс (неверный ключ?).");
        var encoded = r.ReadBytes(encodedSize);
        int filesNum = r.ReadInt();
        if (filesNum < 0 || filesNum > 5_000_000) throw new InvalidDataException("Повреждённый индекс.");
        var nonEncoded = new PakEntry[filesNum];
        for (int i = 0; i < filesNum; i++)
            nonEncoded[i] = ReadFullEntry(r, "") ?? new PakEntry();

        byte[] dirData = ReadAndDecrypt(dirOffset, (int)dirSize, EncryptedIndex);
        var encReader = new BinReader(encoded);

        if (dirData.Length >= 4 && BitConverter.ToInt32(dirData, 0) == FlatDirMagic)
        {
            ReadFlatDirectoryIndex(new BinReader(dirData), encReader, nonEncoded);
            return;
        }

        var d = new BinReader(dirData);
        int dirCount = d.ReadInt();
        for (int di = 0; di < dirCount; di++)
        {
            string dir = d.ReadFString();
            if (dir.StartsWith('/') && MountPoint.EndsWith('/')) dir = dir[1..];
            int fileEntries = d.ReadInt();
            for (int fi = 0; fi < fileEntries; fi++)
            {
                string fileName = d.ReadFString();
                int offset = d.ReadInt();
                if (offset == int.MinValue) continue;
                string path = MountPoint + dir + fileName;
                PakEntry? e = offset >= 0 ? DecodeEntry(encReader, offset, path) : null;
                if (e == null)
                {
                    int idx = -offset - 1;
                    if (idx < 0 || idx >= nonEncoded.Length) continue;
                    e = nonEncoded[idx];
                    e.Path = path;
                }
                Entries.Add(e);
            }
        }
    }

    private void ReadFlatDirectoryIndex(BinReader d, BinReader enc, PakEntry[] nonEncoded)
    {
        if (d.ReadInt() != FlatDirMagic) throw new InvalidDataException("Повреждённый плоский индекс.");
        int numDirs = d.ReadInt(), numFiles = d.ReadInt(), restart = d.ReadInt();
        int dirBlobBytes = d.ReadInt(), fileBlobBytes = d.ReadInt(), numPathHashes = d.ReadInt();
        d.Skip(4);
        if (numDirs < 0 || numFiles < 0 || restart <= 0 || dirBlobBytes < 0 || fileBlobBytes < 0 || numPathHashes < 0)
            throw new InvalidDataException("Повреждённый плоский индекс (неверный ключ?).");
        int numDirAnchors = (numDirs + restart - 1) / restart;
        d.Skip(numPathHashes * 8);
        d.Skip(numPathHashes * 4);
        d.Skip((numDirAnchors + 1) * 4);
        var dirFileStart = d.ReadIntArray(numDirs + 1);
        var fileNameOffsets = d.ReadIntArray(numFiles + 1);
        var fileLocations = d.ReadIntArray(numFiles);
        var dirBlob = d.ReadBytes(dirBlobBytes);
        var fileBlob = d.ReadBytes(fileBlobBytes);
        bool trimMountSep = MountPoint.Length > 0 && MountPoint[^1] == '/';
        int dirPos = 0;
        var nameBytes = new byte[256];
        for (int di = 0; di < numDirs; di++)
        {
            int sharedLen = BitConverter.ToInt32(dirBlob, dirPos); dirPos += 4;
            int suffixLen = BitConverter.ToInt32(dirBlob, dirPos); dirPos += 4;
            int nameLen = sharedLen + suffixLen;
            if (nameLen < 0 || sharedLen < 0 || suffixLen < 0) throw new InvalidDataException("Повреждённый плоский индекс.");
            if (nameBytes.Length < nameLen)
            {
                var g = new byte[Math.Max(nameLen, nameBytes.Length * 2)];
                Array.Copy(nameBytes, g, sharedLen);
                nameBytes = g;
            }
            Array.Copy(dirBlob, dirPos, nameBytes, sharedLen, suffixLen); dirPos += suffixLen;
            bool trimDir = trimMountSep && nameLen > 0 && nameBytes[0] == (byte)'/';
            string dir = Encoding.UTF8.GetString(nameBytes, trimDir ? 1 : 0, trimDir ? nameLen - 1 : nameLen);
            for (int global = dirFileStart[di]; global < dirFileStart[di + 1]; global++)
            {
                int location = fileLocations[global];
                if (location == int.MinValue) continue;
                int nameStart = fileNameOffsets[global];
                string fileName = Encoding.UTF8.GetString(fileBlob, nameStart, fileNameOffsets[global + 1] - nameStart);
                string path = MountPoint + dir + fileName;
                PakEntry? e = location >= 0 ? DecodeEntry(enc, location, path) : null;
                if (e == null)
                {
                    int idx = -location - 1;
                    if (idx < 0 || idx >= nonEncoded.Length) continue;
                    e = nonEncoded[idx];
                    e.Path = path;
                }
                Entries.Add(e);
            }
        }
    }

    private PakEntry? ReadFullEntry(BinReader r, string path)
    {
        var e = new PakEntry { Path = path };
        long start = r.Pos;
        e.Offset = r.ReadLong();
        e.CompressedSize = r.ReadLong();
        e.UncompressedSize = r.ReadLong();
        int methodIndex = Version == 8 ? r.ReadByte() : r.ReadInt();
        e.Method = methodIndex >= 0 && methodIndex < _methods.Length ? _methods[methodIndex] : PakCompression.Unknown;
        r.Skip(20);
        if (Version >= 3)
        {
            if (e.Method != PakCompression.None)
            {
                int blocks = r.ReadInt();
                if (blocks < 0 || blocks > 1_000_000) return null;
                e.Blocks = new (long, long)[blocks];
                for (int i = 0; i < blocks; i++) e.Blocks[i] = (r.ReadLong(), r.ReadLong());
            }
            e.Encrypted = (r.ReadByte() & 1) != 0;
            e.CompressionBlockSize = r.ReadUInt();
        }
        e.StructSize = (int)(r.Pos - start);
        if (Version >= 5)
            for (int i = 0; i < e.Blocks.Length; i++)
                e.Blocks[i] = (e.Blocks[i].Start + e.Offset, e.Blocks[i].End + e.Offset);
        return e;
    }

    private PakEntry DecodeEntry(BinReader enc, int offset, string path)
    {
        enc.Pos = offset;
        uint bitfield = enc.ReadUInt();
        uint compressionBlockSize = (bitfield & 0x3f) == 0x3f ? enc.ReadUInt() : (bitfield & 0x3f) << 11;
        int methodIndex = (int)((bitfield >> 23) & 0x3f);
        var method = methodIndex >= 0 && methodIndex < _methods.Length ? _methods[methodIndex] : PakCompression.Unknown;

        bool off32 = (bitfield & (1u << 31)) != 0;
        bool unc32 = (bitfield & (1u << 30)) != 0;
        long entryOffset = off32 ? enc.ReadUInt() : enc.ReadLong();
        long uncompressed = unc32 ? enc.ReadUInt() : enc.ReadLong();
        bool encrypted = (bitfield & (1 << 22)) != 0;
        long compressed;
        if (method != PakCompression.None)
        {
            bool size32 = (bitfield & (1 << 29)) != 0;
            compressed = size32 ? enc.ReadUInt() : enc.ReadLong();
        }
        else compressed = uncompressed;

        uint blockCount = (bitfield >> 6) & 0xffff;
        var e = new PakEntry
        {
            Path = path, Offset = entryOffset, UncompressedSize = uncompressed, CompressedSize = compressed,
            Method = method, Encrypted = encrypted,
            CompressionBlockSize = blockCount == 1 ? (uint)uncompressed : blockCount > 0 ? compressionBlockSize : 0,
        };

        int structSize = 8 * 3 + 4 * 2 + 1 + 20;
        if (method != PakCompression.None) structSize += 4 + (int)blockCount * 2 * 8;
        e.StructSize = structSize;

        long blockOffset = entryOffset + structSize;
        if (blockCount == 1 && !encrypted)
        {
            e.Blocks = new (long, long)[] { (blockOffset, blockOffset + compressed) };
        }
        else if (blockCount > 0)
        {
            e.Blocks = new (long, long)[blockCount];
            int align = encrypted ? 16 : 1;
            for (int i = 0; i < blockCount; i++)
            {
                uint length = enc.ReadUInt();
                e.Blocks[i] = (blockOffset, blockOffset + length);
                blockOffset += Align(length, align);
            }
        }
        return e;
    }

    public byte[] Extract(PakEntry e)
    {
        if (e.Method is PakCompression.Oodle or PakCompression.Zstd or PakCompression.LZ4)
            throw new NotSupportedException($"Сжатие {e.Method} требует нативную библиотеку и пока не распаковывается.");
        if (e.Method == PakCompression.Unknown)
            throw new NotSupportedException("Неизвестный метод сжатия.");

        using var fs = File.OpenRead(FilePath);
        int align = e.Encrypted ? 16 : 1;

        if (e.IsCompressed)
        {
            var outData = new byte[e.UncompressedSize];
            int outPos = 0;
            int blockSizeU = (int)e.CompressionBlockSize;
            for (int b = 0; b < e.Blocks.Length; b++)
            {
                var (bs, be) = e.Blocks[b];
                int blockSize = (int)(be - bs);
                int srcSize = Align(blockSize, align);
                var comp = ReadAt(fs, bs, srcSize);
                if (e.Encrypted) comp = Decrypt(comp);
                int uSize = (int)Math.Min(blockSizeU, e.UncompressedSize - (long)b * blockSizeU);
                var chunk = Decompress(comp, blockSize, uSize, e.Method);
                Array.Copy(chunk, 0, outData, outPos, uSize);
                outPos += uSize;
            }
            return outData;
        }
        else
        {
            long readSize = Align(e.UncompressedSize, align);
            var data = ReadAt(fs, e.Offset + e.StructSize, (int)readSize);
            if (e.Encrypted) data = Decrypt(data);
            if (data.Length == e.UncompressedSize) return data;
            var res = new byte[e.UncompressedSize];
            Array.Copy(data, 0, res, 0, (int)e.UncompressedSize);
            return res;
        }
    }

    private static byte[] Decompress(byte[] src, int srcLen, int outLen, PakCompression method)
    {
        using var ms = new MemoryStream(src, 0, srcLen);
        Stream z = method switch
        {
            PakCompression.Zlib => new ZLibStream(ms, CompressionMode.Decompress),
            PakCompression.Gzip => new GZipStream(ms, CompressionMode.Decompress),
            _ => throw new NotSupportedException("Метод сжатия не поддержан.")
        };
        using (z)
        {
            var outBuf = new byte[outLen];
            int read = 0;
            while (read < outLen)
            {
                int n = z.Read(outBuf, read, outLen - read);
                if (n == 0) break;
                read += n;
            }
            return outBuf;
        }
    }

    private byte[] ReadAndDecrypt(long offset, int size, bool encrypted)
    {
        using var fs = File.OpenRead(FilePath);
        var data = ReadAt(fs, offset, size);
        return encrypted ? Decrypt(data) : data;
    }

    private static byte[] ReadAt(FileStream fs, long offset, int size)
    {
        var buf = new byte[size];
        fs.Seek(offset, SeekOrigin.Begin);
        fs.ReadExactly(buf, 0, size);
        return buf;
    }

    private byte[] Decrypt(byte[] data)
    {
        if (_key == null) throw new InvalidOperationException("Нет AES-ключа для расшифровки.");
        int n = data.Length - (data.Length % 16);
        using var aes = Aes.Create();
        aes.Mode = CipherMode.ECB;
        aes.Padding = PaddingMode.None;
        aes.KeySize = 256;
        using var dec = aes.CreateDecryptor(_key, null);
        var outBuf = new byte[data.Length];
        dec.TransformBlock(data, 0, n, outBuf, 0);
        if (n < data.Length) Array.Copy(data, n, outBuf, n, data.Length - n);
        return outBuf;
    }

    private static int Align(long v, int a) => (int)((v + a - 1) & ~((long)a - 1));

    private static string ValidateMount(string m)
    {
        if (m.StartsWith("../../..")) m = m["../../..".Length..];
        return m;
    }

    private sealed class BinReader
    {
        private readonly byte[] _d;
        public int Pos;
        public BinReader(byte[] d) { _d = d; }
        public void Skip(int n) => Pos += n;
        public byte ReadByte() => _d[Pos++];
        public int ReadInt() { int v = BitConverter.ToInt32(_d, Pos); Pos += 4; return v; }
        public uint ReadUInt() { uint v = BitConverter.ToUInt32(_d, Pos); Pos += 4; return v; }
        public long ReadLong() { long v = BitConverter.ToInt64(_d, Pos); Pos += 8; return v; }
        public bool ReadBool() => ReadInt() != 0;
        public byte[] ReadBytes(int n) { var b = new byte[n]; Array.Copy(_d, Pos, b, 0, n); Pos += n; return b; }
        public int[] ReadIntArray(int n) { var a = new int[n]; for (int i = 0; i < n; i++) a[i] = ReadInt(); return a; }

        public string ReadFString()
        {
            int len = ReadInt();
            if (len == 0) return "";
            if (len < 0)
            {
                int count = -len;
                var sb = new StringBuilder(count);
                for (int i = 0; i < count; i++) { char c = (char)BitConverter.ToUInt16(_d, Pos); Pos += 2; if (c != 0) sb.Append(c); }
                return sb.ToString();
            }
            var s = Encoding.UTF8.GetString(_d, Pos, len);
            Pos += len;
            return s.TrimEnd('\0');
        }
    }
}

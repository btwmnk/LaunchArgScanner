using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LaunchArgScanner.Core;

public static partial class NetworkScanner
{
    private const int MaxEndpoints = 200;

    [GeneratedRegex(@"https?://[A-Za-z0-9._~:/?#@!$&'()*+,;=%\-\[\]]{4,180}", RegexOptions.IgnoreCase)]
    private static partial Regex UrlRx();

    [GeneratedRegex(@"^(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?$")]
    private static partial Regex IpRx();

    [GeneratedRegex(@"^(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24}(?::\d{1,5})?$")]
    private static partial Regex HostRx();

    private static readonly HashSet<string> FileExt = new(StringComparer.OrdinalIgnoreCase)
    {
        "dll","exe","ini","cfg","png","jpg","jpeg","dds","tga","bmp","uasset","umap","cpp","h","hpp",
        "pak","bin","txt","json","so","lib","pdb","ucas","utoc","tmp","dat","lua","js","css","xml",
        "wav","ogg","mp4","bik","ttf","otf","csv","sav","vdf","locres","upk","pck","res","log"
    };

    private static readonly (string needle, string label)[] StackMarkers =
    {
        ("OnlineSubsystemSteam", "Онлайн-подсистема: Steam"),
        ("OnlineSubsystemEOS", "Онлайн-подсистема: Epic Online Services"),
        ("OnlineSubsystemGDK", "Онлайн-подсистема: GDK (Xbox/Microsoft)"),
        ("OnlineSubsystemNull", "Онлайн-подсистема: Null (без сервиса)"),
        ("OnlineSubsystemUtils", "Онлайн-подсистема: Utils"),
        ("SteamSockets", "Транспорт: Steam Sockets"),
        ("SteamNetworkingSockets", "Транспорт: Steam Networking Sockets"),
        ("SteamNetDriver", "Сетевой драйвер: SteamNetDriver"),
        ("EOSNetDriver", "Сетевой драйвер: EOSNetDriver"),
        ("IpNetDriver", "Сетевой драйвер: IpNetDriver (UDP)"),
        ("WebSocketNetDriver", "Сетевой драйвер: WebSocket"),
        ("PacketHandler", "Обработчик пакетов (PacketHandler)"),
        ("DTLSHandler", "Шифрование трафика: DTLS"),
        ("AESGCMHandler", "Шифрование трафика: AES-GCM"),
        ("OodleHandlerComponent", "Сжатие трафика: Oodle Network"),
        ("OnlineBeacon", "Beacon (подключение до входа в игру)"),
        ("?Name=", "URL-параметр подключения ?Name="),
        ("?Game=", "URL-параметр подключения ?Game="),
    };

    private static readonly (string needle, string label)[] NetDlls =
    {
        ("ws2_32", "Сокеты: Winsock (ws2_32)"),
        ("wsock32", "Сокеты: Winsock (wsock32)"),
        ("iphlpapi", "IP Helper API"),
        ("winhttp", "HTTP-клиент: WinHTTP"),
        ("wininet", "HTTP-клиент: WinINet"),
        ("libcurl", "HTTP-клиент: libcurl"),
        ("crypt32", "TLS/крипто: crypt32"),
    };

    public static void Scan(IReadOnlyList<(string rel, byte[] data)> coreFiles,
                            IReadOnlyList<string> importDlls, List<ArgCandidate> sink)
    {
        var endpoints = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var stack = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var (rel, data) in coreFiles)
        {
            StringExtractor.Extract(data, 4, 200, s =>
            {
                if (endpoints.Count < MaxEndpoints) ScanEndpoints(s, rel, endpoints);
                foreach (var (needle, label) in StackMarkers)
                    if (s.Contains(needle, StringComparison.OrdinalIgnoreCase)) stack.Add(label);
            });
        }

        foreach (var dll in importDlls)
            foreach (var (needle, label) in NetDlls)
                if (dll.Contains(needle, StringComparison.OrdinalIgnoreCase)) stack.Add(label);

        foreach (var kv in endpoints.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
            sink.Add(new ArgCandidate
            {
                Arg = kv.Key,
                Category = ArgCategory.Endpoint,
                FromGameFiles = true,
                Confidence = Confidence.High,
                Description = "Адрес/эндпоинт из бинарника (" + kv.Value + "). Возможная цель для перенаправления на приватный сервер.",
            }.AddSrc(kv.Value));

        foreach (var label in stack.OrderBy(x => x))
            sink.Add(new ArgCandidate
            {
                Arg = label,
                Category = ArgCategory.Network,
                FromGameFiles = true,
                Confidence = Confidence.High,
                Description = "Элемент сетевого стека игры. Учесть при эмуляции сервера.",
            });
    }

    private static void ScanEndpoints(string s, string rel, Dictionary<string, string> endpoints)
    {

        foreach (Match m in UrlRx().Matches(s))
        {
            var url = m.Value.TrimEnd('.', ',', ')', ']', '"', '\'', '>');
            endpoints.TryAdd(url, rel);
            if (endpoints.Count >= MaxEndpoints) return;
        }

        var token = s.Trim();
        if (token.Length is < 4 or > 120) return;
        if (token.IndexOf(' ') >= 0 || token.IndexOf('/') >= 0 || token.IndexOf('\\') >= 0) return;

        if (IpRx().IsMatch(token))
        {
            if (!token.StartsWith("0.") && !token.StartsWith("127.") && token != "255.255.255.255")
                endpoints.TryAdd(token, rel);
            return;
        }

        if (HostRx().IsMatch(token))
        {
            var host = token.Split(':')[0];
            int dot = host.LastIndexOf('.');
            if (dot > 0 && FileExt.Contains(host[(dot + 1)..])) return;
            if (host.EndsWith(".Script", StringComparison.OrdinalIgnoreCase)) return;
            endpoints.TryAdd(token, rel);
        }
    }

    private static ArgCandidate AddSrc(this ArgCandidate c, string src)
    {
        c.Sources.Add(src);
        return c;
    }
}

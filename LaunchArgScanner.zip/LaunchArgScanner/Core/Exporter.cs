using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace LaunchArgScanner.Core;

public static class Exporter
{
    public static string ToText(IEnumerable<ArgCandidate> items, ScanResult? r)
    {
        var sb = new StringBuilder();
        if (r != null)
        {
            sb.AppendLine($"# Игра:   {r.Root}");
            sb.AppendLine($"# Движок: {r.Engine.DisplayName}");
            if (r.MainExe != null) sb.AppendLine($"# Exe:    {r.MainExe}");
            sb.AppendLine();
        }
        var list = items.ToList();
        int pad = list.Count == 0 ? 20 : System.Math.Min(48, list.Max(i => i.ArgWithHint.Length) + 2);
        foreach (var i in list)
            sb.AppendLine($"{i.ArgWithHint.PadRight(pad)} [{i.ConfidenceText}, {i.CategoryText}] {i.Description}");
        return sb.ToString();
    }

    public static string ToCsv(IEnumerable<ArgCandidate> items)
    {
        static string Q(string s) => "\"" + s.Replace("\"", "\"\"") + "\"";
        var sb = new StringBuilder();
        sb.AppendLine("Arg;ValueHint;Category;Confidence;Hits;Description;Files");
        foreach (var i in items)
            sb.AppendLine(string.Join(";", Q(i.Arg), Q(i.ValueHint ?? ""), Q(i.CategoryText), Q(i.ConfidenceText),
                i.Hits.ToString(), Q(i.Description), Q(string.Join(", ", i.Sources))));
        return sb.ToString();
    }

    public static string ToJson(IEnumerable<ArgCandidate> items, ScanResult? r)
    {
        var payload = new
        {
            root = r?.Root,
            engine = r?.Engine.DisplayName,
            mainExe = r?.MainExe,
            args = items.Select(i => new
            {
                arg = i.Arg,
                valueHint = i.ValueHint,
                category = i.Category.ToString(),
                confidence = i.Confidence.ToString(),
                hits = i.Hits,
                description = i.Description,
                files = i.Sources.ToArray()
            })
        };
        return JsonSerializer.Serialize(payload, new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace LaunchArgScanner.Core;

public static class AssetScanner
{
    private const int MaxMaps = 600;
    private const int MaxConfigKeys = 2000;
    private const int MaxIniFiles = 250;

    private static readonly HashSet<string> CultureCodes = new(StringComparer.OrdinalIgnoreCase)
    {
        "en","en-US","en-GB","ru","ru-RU","fr","fr-FR","de","de-DE","es","es-ES","es-419","es-MX",
        "it","it-IT","pt","pt-BR","pt-PT","pl","pl-PL","tr","tr-TR","ja","ja-JP","ko","ko-KR",
        "zh","zh-Hans","zh-Hant","zh-CN","zh-TW","cs","cs-CZ","nl","nl-NL","sv","da","fi","no","nb",
        "uk","uk-UA","hu","ro","el","th","th-TH","vi","id","ar","he","hi"
    };

    public static void Scan(string root, IReadOnlyList<string> files, EngineFamily engine, List<ArgCandidate> sink)
    {
        try { ScanMaps(root, files, sink); } catch { }
        try { ScanCultures(root, files, sink); } catch { }
        try { ScanConfigKeys(root, files, sink); } catch { }
    }

    private static void ScanMaps(string root, IReadOnlyList<string> files, List<ArgCandidate> sink)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int n = 0;
        foreach (var f in files)
        {
            var ext = Path.GetExtension(f);
            bool map = ext.Equals(".umap", StringComparison.OrdinalIgnoreCase)
                    || ext.Equals(".bsp", StringComparison.OrdinalIgnoreCase);
            if (!map) continue;

            var name = Path.GetFileNameWithoutExtension(f);
            if (!seen.Add(name)) continue;
            if (n++ >= MaxMaps) break;

            sink.Add(new ArgCandidate
            {
                Arg = name,
                Category = ArgCategory.Map,
                FromGameFiles = true,
                Confidence = Confidence.High,
                Description = "Карта/уровень. Загрузить: -map=" + name + " (или +map " + name + " в Source).",
            }.WithSource(Path.GetRelativePath(root, f)));
        }
    }

    private static void ScanCultures(string root, IReadOnlyList<string> files, List<ArgCandidate> sink)
    {
        var found = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in files)
        {
            if (f.IndexOf("ocaliz", StringComparison.OrdinalIgnoreCase) < 0 &&
                f.IndexOf("\\resource\\", StringComparison.OrdinalIgnoreCase) < 0) continue;

            foreach (var seg in f.Split(Path.DirectorySeparatorChar))
                if (CultureCodes.Contains(seg)) found.Add(seg);

        }
        foreach (var c in found.OrderBy(x => x))
            sink.Add(new ArgCandidate
            {
                Arg = c,
                Category = ArgCategory.Culture,
                FromGameFiles = true,
                Confidence = Confidence.High,
                Description = "Язык/локаль в сборке. Выбрать: -culture=" + c + " (Unreal).",
            });
    }

    private static void ScanConfigKeys(string root, IReadOnlyList<string> files, List<ArgCandidate> sink)
    {
        var inis = files.Where(f => f.EndsWith(".ini", StringComparison.OrdinalIgnoreCase)).Take(MaxIniFiles);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int n = 0;

        foreach (var ini in inis)
        {
            string[] lines;
            try { lines = File.ReadAllLines(ini); } catch { continue; }
            string section = "";
            var rel = Path.GetRelativePath(root, ini);

            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line.Length == 0 || line[0] is ';' or '#') continue;
                if (line[0] == '[' && line[^1] == ']') { section = line[1..^1]; continue; }

                int eq = line.IndexOf('=');
                if (eq <= 0) continue;
                var key = line[..eq].TrimStart('+', '-', '.', '!').Trim();
                if (key.Length == 0 || key.Length > 60 || key.Contains(' ')) continue;
                var val = line[(eq + 1)..].Trim();

                var id = section + ":" + key;
                if (!seen.Add(id)) continue;
                if (n++ >= MaxConfigKeys) return;

                sink.Add(new ArgCandidate
                {
                    Arg = key,
                    Category = ArgCategory.ConfigKey,
                    FromGameFiles = true,
                    Confidence = Confidence.High,
                    IsValueParam = true,
                    ValueHint = string.IsNullOrEmpty(val) ? "<значение>" : val,
                    Description = $"Ключ конфига [{section}] в {Path.GetFileName(ini)}" +
                                  (string.IsNullOrEmpty(val) ? "." : $" (сейчас: {Trim(val)}).") +
                                  $" Переопределить: -ini:{IniName(ini)}:[{section}]:{key}=<значение>.",
                }.WithSource(rel));
            }
        }
    }

    private static string Trim(string s) => s.Length <= 60 ? s : s[..57] + "...";

    private static string IniName(string path)
    {
        var n = Path.GetFileNameWithoutExtension(path);
        if (n.StartsWith("Default", StringComparison.OrdinalIgnoreCase)) n = n["Default".Length..];
        return n;
    }

    private static ArgCandidate WithSource(this ArgCandidate c, string src)
    {
        c.Sources.Add(src);
        return c;
    }
}

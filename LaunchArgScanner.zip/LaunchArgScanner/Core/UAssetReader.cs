using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LaunchArgScanner.Core;

public sealed class UAssetName
{
    public int Index;
    public string Name = "";
}

public sealed class UAssetObj
{
    public int Index;
    public string Name = "";
    public string ClassName = "";
    public string Outer = "";
    public string SizeText = "";
}

public sealed class UAssetInfo
{
    public bool MagicOk;
    public string Error = "";
    public long FileSize;
    public int LegacyVersion;
    public int FileVersionUE4;
    public int FileVersionUE5;
    public int LicenseeVersion;
    public uint PackageFlags;
    public string FolderName = "";
    public int CustomVersionCount;
    public int TotalHeaderSize;
    public int NameCount;
    public int NameOffset;
    public int ImportCount;
    public int ImportOffset;
    public int ExportCount;
    public int ExportOffset;

    public bool Unversioned;
    public bool NameHashes;
    public int EffectiveUe4;
    public int EffectiveUe5;

    public List<UAssetName> Names = new();
    public List<UAssetObj> Imports = new();
    public List<UAssetObj> Exports = new();

    public bool NamesPartial;
    public bool ImportsPartial;
    public bool ExportsPartial;
    public bool ImportsRead;
    public bool ExportsRead;

    public bool IsUe5;

    public string EngineText
    {
        get
        {
            string ver = Unversioned ? "без версии в файле" : (IsUe5 ? "UE5 v" + FileVersionUE5 + ", UE4 v" + FileVersionUE4 : "UE4 v" + FileVersionUE4);
            return (IsUe5 ? "Unreal Engine 5" : "Unreal Engine 4") + " (" + ver + ")";
        }
    }
}

public static class UAssetReader
{
    private const uint Magic = 0x9E2A83C1;

    public static UAssetInfo Read(string path, int forceUe4 = 0, int forceUe5 = 0)
    {
        var info = new UAssetInfo();
        try
        {
            byte[] d = File.ReadAllBytes(path);
            info.FileSize = d.LongLength;
            var r = new R(d);

            uint tag = r.U();
            info.MagicOk = tag == Magic;
            if (!info.MagicOk) { info.Error = "Файл не является .uasset (неверная сигнатура)."; return info; }

            int legacy = r.I();
            info.LegacyVersion = legacy;
            if (legacy < -9 || legacy >= 0) { info.Error = "Неизвестная версия пакета (" + legacy + ")."; return info; }

            if (legacy != -4) r.I();
            info.FileVersionUE4 = r.I();
            if (legacy <= -8) info.FileVersionUE5 = r.I();
            info.LicenseeVersion = r.I();

            if (legacy <= -2)
            {
                int cvc = r.I();
                if (cvc < 0 || cvc > 4096) { info.Error = "Повреждён список custom versions."; return info; }
                info.CustomVersionCount = cvc;
                r.Skip(cvc * 20);
            }

            info.TotalHeaderSize = r.I();
            info.FolderName = r.Str();
            info.PackageFlags = r.U();
            info.NameCount = r.I();
            info.NameOffset = r.I();
            int pos0 = r.Pos;

            info.IsUe5 = legacy <= -8 || info.FileVersionUE5 > 0;
            info.Unversioned = info.FileVersionUE4 == 0 && info.FileVersionUE5 == 0;

            if (!OffsetOk(info.NameOffset, d.Length) || info.NameCount < 0 || info.NameCount > 5_000_000)
            {
                info.Error = "Смещение таблицы имён вне файла.";
                return info;
            }

            bool hashes = DetectHashes(d, info.NameOffset, info.NameCount, out int nameEnd, out bool namesOk);
            info.NameHashes = hashes;

            var lay = DetectLayout(d, pos0, info.IsUe5, info.NameOffset, nameEnd);
            if (lay != null)
            {
                info.ExportCount = lay.ExportCount;
                info.ExportOffset = lay.ExportOffset;
                info.ImportCount = lay.ImportCount;
                info.ImportOffset = lay.ImportOffset;
            }

            info.EffectiveUe4 = forceUe4 > 0 ? forceUe4 : (info.FileVersionUE4 > 0 ? info.FileVersionUE4 : InferUe4(hashes, lay));
            info.EffectiveUe5 = forceUe5 > 0 ? forceUe5 : info.FileVersionUE5;

            ReadNames(d, info, hashes);
            if (!namesOk) info.NamesPartial = info.Names.Count < info.NameCount;

            if (OffsetOk(info.ImportOffset, d.Length) && info.ImportCount >= 0 && info.ImportCount < 1_000_000)
                ReadImports(d, info);
            if (OffsetOk(info.ExportOffset, d.Length) && info.ExportCount >= 0 && info.ExportCount < 1_000_000)
                ReadExports(d, info);
        }
        catch (Exception ex)
        {
            if (string.IsNullOrEmpty(info.Error)) info.Error = ex.Message;
        }
        return info;
    }

    private static bool OffsetOk(int off, int len) => off > 0 && off < len;

    private static int InferUe4(bool hashes, Layout? lay)
    {
        bool loc = lay?.HasLoc ?? false;
        bool text = lay?.HasText ?? false;
        if (loc) return 517;
        if (text) return hashes ? 510 : 480;
        return hashes ? 504 : 400;
    }

    private static bool DetectHashes(byte[] d, int nameOffset, int nameCount, out int endPos, out bool ok)
    {
        if (ProbeNames(d, nameOffset, nameCount, true, out int e1)) { endPos = e1; ok = true; return true; }
        if (ProbeNames(d, nameOffset, nameCount, false, out int e2)) { endPos = e2; ok = true; return false; }
        ProbeNames(d, nameOffset, nameCount, true, out endPos);
        ok = false;
        return true;
    }

    private static bool ProbeNames(byte[] d, int nameOffset, int nameCount, bool hashes, out int endPos)
    {
        var r = new R(d) { Pos = nameOffset };
        for (int i = 0; i < nameCount; i++)
        {
            if (r.Pos + 4 > d.Length) { endPos = r.Pos; return false; }
            int len = BitConverter.ToInt32(d, r.Pos);
            if (len > 1_000_000 || len < -1_000_000) { endPos = r.Pos; return false; }
            try { r.Str(); } catch { endPos = r.Pos; return false; }
            if (hashes)
            {
                if (r.Pos + 4 > d.Length) { endPos = r.Pos; return i == nameCount - 1; }
                r.Skip(4);
            }
        }
        endPos = r.Pos;
        return true;
    }

    private sealed class Layout
    {
        public bool HasSoft;
        public bool HasLoc;
        public bool HasText;
        public int ExportCount;
        public int ExportOffset;
        public int ImportCount;
        public int ImportOffset;
        public int Score;
    }

    private static Layout? DetectLayout(byte[] d, int pos0, bool isUe5, int nameOffset, int nameEnd)
    {
        Layout? best = null;
        bool[] softOpts = isUe5 ? new[] { false, true } : new[] { false };
        bool[] locOpts = { false, true };
        bool[] textOpts = { false, true };

        foreach (var soft in softOpts)
            foreach (var loc in locOpts)
                foreach (var text in textOpts)
                {
                    var lay = TryLayout(d, pos0, soft, loc, text, nameOffset, nameEnd);
                    if (lay != null && (best == null || lay.Score > best.Score)) best = lay;
                }
        return best;
    }

    private static Layout? TryLayout(byte[] d, int pos0, bool soft, bool loc, bool text, int nameOffset, int nameEnd)
    {
        try
        {
            var r = new R(d) { Pos = pos0 };
            int gatherOffset = -1;
            if (soft) { r.I(); r.I(); }
            if (loc) r.Str();
            if (text) { r.I(); gatherOffset = r.I(); }
            if (r.Pos + 20 > d.Length) return null;
            int exportCount = r.I();
            int exportOffset = r.I();
            int importCount = r.I();
            int importOffset = r.I();
            int dependsOffset = r.I();

            if (exportCount < 0 || exportCount > 1_000_000) return null;
            if (importCount < 0 || importCount > 1_000_000) return null;
            if (!Within(exportOffset, d.Length) || !Within(importOffset, d.Length) || !Within(dependsOffset, d.Length)) return null;
            if (exportCount > 0 && (exportOffset <= nameOffset || exportOffset >= d.Length)) return null;
            if (importCount > 0 && (importOffset <= nameOffset || importOffset >= d.Length)) return null;

            var lay = new Layout
            {
                HasSoft = soft, HasLoc = loc, HasText = text,
                ExportCount = exportCount, ExportOffset = exportOffset,
                ImportCount = importCount, ImportOffset = importOffset
            };

            int firstSection = int.MaxValue;
            if (text && gatherOffset > nameOffset) firstSection = Math.Min(firstSection, gatherOffset);
            if (importOffset > nameOffset) firstSection = Math.Min(firstSection, importOffset);
            if (exportOffset > nameOffset) firstSection = Math.Min(firstSection, exportOffset);

            int score = 0;
            if (firstSection != int.MaxValue)
            {
                int diff = Math.Abs(firstSection - nameEnd);
                if (diff == 0) score += 100;
                else if (diff <= 4) score += 60;
                else if (diff <= 32) score += 20;
            }
            if (importCount > 0 && importOffset > nameOffset) score += 5;
            if (exportCount > 0 && exportOffset > nameOffset) score += 5;
            if (dependsOffset > 0) score += 1;
            lay.Score = score;
            return score > 0 ? lay : null;
        }
        catch { return null; }
    }

    private static bool Within(int off, int len) => off >= 0 && off <= len;

    private static void ReadNames(byte[] d, UAssetInfo info, bool hashes)
    {
        var r = new R(d) { Pos = info.NameOffset };
        for (int i = 0; i < info.NameCount; i++)
        {
            if (r.Pos + 4 > d.Length) { info.NamesPartial = true; break; }
            string s;
            try { s = r.Str(); } catch { info.NamesPartial = true; break; }
            if (hashes)
            {
                if (r.Pos + 4 > d.Length) { info.Names.Add(new UAssetName { Index = i, Name = s }); info.NamesPartial = true; break; }
                r.Skip(4);
            }
            info.Names.Add(new UAssetName { Index = i, Name = s });
        }
    }

    private static string Resolve(UAssetInfo info, int nameIndex, int number)
    {
        if (nameIndex < 0 || nameIndex >= info.Names.Count) return "?";
        var n = info.Names[nameIndex].Name;
        return number > 0 ? n + "_" + (number - 1) : n;
    }

    private static string RefName(UAssetInfo info, int pkgIndex)
    {
        if (pkgIndex == 0) return "(нет)";
        if (pkgIndex < 0)
        {
            int idx = -pkgIndex - 1;
            return idx >= 0 && idx < info.Imports.Count ? info.Imports[idx].Name : "import#" + idx;
        }
        int e = pkgIndex - 1;
        return e >= 0 && e < info.Exports.Count ? info.Exports[e].Name : "export#" + e;
    }

    private static void ReadImports(byte[] d, UAssetInfo info)
    {
        info.ImportsRead = true;
        var r = new R(d) { Pos = info.ImportOffset };
        for (int i = 0; i < info.ImportCount; i++)
        {
            if (r.Pos + 28 > d.Length) { info.ImportsPartial = true; break; }
            r.I(); r.I();
            int cnI = r.I(); int cnN = r.I();
            int outer = r.I();
            int onI = r.I(); int onN = r.I();
            if (cnI < 0 || cnI >= info.Names.Count || onI < 0 || onI >= info.Names.Count) { info.ImportsPartial = true; break; }
            info.Imports.Add(new UAssetObj
            {
                Index = i,
                Name = Resolve(info, onI, onN),
                ClassName = Resolve(info, cnI, cnN),
                Outer = outer.ToString()
            });
        }
    }

    private static void ReadExports(byte[] d, UAssetInfo info)
    {
        info.ExportsRead = true;
        int ue4 = info.EffectiveUe4;
        var r = new R(d) { Pos = info.ExportOffset };
        bool hasTemplate = ue4 >= 508;
        var raw = new List<(int cls, int onI, int onN, long size)>();
        for (int i = 0; i < info.ExportCount; i++)
        {
            if (r.Pos + 44 > d.Length) { info.ExportsPartial = true; break; }
            int classIndex = r.I();
            r.I();
            if (hasTemplate) r.I();
            r.I();
            int onI = r.I(); int onN = r.I();
            if (onI < 0 || onI >= info.Names.Count) { info.ExportsPartial = true; break; }
            r.U();
            long serialSize = r.L();
            r.L();
            if (serialSize < 0 || serialSize > info.FileSize * 8 + 0x400000) { info.ExportsPartial = true; break; }
            raw.Add((classIndex, onI, onN, serialSize));
            SkipExportTail(r, d, ue4);
            if (r.Pos > d.Length) { info.ExportsPartial = true; break; }
        }
        foreach (var e in raw)
            info.Exports.Add(new UAssetObj
            {
                Index = info.Exports.Count,
                Name = Resolve(info, e.onI, e.onN),
                ClassName = e.cls == 0 ? "Class" : RefName(info, e.cls),
                SizeText = Human(e.size)
            });
    }

    private static void SkipExportTail(R r, byte[] d, int ue4)
    {
        r.I();
        r.I();
        if (ue4 >= 224) r.I();
        if (ue4 >= 322) r.U();
        if (ue4 >= 507) r.Skip(16);
        if (ue4 >= 365)
        {
            if (r.Pos + 4 > d.Length) return;
            int depCount = r.I();
            if (depCount >= 0 && depCount < 1_000_000) r.Skip(depCount * 4);
        }
        if (ue4 >= 475) r.U();
        if (ue4 >= 508) r.I();
        if (ue4 >= 391) { r.I(); r.I(); }
    }

    private static string Human(long n)
    {
        if (n < 1024) return n + " B";
        double v = n;
        string[] u = { "KB", "MB", "GB" };
        int i = -1;
        do { v /= 1024; i++; } while (v >= 1024 && i < u.Length - 1);
        return v.ToString("0.0") + " " + u[i];
    }

    private sealed class R
    {
        private readonly byte[] _d;
        public int Pos;
        public R(byte[] d) { _d = d; }
        public void Skip(int n) => Pos += n;
        public int I() { int v = BitConverter.ToInt32(_d, Pos); Pos += 4; return v; }
        public uint U() { uint v = BitConverter.ToUInt32(_d, Pos); Pos += 4; return v; }
        public long L() { long v = BitConverter.ToInt64(_d, Pos); Pos += 8; return v; }

        public string Str()
        {
            int len = I();
            if (len == 0) return "";
            if (len < 0)
            {
                int count = -len;
                if (count > 1_000_000) throw new InvalidDataException("bad string");
                var sb = new StringBuilder(count);
                for (int i = 0; i < count; i++) { char c = (char)BitConverter.ToUInt16(_d, Pos); Pos += 2; if (c != 0) sb.Append(c); }
                return sb.ToString();
            }
            if (len > 1_000_000) throw new InvalidDataException("bad string");
            var s = Encoding.UTF8.GetString(_d, Pos, len);
            Pos += len;
            return s.TrimEnd('\0');
        }
    }
}

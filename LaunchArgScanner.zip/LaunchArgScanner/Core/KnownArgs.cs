using System;
using System.Collections.Generic;
using System.Linq;
using static LaunchArgScanner.Core.EngineMask;

namespace LaunchArgScanner.Core;

public static class KnownArgs
{
    private static KnownArg K(string name, string desc, EngineMask engines, string? hint = null) => new(name, desc, engines, hint);

    public static IReadOnlyList<KnownArg> All { get; } = new List<KnownArg>
    {

        K("-windowed", "Запуск в оконном режиме", Unreal),
        K("-fullscreen", "Запуск в полноэкранном режиме", Unreal),
        K("-ResX=", "Ширина окна/разрешения, например -ResX=1920", Unreal, "<ширина>"),
        K("-ResY=", "Высота окна/разрешения, например -ResY=1080", Unreal, "<высота>"),
        K("-WinX=", "Позиция окна по X", UnrealModern, "<x>"),
        K("-WinY=", "Позиция окна по Y", UnrealModern, "<y>"),
        K("-PosX=", "Позиция окна по X", Unreal3, "<x>"),
        K("-PosY=", "Позиция окна по Y", Unreal3, "<y>"),
        K("-log", "Открыть окно консоли с логом", Unreal),
        K("-nosound", "Отключить звук", Unreal),
        K("-NoSplash", "Не показывать сплэш-экран при загрузке", Unreal),
        K("-nomovie", "Пропустить стартовые ролики (зависит от версии)", Unreal),
        K("-nostartupmovies", "Пропустить стартовые ролики", Unreal3),
        K("-NoLoadingScreen", "Отключить экран загрузки (MoviePlayer)", UnrealModern),
        K("-USEALLAVAILABLECORES", "Использовать все ядра CPU", Unreal),
        K("-ONETHREAD", "Однопоточный режим (отладка)", Unreal),
        K("-nothreading", "Отключить многопоточность (отладка)", UnrealModern),
        K("-NoTextureStreaming", "Отключить стриминг текстур (грузить всё сразу)", Unreal),
        K("-VSync", "Принудительно включить VSync (не во всех версиях)", Unreal),
        K("-NoVSync", "Принудительно выключить VSync (не во всех версиях)", Unreal),
        K("-dx11", "Рендер через DirectX 11", Unreal),
        K("-d3d11", "Рендер через DirectX 11 (альтернативное имя)", Unreal),
        K("-dx12", "Рендер через DirectX 12", UnrealModern),
        K("-d3d12", "Рендер через DirectX 12 (альтернативное имя)", UnrealModern),
        K("-vulkan", "Рендер через Vulkan", UnrealModern),
        K("-opengl", "Рендер через OpenGL (старые UE4)", UnrealModern),
        K("-dx9", "Рендер через DirectX 9", Unreal3),
        K("-sm5", "Shader Model 5", UnrealModern),
        K("-sm6", "Shader Model 6 (UE5, нужен для Nanite/VSM на DX12)", UnrealModern),
        K("-nullrhi", "Запуск без рендеринга (серверы, тесты)", UnrealModern),
        K("-d3ddebug", "Включить отладочный слой Direct3D", UnrealModern),
        K("-gpucrashdebugging", "Расширенная диагностика падений GPU (Aftermath/DRED)", UnrealModern),
        K("-norhithread", "Отключить отдельный поток RHI", UnrealModern),
        K("-preferNvidia", "Предпочитать GPU NVIDIA на ноутбуках с двумя GPU", UnrealModern),
        K("-graphicsadapter=", "Индекс видеокарты для рендера", UnrealModern, "<индекс>"),
        K("-AllowSoftwareRendering", "Разрешить программный рендер (WARP)", UnrealModern),
        K("-ExecCmds=", "Выполнить консольные команды при старте: -ExecCmds=\"r.ScreenPercentage 100, t.MaxFPS 144\"", UnrealModern, "\"<команды через запятую>\""),
        K("-exec=", "Выполнить файл с консольными командами", Unreal, "<файл>"),
        K("-dpcvars=", "Задать CVar'ы при старте (UE5): -dpcvars=r.Foo=1,t.MaxFPS=144", UnrealModern, "<cvar=значение,...>"),
        K("-ini:", "Переопределить ini: -ini:Engine:[/Script/Engine.RendererSettings]:r.Foo=1", UnrealModern, "<Файл:[Секция]:Ключ=Знач>"),
        K("-benchmark", "Режим бенчмарка (фиксированный шаг времени)", Unreal),
        K("-NoScreenMessages", "Скрыть отладочные сообщения на экране", UnrealModern),
        K("-unattended", "Без диалоговых окон (автоматизация)", Unreal),
        K("-nopause", "Не ждать нажатия клавиши при закрытии лога", Unreal),
        K("-stdout", "Дублировать лог в stdout", UnrealModern),
        K("-FullStdOutLogOutput", "Полный вывод лога в stdout", UnrealModern),
        K("-FORCELOGFLUSH", "Сбрасывать лог на диск после каждой строки", Unreal),
        K("-LOG=", "Имя файла лога", Unreal, "<имя.log>"),
        K("-ABSLOG=", "Абсолютный путь к файлу лога", Unreal, "<путь>"),
        K("-culture=", "Язык/культура интерфейса (en, ru, ...)", UnrealModern, "<код>"),
        K("-userdir=", "Своя папка для сохранений и конфигов", UnrealModern, "<путь>"),
        K("-nosteam", "Отключить онлайн-подсистему Steam", UnrealModern),
        K("-nohmd", "Отключить VR-шлем", UnrealModern),
        K("-vr", "Запуск в VR-режиме", UnrealModern),
        K("-emulatestereo", "Эмуляция стереорендера VR без шлема", UnrealModern),
        K("-clearPSODriverCache", "Очистить кеш PSO драйвера при старте (UE5)", UnrealModern),
        K("-trace=", "Unreal Insights: каналы трассировки (cpu,gpu,frame,...)", UnrealModern, "<каналы>"),
        K("-tracehost=", "Unreal Insights: адрес хоста трассировки", UnrealModern, "<ip>"),
        K("-statnamedevents", "Именованные события для профайлеров", UnrealModern),
        K("-game", "Запуск в режиме игры (для редактора/dev-сборок)", UnrealModern),
        K("-server", "Запуск как выделенный сервер", Unreal),
        K("-messaging", "Включить шину сообщений (dev-сборки)", UnrealModern),
        K("-seekfreeloading", "Загрузка cooked-пакетов (UE3)", Unreal3),
        K("-nohomedir", "Хранить конфиги рядом с игрой, а не в Документах (UE3)", Unreal3),
        K("-installed", "Режим установленной игры (UE3)", Unreal3),
        K("-NOVERIFYGC", "Отключить проверку сборщика мусора", Unreal),
        K("-multihome=", "Привязать сеть к конкретному IP", Unreal, "<ip>"),

        K("-screen-fullscreen", "Полный экран: 1 — вкл, 0 — выкл", Unity, "<0|1>"),
        K("-screen-width", "Ширина окна", Unity, "<ширина>"),
        K("-screen-height", "Высота окна", Unity, "<высота>"),
        K("-window-mode", "Режим окна: exclusive | borderless | windowed", Unity, "<режим>"),
        K("-popupwindow", "Окно без рамки", Unity),
        K("-monitor", "Номер монитора (с 1)", Unity, "<N>"),
        K("-adapter", "Индекс видеокарты (D3D)", Unity, "<N>"),
        K("-screen-quality", "Пресет качества по имени", Unity, "<имя>"),
        K("-force-d3d11", "Принудительно DirectX 11", Unity),
        K("-force-d3d12", "Принудительно DirectX 12", Unity),
        K("-force-vulkan", "Принудительно Vulkan", Unity),
        K("-force-glcore", "Принудительно OpenGL Core", Unity),
        K("-force-d3d11-singlethreaded", "DX11 без многопоточного рендера", Unity),
        K("-force-driver-type-warp", "Программный рендер DX11 (WARP)", Unity),
        K("-force-feature-level-11-0", "Ограничить feature level DX11.0", Unity),
        K("-force-gfx-jobs", "Режим графических jobs: native | legacy | split", Unity, "<режим>"),
        K("-force-device-index", "Индекс GPU (Vulkan)", Unity, "<N>"),
        K("-force-clamped", "Ограничить OpenGL возможностями ядра", Unity),
        K("-nolog", "Не писать Player.log", Unity),
        K("-logFile", "Путь к файлу лога (- = stdout)", Unity, "<путь>"),
        K("-batchmode", "Пакетный режим без окна", Unity),
        K("-nographics", "Без инициализации графики (с -batchmode)", Unity),
        K("-single-instance", "Разрешить только один экземпляр игры", Unity),
        K("-parentHWND", "Встроить окно в чужое окно", Unity, "<hwnd>"),
        K("-show-screen-selector", "Показать окно выбора разрешения при старте", Unity),
        K("-vrmode", "Запуск в VR-режиме с указанным устройством", Unity, "<устройство>"),
        K("-systemallocator", "Системный аллокатор вместо встроенного (отладка)", Unity),
        K("-job-worker-count", "Число потоков Job System", Unity, "<N>"),
        K("-disable-gpu-skinning", "Отключить GPU-скиннинг", Unity),

        K("-novid", "Пропустить вступительное видео", AnySource),
        K("-console", "Открыть консоль при старте", AnySource),
        K("-windowed", "Оконный режим", AnySource),
        K("-sw", "Оконный режим (короткая форма)", AnySource),
        K("-fullscreen", "Полноэкранный режим", AnySource),
        K("-noborder", "Окно без рамки", AnySource),
        K("-w", "Ширина экрана", AnySource, "<ширина>"),
        K("-h", "Высота экрана", AnySource, "<высота>"),
        K("-refresh", "Частота обновления", AnySource, "<Гц>"),
        K("-freq", "Частота обновления (старое имя)", Source, "<Гц>"),
        K("-high", "Высокий приоритет процесса", AnySource),
        K("-threads", "Количество потоков", AnySource, "<N>"),
        K("-nojoy", "Отключить поддержку джойстика", AnySource),
        K("-nosteamcontroller", "Отключить Steam Controller", AnySource),
        K("-language", "Язык игры", AnySource, "<язык>"),
        K("-vulkan", "Рендер через Vulkan", AnySource),
        K("-dx11", "Рендер через DirectX 11", Source2),
        K("-allow_third_party_software", "Разрешить сторонние программы-оверлеи (CS2, при VAC-доверии)", Source2),
        K("-dxlevel", "Уровень DirectX (80/90/95)", Source, "<уровень>"),
        K("-nod3d9ex", "Отключить D3D9Ex", Source),
        K("-heapsize", "Размер кучи в КБ", Source, "<КБ>"),
        K("-noaafonts", "Отключить сглаживание шрифтов", Source),
        K("-autoconfig", "Сбросить графику на авто-настройки", Source),
        K("-dev", "Режим разработчика", Source),
        K("-insecure", "Запуск без VAC", AnySource),
        K("-tickrate", "Тикрейт локального сервера", AnySource, "<N>"),
        K("-nocrashdialog", "Не показывать окно ошибки при падении", Source),
        K("-softparticlesdefaultoff", "Отключить мягкие частицы", Source),
        K("+fps_max", "Ограничение FPS (консольная переменная)", AnySource, "<N>"),
        K("+mat_queue_mode", "Многопоточный рендер (-1/0/2)", Source, "<режим>"),
        K("+exec", "Выполнить cfg-файл при старте", AnySource, "<файл.cfg>"),
        K("+map", "Загрузить карту при старте", AnySource, "<карта>"),
        K("+connect", "Подключиться к серверу при старте", AnySource, "<ip:port>"),

        K("--fullscreen", "Полноэкранный режим (-f)", Godot),
        K("--windowed", "Оконный режим (-w)", Godot),
        K("--maximized", "Развернуть окно (-m)", Godot),
        K("--always-on-top", "Поверх всех окон (-t)", Godot),
        K("--resolution", "Разрешение окна, например 1920x1080", Godot, "<WxH>"),
        K("--position", "Позиция окна, например 0,0", Godot, "<X,Y>"),
        K("--screen", "Номер экрана", Godot, "<N>"),
        K("--single-window", "Все окна в одном", Godot),
        K("--rendering-driver", "Драйвер рендера: vulkan | d3d12 | opengl3", Godot, "<драйвер>"),
        K("--rendering-method", "Метод рендера: forward_plus | mobile | gl_compatibility", Godot, "<метод>"),
        K("--display-driver", "Драйвер дисплея", Godot, "<драйвер>"),
        K("--audio-driver", "Аудиодрайвер (Dummy — без звука)", Godot, "<драйвер>"),
        K("--gpu-index", "Индекс видеокарты", Godot, "<N>"),
        K("--max-fps", "Ограничение FPS", Godot, "<N>"),
        K("--frame-delay", "Задержка кадра в мс", Godot, "<мс>"),
        K("--time-scale", "Скорость игрового времени", Godot, "<множитель>"),
        K("--disable-vsync", "Отключить VSync", Godot),
        K("--print-fps", "Печатать FPS в stdout", Godot),
        K("--verbose", "Подробный лог (-v)", Godot),
        K("--quiet", "Тихий режим (-q)", Godot),
        K("--headless", "Без окна и звука", Godot),
        K("--log-file", "Путь к файлу лога", Godot, "<путь>"),
        K("--language", "Язык (-l)", Godot, "<локаль>"),
        K("--main-pack", "Путь к .pck с ресурсами", Godot, "<путь>"),
        K("--disable-crash-handler", "Отключить обработчик падений", Godot),
        K("--fixed-fps", "Фиксированный FPS симуляции", Godot, "<N>"),

        K("-devmode", "Режим разработчика (консоль, читы)", CryEngine),
        K("-dx11", "Рендер через DirectX 11", CryEngine),
        K("-dx12", "Рендер через DirectX 12", CryEngine),
        K("-vulkan", "Рендер через Vulkan", CryEngine),

        K("-windowed", "Оконный режим (встречается во многих играх)", Generic),
        K("-fullscreen", "Полный экран (встречается во многих играх)", Generic),
        K("-borderless", "Окно без рамки (встречается во многих играх)", Generic),
        K("-noborder", "Окно без рамки (встречается во многих играх)", Generic),
        K("-dx11", "DirectX 11 (встречается во многих играх)", Generic),
        K("-dx12", "DirectX 12 (встречается во многих играх)", Generic),
        K("-vulkan", "Vulkan (встречается во многих играх)", Generic),
        K("-opengl", "OpenGL (встречается во многих играх)", Generic),
        K("-console", "Консоль разработчика (встречается во многих играх)", Generic),
        K("-log", "Включить лог (встречается во многих играх)", Generic),
        K("-debug", "Отладочный режим (встречается во многих играх)", Generic),
        K("-nosound", "Без звука (встречается во многих играх)", Generic),
        K("-skipintro", "Пропустить интро (встречается в некоторых играх)", Generic),
        K("-safemode", "Безопасный режим графики (встречается в некоторых играх)", Generic),
    };

    public static Dictionary<string, KnownArg> BuildLookup(EngineMask engine)
    {
        var dict = new Dictionary<string, KnownArg>(StringComparer.OrdinalIgnoreCase);

        IEnumerable<KnownArg> ordered = engine == EngineMask.All
            ? All.Where(k => k.Engines.HasFlag(Generic)).Concat(All.Where(k => !k.Engines.HasFlag(Generic)))
            : All;
        foreach (var k in ordered)
        {
            if ((k.Engines & engine) == 0 && !k.Engines.HasFlag(Generic)) continue;
            dict.TryAdd(k.Name, k);
        }
        return dict;
    }

    public static Dictionary<string, KnownArg> BuildBareLookup(Dictionary<string, KnownArg> lookup)
    {
        var dict = new Dictionary<string, KnownArg>(StringComparer.OrdinalIgnoreCase);
        foreach (var k in lookup.Values)
        {
            var bare = k.BareName;
            if (bare.Length < 4) continue;
            dict.TryAdd(bare, k);
            var trimmed = bare.TrimEnd('=', ':');
            if (trimmed.Length >= 4 && trimmed != bare) dict.TryAdd(trimmed, k);
        }
        return dict;
    }

    public static IEnumerable<string> EngineFilterNames => new[]
    {
        "Все движки", "Unreal Engine 3", "Unreal Engine 4/5", "Unity", "Source", "Source 2", "Godot", "CryEngine", "Общие"
    };

    public static EngineMask EngineFilterMask(int index) => index switch
    {
        1 => Unreal3,
        2 => UnrealModern,
        3 => Unity,
        4 => Source,
        5 => Source2,
        6 => Godot,
        7 => CryEngine,
        8 => Generic,
        _ => EngineMask.All
    };
}

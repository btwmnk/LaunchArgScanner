using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using UAssetAPI;
using UAssetAPI.UnrealTypes;

namespace LaunchArgScanner.Core;

public sealed class PropNode
{
    internal object Pd = null!;
    public string Name = "";
    public string Type = "";
    public string Value = "";
    public bool Editable;
    public string NameType => Name + "  :  " + Type;
}

public sealed class ExportNode
{
    internal object Exp = null!;
    public string Name = "";
    public string ClassName = "";
    public List<PropNode> Props = new();
    public string Label => Name + "   (" + ClassName + ")   ·   свойств: " + Props.Count;
}

public sealed class NameNode
{
    public int Index;
    public string Name = "";
    public string IndexText => Index.ToString();
}

public sealed class ImportNode
{
    public string Name = "";
    public string ClassName = "";
}

public sealed class EditSession
{
    internal object Asset = null!;
    public string Path = "";
    public bool Editable;
    public List<ExportNode> Exports = new();
    public List<NameNode> Names = new();
    public List<ImportNode> Imports = new();
}

public static class UAssetEditor
{
    public static EngineVersion MapVersion(int comboIndex) => comboIndex switch
    {
        1 => EngineVersion.VER_UE4_12,
        2 => EngineVersion.VER_UE4_16,
        3 => EngineVersion.VER_UE4_19,
        4 => EngineVersion.VER_UE4_21,
        5 => EngineVersion.VER_UE4_25,
        6 => EngineVersion.VER_UE5_0,
        7 => EngineVersion.VER_UE5_1,
        8 => EngineVersion.VER_UE5_4,
        _ => EngineVersion.UNKNOWN
    };

    public static EditSession Load(string path, int versionIndex)
    {
        var asset = new UAsset(path, MapVersion(versionIndex));
        var s = new EditSession { Asset = asset, Path = path, Editable = true };

        var names = asset.GetNameMapIndexList();
        for (int i = 0; i < names.Count; i++)
            s.Names.Add(new NameNode { Index = i, Name = names[i]?.ToString() ?? "" });

        foreach (var imp in asset.Imports)
            s.Imports.Add(new ImportNode { Name = MemberStr(imp, "ObjectName"), ClassName = MemberStr(imp, "ClassName") });

        foreach (var exp in asset.Exports)
        {
            var en = new ExportNode { Exp = exp, Name = MemberStr(exp, "ObjectName"), ClassName = ExportClass(exp) };
            var data = GetMemberValue(exp, "Data") as IEnumerable;
            if (data != null)
                foreach (var pd in data)
                    if (pd != null) en.Props.Add(MakeProp(pd));
            s.Exports.Add(en);
        }
        return s;
    }

    public static bool SetName(EditSession s, int index, string val, out string err)
    {
        err = "";
        try
        {
            var m = s.Asset.GetType().GetMethod("SetNameReference");
            m!.Invoke(s.Asset, new object[] { index, new FString(val) });
            foreach (var n in s.Names) if (n.Index == index) n.Name = val;
            return true;
        }
        catch (Exception ex) { err = ex.Message; return false; }
    }

    public static bool SetProp(PropNode p, string val, out string err)
    {
        err = "";
        try
        {
            var (mi, t) = ValueMember(p.Pd);
            if (mi == null || t == null) { err = "у этого свойства нельзя менять значение здесь"; return false; }

            object converted;
            if (t == typeof(FString)) converted = new FString(val);
            else if (t == typeof(bool)) converted = val.Trim().ToLowerInvariant() is "true" or "1" or "да";
            else if (t.IsEnum) converted = Enum.Parse(t, val, true);
            else converted = Convert.ChangeType(val, t, CultureInfo.InvariantCulture);

            SetMember(p.Pd, mi, converted);
            p.Value = ValueToStr(GetMember(p.Pd, mi));
            return true;
        }
        catch (Exception ex) { err = ex.Message; return false; }
    }

    public static void Save(EditSession s, string outPath)
    {
        var m = s.Asset.GetType().GetMethod("Write", new[] { typeof(string) });
        m!.Invoke(s.Asset, new object[] { outPath });
    }

    private static PropNode MakeProp(object pd)
    {
        var node = new PropNode
        {
            Pd = pd,
            Name = MemberStr(pd, "Name"),
            Type = MemberStr(pd, "PropertyType")
        };
        var (mi, t) = ValueMember(pd);
        if (mi != null && t != null)
        {
            node.Value = ValueToStr(GetMember(pd, mi));
            node.Editable = t == typeof(FString) || t == typeof(string) || t == typeof(bool) || t.IsEnum
                || t == typeof(int) || t == typeof(uint) || t == typeof(long) || t == typeof(ulong)
                || t == typeof(short) || t == typeof(ushort) || t == typeof(byte) || t == typeof(sbyte)
                || t == typeof(float) || t == typeof(double);
        }
        else
        {
            node.Value = "(составное значение)";
        }
        return node;
    }

    private static string ExportClass(object exp)
    {
        try
        {
            var m = exp.GetType().GetMethod("GetExportClassType", Type.EmptyTypes);
            var r = m?.Invoke(exp, null);
            var str = r?.ToString();
            if (!string.IsNullOrEmpty(str)) return str;
        }
        catch { }
        return "";
    }

    private static (MemberInfo?, Type?) ValueMember(object pd)
    {
        var f = pd.GetType().GetField("Value");
        if (f != null) return (f, f.FieldType);
        var p = pd.GetType().GetProperty("Value");
        if (p != null && p.CanRead && p.CanWrite) return (p, p.PropertyType);
        return (null, null);
    }

    private static object? GetMember(object obj, MemberInfo mi)
        => mi is FieldInfo f ? f.GetValue(obj) : ((PropertyInfo)mi).GetValue(obj);

    private static void SetMember(object obj, MemberInfo mi, object? val)
    {
        if (mi is FieldInfo f) f.SetValue(obj, val);
        else ((PropertyInfo)mi).SetValue(obj, val);
    }

    private static object? GetMemberValue(object obj, string name)
    {
        var f = obj.GetType().GetField(name);
        if (f != null) return f.GetValue(obj);
        var p = obj.GetType().GetProperty(name);
        return p?.GetValue(obj);
    }

    private static string MemberStr(object obj, string name)
    {
        try { return GetMemberValue(obj, name)?.ToString() ?? ""; }
        catch { return ""; }
    }

    private static string ValueToStr(object? v) => v?.ToString() ?? "";
}

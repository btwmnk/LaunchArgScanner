using System;
using System.Runtime.InteropServices;

namespace LaunchArgScanner.Core;

public static class Win32Dialogs
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct OpenFileName
    {
        public int lStructSize;
        public IntPtr hwndOwner;
        public IntPtr hInstance;
        public string? lpstrFilter;
        public string? lpstrCustomFilter;
        public int nMaxCustFilter;
        public int nFilterIndex;
        public IntPtr lpstrFile;
        public int nMaxFile;
        public string? lpstrFileTitle;
        public int nMaxFileTitle;
        public string? lpstrInitialDir;
        public string? lpstrTitle;
        public int Flags;
        public short nFileOffset;
        public short nFileExtension;
        public string? lpstrDefExt;
        public IntPtr lCustData;
        public IntPtr lpfnHook;
        public string? lpTemplateName;
        public IntPtr pvReserved;
        public int dwReserved;
        public int FlagsEx;
    }

    [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetOpenFileNameW(ref OpenFileName ofn);

    [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetSaveFileNameW(ref OpenFileName ofn);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct BrowseInfo
    {
        public IntPtr hwndOwner;
        public IntPtr pidlRoot;
        public IntPtr pszDisplayName;
        public string? lpszTitle;
        public uint ulFlags;
        public IntPtr lpfn;
        public IntPtr lParam;
        public int iImage;
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SHBrowseForFolderW(ref BrowseInfo bi);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern bool SHGetPathFromIDListW(IntPtr pidl, IntPtr pszPath);

    [DllImport("ole32.dll")]
    private static extern void CoTaskMemFree(IntPtr pv);

    private const int OFN_FILEMUSTEXIST = 0x1000;
    private const int OFN_PATHMUSTEXIST = 0x0800;
    private const int OFN_OVERWRITEPROMPT = 0x0002;
    private const int OFN_EXPLORER = 0x00080000;
    private const int OFN_NOCHANGEDIR = 0x00000008;
    private const uint BIF_RETURNONLYFSDIRS = 0x0001;
    private const uint BIF_NEWDIALOGSTYLE = 0x0040;

    public static string? OpenFile(IntPtr owner, string filterName, string filterPattern)
    {
        int cap = 4096;
        IntPtr buf = Marshal.AllocHGlobal(cap * 2);
        try
        {
            for (int i = 0; i < cap; i++) Marshal.WriteInt16(buf, i * 2, 0);
            var ofn = new OpenFileName
            {
                lStructSize = Marshal.SizeOf<OpenFileName>(),
                hwndOwner = owner,
                lpstrFilter = filterName + "\0" + filterPattern + "\0Все файлы (*.*)\0*.*\0\0",
                lpstrFile = buf,
                nMaxFile = cap,
                Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER | OFN_NOCHANGEDIR
            };
            if (!GetOpenFileNameW(ref ofn)) return null;
            var s = Marshal.PtrToStringUni(buf);
            return string.IsNullOrEmpty(s) ? null : s;
        }
        finally { Marshal.FreeHGlobal(buf); }
    }

    public static string? SaveFile(IntPtr owner, string filterName, string filterPattern, string defExt, string suggestedName)
    {
        int cap = 4096;
        IntPtr buf = Marshal.AllocHGlobal(cap * 2);
        try
        {
            for (int i = 0; i < cap; i++) Marshal.WriteInt16(buf, i * 2, 0);
            var start = suggestedName ?? "";
            for (int i = 0; i < start.Length && i < cap - 1; i++) Marshal.WriteInt16(buf, i * 2, start[i]);

            var ofn = new OpenFileName
            {
                lStructSize = Marshal.SizeOf<OpenFileName>(),
                hwndOwner = owner,
                lpstrFilter = filterName + "\0" + filterPattern + "\0Все файлы (*.*)\0*.*\0\0",
                lpstrFile = buf,
                nMaxFile = cap,
                lpstrDefExt = defExt,
                Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_EXPLORER | OFN_NOCHANGEDIR
            };
            if (!GetSaveFileNameW(ref ofn)) return null;
            var s = Marshal.PtrToStringUni(buf);
            return string.IsNullOrEmpty(s) ? null : s;
        }
        finally { Marshal.FreeHGlobal(buf); }
    }

    public static string? PickFolder(IntPtr owner, string title)
    {
        IntPtr pszPath = Marshal.AllocHGlobal(260 * 2);
        try
        {
            var bi = new BrowseInfo
            {
                hwndOwner = owner,
                lpszTitle = title,
                ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE
            };
            IntPtr pidl = SHBrowseForFolderW(ref bi);
            if (pidl == IntPtr.Zero) return null;
            try
            {
                if (!SHGetPathFromIDListW(pidl, pszPath)) return null;
                var s = Marshal.PtrToStringUni(pszPath);
                return string.IsNullOrEmpty(s) ? null : s;
            }
            finally { CoTaskMemFree(pidl); }
        }
        finally { Marshal.FreeHGlobal(pszPath); }
    }
}

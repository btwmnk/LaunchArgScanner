using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace LaunchArgScanner.Core;

public static class EngineDetector
{
    private static readonly string[] NonGameExeHints =
    {
        "crash", "unins", "setup", "redist", "vc_redist", "dxsetup", "prereq", "uploader",
        "easyanticheat", "battleye", "beservice", "eac_", "cefprocess", "webhelper", "dotnet",
        "unitycrashhandler", "ue4prereq", "ueprereq", "reporter", "updater", "touchup", "cleanup"
    };

    public static string NormalizeRoot(string path)
    {
        string dir = File.Exists(path) ? Path.GetDirectoryName(path)! : path;
        dir = Path.TrimEndingDirectorySeparator(Path.GetFullPath(dir));

        var d = new DirectoryInfo(dir);

        if (d.Parent is { } p1 && p1.Name.Equals("Binaries", StringComparison.OrdinalIgnoreCase) && p1.Parent is { } project)
        {
            d = project;

            if (d.Parent is { } root && Directory.Exists(Path.Combine(root.FullName, "Engine")))
                d = root;
        }
        return d.FullName;
    }

    public static string? FindMainExe(string root, IReadOnlyList<string> files)
    {
        var exes = files
            .Where(f => f.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            .Where(f => !NonGameExeHints.Any(h => Path.GetFileName(f).Contains(h, StringComparison.OrdinalIgnoreCase)))
            .Where(f => !f.Contains(@"\Engine\Binaries\ThirdParty\", StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (exes.Count == 0) return null;

        var unityPlayer = files.FirstOrDefault(f => Path.GetFileName(f).Equals("UnityPlayer.dll", StringComparison.OrdinalIgnoreCase));
        if (unityPlayer != null)
        {
            var dir = Path.GetDirectoryName(unityPlayer);
            var ue = exes.Where(e => string.Equals(Path.GetDirectoryName(e), dir, StringComparison.OrdinalIgnoreCase))
                         .OrderByDescending(SafeSize).FirstOrDefault();
            if (ue != null) return ue;
        }

        var rootExe = exes.Where(e => string.Equals(Path.GetDirectoryName(e), root, StringComparison.OrdinalIgnoreCase))
                          .OrderByDescending(SafeSize).FirstOrDefault();
        if (rootExe != null) return rootExe;

        var shipping = exes.FirstOrDefault(e => e.Contains("-Shipping", StringComparison.OrdinalIgnoreCase));
        if (shipping != null) return shipping;

        return exes.OrderBy(e => e.Count(c => c == Path.DirectorySeparatorChar)).ThenByDescending(SafeSize).First();
    }

    public static EngineInfo Detect(string root, IReadOnlyList<string> files, string? mainExe)
    {
        var info = new EngineInfo();
        bool Has(Func<string, bool> pred) => files.Any(pred);
        static string N(string f) => Path.GetFileName(f);
        static bool Eq(string a, string b) => a.Equals(b, StringComparison.OrdinalIgnoreCase);
        static bool Contains(string a, string b) => a.Contains(b, StringComparison.OrdinalIgnoreCase);

        var unityPlayer = files.FirstOrDefault(f => Eq(N(f), "UnityPlayer.dll"));
        if (unityPlayer != null || Has(f => Contains(f, "_Data\\globalgamemanagers") || Contains(f, "_Data\\data.unity3d")))
        {
            info.Family = EngineFamily.Unity;
            info.Evidence.Add(unityPlayer != null ? "UnityPlayer.dll" : "*_Data\\globalgamemanagers");
            if (Has(f => Eq(N(f), "GameAssembly.dll") || Eq(N(f), "global-metadata.dat")))
            {
                info.Variant = "IL2CPP";
                info.Evidence.Add("GameAssembly.dll / global-metadata.dat");
            }
            else if (Has(f => Eq(N(f), "Assembly-CSharp.dll")))
            {
                info.Variant = "Mono";
                info.Evidence.Add("Managed\\Assembly-CSharp.dll");
            }
            if (unityPlayer != null)
            {
                var v = TryVersion(unityPlayer, product: true);
                if (!string.IsNullOrWhiteSpace(v)) info.Version = v;
            }
            return info;
        }

        if (Has(f => Contains(f, "\\CookedPC\\") || Contains(f, "\\CookedPCConsole\\") || f.EndsWith(".upk", StringComparison.OrdinalIgnoreCase)))
        {
            info.Family = EngineFamily.Unreal;
            info.UnrealMajor = 3;
            info.Evidence.Add("CookedPC / *.upk");
            return info;
        }

        var paks = Has(f => Contains(f, "\\Content\\Paks\\") && (f.EndsWith(".pak", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".utoc", StringComparison.OrdinalIgnoreCase)));
        var shipping = Has(f => N(f).EndsWith("-Shipping.exe", StringComparison.OrdinalIgnoreCase));
        if (paks || shipping || Directory.Exists(Path.Combine(root, "Engine", "Binaries")))
        {
            info.Family = EngineFamily.Unreal;
            if (paks) info.Evidence.Add("Content\\Paks\\*.pak");
            if (shipping) info.Evidence.Add("*-Shipping.exe");
            if (Has(f => f.EndsWith(".utoc", StringComparison.OrdinalIgnoreCase))) info.Evidence.Add("IoStore (*.utoc) → UE4.26+/UE5");
            return info;
        }

        if (Has(f => Eq(N(f), "engine2.dll")))
        {
            info.Family = EngineFamily.Source2;
            info.Evidence.Add("engine2.dll");
            return info;
        }

        if (Has(f => Eq(N(f), "engine.dll") && Contains(f, "\\bin\\")) && Has(f => f.EndsWith(".vpk", StringComparison.OrdinalIgnoreCase) || Eq(N(f), "gameinfo.txt")))
        {
            info.Family = EngineFamily.Source;
            info.Evidence.Add("bin\\engine.dll + *.vpk/gameinfo.txt");
            return info;
        }

        if (Has(f => Eq(N(f), "CrySystem.dll")))
        {
            info.Family = EngineFamily.CryEngine;
            info.Evidence.Add("CrySystem.dll");
            return info;
        }

        if (mainExe != null)
        {
            try
            {
                var vi = FileVersionInfo.GetVersionInfo(mainExe);
                if (Contains(vi.ProductName ?? "", "Godot") || Contains(vi.FileDescription ?? "", "Godot"))
                {
                    info.Family = EngineFamily.Godot;
                    info.Version = vi.ProductVersion;
                    info.Evidence.Add("ProductName = Godot");
                    return info;
                }
            }
            catch {  }

            var pck = Path.ChangeExtension(mainExe, ".pck");
            if (File.Exists(pck))
            {
                info.Family = EngineFamily.Godot;
                info.Evidence.Add(Path.GetFileName(pck));
                return info;
            }
        }

        return info;
    }

    private static long SafeSize(string f)
    {
        try { return new FileInfo(f).Length; } catch { return 0; }
    }

    private static string? TryVersion(string file, bool product)
    {
        try
        {
            var vi = FileVersionInfo.GetVersionInfo(file);
            var v = product ? vi.ProductVersion : vi.FileVersion;
            return string.IsNullOrWhiteSpace(v) ? null : v.Split(' ')[0].Trim();
        }
        catch { return null; }
    }
}

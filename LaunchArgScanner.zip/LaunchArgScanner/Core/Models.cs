using System;
using System.Collections.Generic;
using System.Linq;

namespace LaunchArgScanner.Core;

public enum EngineFamily { Unknown, Unreal, Unity, Source, Source2, Godot, CryEngine }

[Flags]
public enum EngineMask
{
    None = 0,
    Generic = 1,
    Unreal3 = 2,
    UnrealModern = 4,
    Unity = 8,
    Source = 16,
    Source2 = 32,
    Godot = 64,
    CryEngine = 128,
    Unreal = Unreal3 | UnrealModern,
    AnySource = Source | Source2,
    All = 0xFFFF
}

public enum Confidence { NotFound = 0, Low = 1, Medium = 2, High = 3 }

public enum ArgCategory
{
    Known,
    Prefixed,
    HelpText,
    ValueKey,
    CVar,
    ConsoleCommand,
    ConfigKey,
    Map,
    Culture,
    Dependency,
    BuildInfo,
    Endpoint,
    Network
}

public sealed class EngineInfo
{
    public EngineFamily Family { get; set; } = EngineFamily.Unknown;
    public int? UnrealMajor { get; set; }
    public string? Version { get; set; }
    public string? Variant { get; set; }
    public List<string> Evidence { get; } = new();

    public EngineMask Mask => Family switch
    {
        EngineFamily.Unreal => UnrealMajor switch
        {
            3 => EngineMask.Unreal3,
            4 or 5 => EngineMask.UnrealModern,
            _ => EngineMask.Unreal
        },
        EngineFamily.Unity => EngineMask.Unity,
        EngineFamily.Source => EngineMask.Source,
        EngineFamily.Source2 => EngineMask.Source2,
        EngineFamily.Godot => EngineMask.Godot,
        EngineFamily.CryEngine => EngineMask.CryEngine,
        _ => EngineMask.All
    };

    public string DisplayName
    {
        get
        {
            string name = Family switch
            {
                EngineFamily.Unreal => UnrealMajor is int m ? $"Unreal Engine {m}" : "Unreal Engine",
                EngineFamily.Unity => "Unity",
                EngineFamily.Source => "Source",
                EngineFamily.Source2 => "Source 2",
                EngineFamily.Godot => "Godot",
                EngineFamily.CryEngine => "CryEngine",
                _ => "Не определён"
            };
            if (!string.IsNullOrEmpty(Version)) name += " " + Version;
            if (!string.IsNullOrEmpty(Variant)) name += $" ({Variant})";
            return name;
        }
    }
}

public sealed class KnownArg
{
    public KnownArg(string name, string description, EngineMask engines, string? valueHint = null)
    {
        Name = name;
        Description = description;
        Engines = engines;
        ValueHint = valueHint;
    }

    public string Name { get; }
    public string Description { get; }
    public EngineMask Engines { get; }
    public string? ValueHint { get; }

    public string BareName => Name.TrimStart('-', '+');

    public string NameWithHint => ValueHint is null ? Name : $"{Name} {ValueHint}";

    public string EnginesText
    {
        get
        {
            var parts = new List<string>();
            if (Engines.HasFlag(EngineMask.Unreal3) && Engines.HasFlag(EngineMask.UnrealModern)) parts.Add("Unreal 3/4/5");
            else if (Engines.HasFlag(EngineMask.Unreal3)) parts.Add("Unreal 3");
            else if (Engines.HasFlag(EngineMask.UnrealModern)) parts.Add("Unreal 4/5");
            if (Engines.HasFlag(EngineMask.Unity)) parts.Add("Unity");
            if (Engines.HasFlag(EngineMask.Source)) parts.Add("Source");
            if (Engines.HasFlag(EngineMask.Source2)) parts.Add("Source 2");
            if (Engines.HasFlag(EngineMask.Godot)) parts.Add("Godot");
            if (Engines.HasFlag(EngineMask.CryEngine)) parts.Add("CryEngine");
            if (Engines.HasFlag(EngineMask.Generic)) parts.Add("Общие");
            return string.Join(", ", parts);
        }
    }
}

public sealed class ArgCandidate
{
    public string Arg { get; set; } = "";
    public ArgCategory Category { get; set; }
    public Confidence Confidence { get; set; }
    public string Description { get; set; } = "";
    public string? ValueHint { get; set; }
    public int Hits { get; set; }
    public HashSet<string> Sources { get; } = new(StringComparer.OrdinalIgnoreCase);

    public bool VerifiedByCode { get; set; }

    public int CodeCallSites { get; set; }

    public bool IsValueParam { get; set; }

    public string? CodeEvidence { get; set; }

    public bool SeenAtRuntime { get; set; }

    public bool FromGameFiles { get; set; }

    public bool IsExact => VerifiedByCode || FromGameFiles;

    public string ConfidenceText
    {
        get
        {
            if (VerifiedByCode) return "Проверено кодом";
            if (FromGameFiles) return "Из файлов игры";
            if (SeenAtRuntime) return "Видно при запуске";
            return Confidence switch
            {
                Confidence.High => "Высокая",
                Confidence.Medium => "Средняя",
                Confidence.Low => "Низкая",
                _ => "Не найден"
            };
        }
    }

    public int Rank => VerifiedByCode ? 6 : FromGameFiles ? 5 : SeenAtRuntime ? 4 : (int)Confidence;

    public string CategoryText => Category switch
    {
        ArgCategory.Known => "Известный",
        ArgCategory.Prefixed => "Флаг",
        ArgCategory.HelpText => "Из справки",
        ArgCategory.ValueKey => "Параметр=",
        ArgCategory.CVar => "CVar",
        ArgCategory.ConsoleCommand => "Команда",
        ArgCategory.ConfigKey => "Конфиг",
        ArgCategory.Map => "Карта",
        ArgCategory.Culture => "Язык",
        ArgCategory.Dependency => "Зависимость",
        ArgCategory.BuildInfo => "Сборка",
        ArgCategory.Endpoint => "Адрес",
        ArgCategory.Network => "Сеть",
        _ => ""
    };

    public string ArgWithHint => ValueHint is null ? Arg : $"{Arg} {ValueHint}";

    public string SourcesText
    {
        get
        {
            if (Sources.Count == 0) return Confidence == Confidence.NotFound ? "в файлах игры не найден" : "—";
            var first = string.Join(", ", Sources.Take(3));
            return Sources.Count > 3 ? $"{first} +{Sources.Count - 3}" : first;
        }
    }
}

public sealed class ScanOptions
{
    public bool SkipThirdParty { get; set; } = true;
    public bool IncludeCVars { get; set; }
    public bool IncludeValueKeys { get; set; } = true;
    public bool IncludeHelpText { get; set; } = true;
    public long MaxFileSize { get; set; } = 1_900_000_000;

    public bool AnalyzeCode { get; set; } = true;

    public long MaxCodeAnalysisSize { get; set; } = 400_000_000;
}

public readonly record struct ScanProgress(int Current, int Total, string FileName)
{
    public double Percent => Total == 0 ? 0 : Current * 100.0 / Total;
}

public sealed class ScanResult
{
    public string Root { get; set; } = "";
    public EngineInfo Engine { get; set; } = new();
    public string? MainExe { get; set; }
    public string? SteamAppId { get; set; }
    public string? SteamGameName { get; set; }
    public List<ArgCandidate> Candidates { get; set; } = new();
    public int FilesScanned { get; set; }
    public long BytesScanned { get; set; }
    public List<string> SkippedFiles { get; } = new();
    public TimeSpan Elapsed { get; set; }

    public int VerifiedByCode { get; set; }

    public bool CodeAnalysisRan { get; set; }

    public string? CodeAnalysisNote { get; set; }
}

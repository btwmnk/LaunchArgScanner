using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using Iced.Intel;

namespace LaunchArgScanner.Core;

public static partial class CodeAnalyzer
{
    [GeneratedRegex(@"^[A-Za-z][A-Za-z0-9_\-]{1,40}=?$")]
    private static partial Regex FlagLikeRx();

    [GeneratedRegex(@"^[A-Za-z][A-Za-z0-9]{0,24}\.[A-Za-z0-9_.]{2,60}$")]
    private static partial Regex CVarNameRx();

    [GeneratedRegex(@"^[A-Za-z][A-Za-z0-9_]{2,40}$")]
    private static partial Regex CmdNameRx();

    public sealed class CodeArg
    {
        public string Arg = "";
        public int CallSites;
        public bool IsValue;
        public bool IsCVar;
        public bool IsCommand;
        public string? Help;
        public ulong CallVa;
        public string? Evidence;
        public HashSet<string> Files = new(StringComparer.OrdinalIgnoreCase);
    }

    public sealed class Result
    {
        public bool Ran;
        public string? Note;
        public int Switches;
        public int CVars;
        public Dictionary<string, CodeArg> ByArg = new(StringComparer.OrdinalIgnoreCase);
    }

    public static Result Analyze(IReadOnlyList<(string rel, byte[] data)> files,
                                 Dictionary<string, KnownArg> bareLookup,
                                 Action<string>? status,
                                 CancellationToken ct)
    {
        var result = new Result();
        var known = new HashSet<string>(bareLookup.Keys, StringComparer.OrdinalIgnoreCase);
        int analysed = 0;

        foreach (var (rel, data) in files)
        {
            ct.ThrowIfCancellationRequested();
            if (!PeImage.TryParse(data, out var pe) || !pe.Is64Bit)
                continue;

            status?.Invoke("Анализ кода: " + rel);
            try
            {
                AnalyseFile(pe, rel, known, result, ct);
                analysed++;
            }
            catch (OperationCanceledException) { throw; }
            catch {  }
        }

        result.Switches = result.ByArg.Values.Count(a => !a.IsCVar);
        result.CVars = result.ByArg.Values.Count(a => a.IsCVar);
        result.Ran = analysed > 0 && result.ByArg.Count > 0;
        if (analysed == 0)
            result.Note = "Код не удалось разобрать (нет 64-битного кода или бинарник упакован).";
        else if (result.ByArg.Count == 0)
            result.Note = "Код разобран, но функции разбора параметров не распознаны (возможно, движок не нативный, как Unity Mono).";
        return result;
    }

    private sealed class Snap
    {
        public string?[] Regs = new string?[4];
        public ulong[] LeaIp = new ulong[4];
        public ulong CallIp;
    }

    private static void AnalyseFile(PeImage pe, string rel, HashSet<string> known, Result result, CancellationToken ct)
    {

        var byTarget = new Dictionary<ulong, List<Snap>>();

        foreach (var sec in pe.Sections)
        {
            if (!sec.IsExecutable) continue;
            var bytes = pe.SectionBytes(sec);
            if (bytes.IsEmpty) continue;

            ulong ip = pe.ImageBase + sec.VirtualAddress;
            var reader = new ByteArrayCodeReader(bytes.ToArray());
            var decoder = Decoder.Create(64, reader, ip);

            string?[] regStr = new string?[4];
            ulong[] regLeaIp = new ulong[4];
            long counter = 0;

            while (reader.CanReadByte)
            {
                decoder.Decode(out var instr);
                if ((++counter & 0x3FFFFF) == 0) ct.ThrowIfCancellationRequested();
                if (instr.Code == Code.INVALID) continue;

                if (instr.Mnemonic == Mnemonic.Lea &&
                    instr.Op0Kind == OpKind.Register &&
                    instr.IsIPRelativeMemoryOperand)
                {
                    int idx = ArgRegIndex(instr.Op0Register.GetFullRegister());
                    if (idx >= 0)
                    {
                        regStr[idx] = pe.ReadStringAtVa(instr.IPRelativeMemoryAddress);
                        regLeaIp[idx] = instr.IP;
                    }
                    continue;
                }

                if (instr.Op0Kind == OpKind.Register)
                {
                    int idx = ArgRegIndex(instr.Op0Register.GetFullRegister());
                    if (idx >= 0) regStr[idx] = null;
                }

                if (instr.FlowControl is FlowControl.Call or FlowControl.IndirectCall &&
                    instr.Op0Kind == OpKind.NearBranch64)
                {
                    if (regStr[0] == null && regStr[1] == null && regStr[2] == null && regStr[3] == null)
                        continue;
                    ulong target = instr.NearBranchTarget;
                    if (!byTarget.TryGetValue(target, out var list))
                        byTarget[target] = list = new List<Snap>();
                    if (list.Count < 8000)
                        list.Add(new Snap { Regs = (string?[])regStr.Clone(), LeaIp = (ulong[])regLeaIp.Clone(), CallIp = instr.IP });
                }
            }
        }

        ExtractSwitches(byTarget, known, rel, result, pe);
        ExtractConsole(byTarget, rel, result, pe);
    }

    private static string? FormatAt(PeImage pe, ulong va)
    {
        try
        {
            if (!pe.TryVaToOffset(va, out int off)) return null;
            var slice = pe.RawSlice(off, 16);
            if (slice.Length == 0) return null;
            var reader = new ByteArrayCodeReader(slice);
            var decoder = Decoder.Create(64, reader, va);
            decoder.Decode(out var instr);
            var fmt = new NasmFormatter();
            var output = new StringOutput();
            fmt.Format(instr, output);
            return $"0x{va:X}  {output.ToStringAndReset()}";
        }
        catch { return null; }
    }

    private static string? BuildEvidence(PeImage pe, Snap snap, int regIdx)
    {
        var parts = new List<string>();
        if (snap.LeaIp[regIdx] != 0) { var l = FormatAt(pe, snap.LeaIp[regIdx]); if (l != null) parts.Add(l); }
        var c = FormatAt(pe, snap.CallIp); if (c != null) parts.Add(c);
        return parts.Count > 0 ? string.Join("  →  ", parts) : null;
    }

    private static void ExtractSwitches(Dictionary<ulong, List<Snap>> byTarget, HashSet<string> known, string rel, Result result, PeImage pe)
    {
        foreach (var (_, snaps) in byTarget)
        {

            var flags = snaps.Select(s => s.Regs[1] ?? s.Regs[0]).Where(s => s != null).Select(s => s!).ToList();
            if (flags.Count == 0) continue;

            var distinct = new HashSet<string>(flags, StringComparer.Ordinal);
            int knownHits = distinct.Count(s => known.Contains(Bare(s)));
            int flagLike = distinct.Count(IsFlagLike);
            bool isParser = knownHits >= 4 || (flagLike >= 12 && flagLike >= distinct.Count * 0.6);
            if (!isParser) continue;

            int withEq = distinct.Count(s => s.EndsWith('='));
            bool valueParser = distinct.Count > 0 && withEq >= distinct.Count * 0.5;

            foreach (var str in distinct)
            {
                if (!IsFlagLike(str)) continue;
                var arg = Normalize(str);
                if (!result.ByArg.TryGetValue(arg, out var ca))
                    result.ByArg[arg] = ca = new CodeArg { Arg = arg };
                ca.CallSites += flags.Count(f => f == str);
                ca.Files.Add(rel);
                if (str.EndsWith('=') || valueParser) ca.IsValue = true;

                if (ca.CallVa == 0)
                {
                    var snap = snaps.FirstOrDefault(s => (s.Regs[1] ?? s.Regs[0]) == str);
                    if (snap != null)
                    {
                        int ri = snap.Regs[1] == str ? 1 : 0;
                        ca.CallVa = snap.CallIp;
                        ca.Evidence = BuildEvidence(pe, snap, ri);
                    }
                }
            }
        }
    }

    private static void ExtractConsole(Dictionary<ulong, List<Snap>> byTarget, string rel, Result result, PeImage pe)
    {
        foreach (var (_, snaps) in byTarget)
        {

            var pairs = new List<(string name, string? help, bool isCvar, int nameIdx, Snap snap)>();
            foreach (var s in snaps)
            {
                var pair = FindNamedPair(s.Regs);
                if (pair != null) pairs.Add((pair.Value.name, pair.Value.help, pair.Value.isCvar, pair.Value.nameIdx, s));
            }
            if (pairs.Count == 0) continue;

            int cvarNames = pairs.Count(p => p.isCvar);
            var distinct = pairs.Select(p => p.name).Distinct(StringComparer.OrdinalIgnoreCase).Count();

            bool cvarReg = cvarNames >= 8 && distinct >= 8;
            bool cmdReg = !cvarReg && pairs.Count(p => !p.isCvar) >= 12 && distinct >= 12;
            if (!cvarReg && !cmdReg) continue;

            foreach (var (name, help, isCvar, nameIdx, snap) in pairs)
            {
                if (cvarReg && !isCvar) continue;
                if (cmdReg && isCvar) continue;
                if (!result.ByArg.TryGetValue(name, out var ca))
                    result.ByArg[name] = ca = new CodeArg { Arg = name };
                ca.IsCVar = isCvar;
                ca.IsCommand = !isCvar;
                ca.IsValue = isCvar;
                ca.CallSites++;
                ca.Files.Add(rel);
                if (ca.Help == null && !string.IsNullOrWhiteSpace(help)) ca.Help = help!.Trim();
                if (ca.CallVa == 0)
                {
                    ca.CallVa = snap.CallIp;
                    ca.Evidence = BuildEvidence(pe, snap, nameIdx);
                }
            }
        }
    }

    private static (string name, string? help, bool isCvar, int nameIdx)? FindNamedPair(string?[] snap)
    {
        string? name = null, help = null;
        bool isCvar = false;
        int nameIdx = 0;
        for (int i = 0; i < snap.Length; i++)
        {
            var s = snap[i];
            if (s == null) continue;
            if (IsHelpSentence(s)) { if (help == null || s.Length > help.Length) help = s; continue; }
            if (name == null)
            {
                if (CVarNameRx().IsMatch(s)) { name = s; isCvar = true; nameIdx = i; }
                else if (CmdNameRx().IsMatch(s)) { name = s; isCvar = false; nameIdx = i; }
            }
        }
        if (name == null) return null;
        if (!isCvar && help == null) return null;
        return (name, help, isCvar, nameIdx);
    }

    private static bool IsHelpSentence(string s)
    {
        if (s.Length < 8 || s.Length > 280) return false;
        if (s.IndexOf(' ') < 0) return false;
        if (s.IndexOf('%') >= 0) return false;
        if (!char.IsLetter(s[0])) return false;
        if (CVarNameRx().IsMatch(s)) return false;
        int letters = s.Count(char.IsLetter);
        int lower = s.Count(char.IsLower);
        return letters >= s.Length / 2 && lower >= 3;
    }

    private static int ArgRegIndex(Register full) => full switch
    {
        Register.RCX => 0,
        Register.RDX => 1,
        Register.R8 => 2,
        Register.R9 => 3,
        _ => -1
    };

    private static bool IsFlagLike(string s)
    {
        var body = Bare(s);
        if (body.Length < 2 || body.Length > 40) return false;
        if (!FlagLikeRx().IsMatch(s.TrimStart('-', '+'))) return false;
        if (body.Contains('.')) return false;
        int digits = body.Count(char.IsDigit);
        return digits * 2 <= body.Length;
    }

    private static string Bare(string s) => s.TrimStart('-', '+').TrimEnd('=', ':');

    private static string Normalize(string s)
    {
        if (s.Length == 0) return s;
        if (s[0] == '-' || s[0] == '+') return s;
        return "-" + s;
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace LaunchArgScanner.Core;

public static class SteamIntegration
{
    public sealed class WriteResult
    {
        public bool Ok;
        public string? Error;
        public string? UserConfigPath;
        public string? BackupPath;
        public string? PreviousValue;
        public string SteamUserId = "";
    }

    public static string? FindSteamPath()
    {
        try
        {
            using var k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
            if (k?.GetValue("SteamPath") is string p && p.Length > 0)
            {
                p = p.Replace('/', '\\');
                if (Directory.Exists(p)) return p;
            }
        }
        catch {  }

        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam")
                       ?? Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Valve\Steam");
            if (k?.GetValue("InstallPath") is string p && Directory.Exists(p)) return p;
        }
        catch {  }

        return null;
    }

    public static (string appId, string name)? ResolveApp(string gameRoot)
    {
        var full = Path.GetFullPath(gameRoot);
        var parts = full.Split(Path.DirectorySeparatorChar);

        int common = Array.FindIndex(parts, p => p.Equals("common", StringComparison.OrdinalIgnoreCase));
        if (common <= 0 || common + 1 >= parts.Length) return null;
        if (!parts[common - 1].Equals("steamapps", StringComparison.OrdinalIgnoreCase)) return null;

        string installDir = parts[common + 1];
        string steamapps = string.Join(Path.DirectorySeparatorChar, parts.Take(common));

        if (!Directory.Exists(steamapps)) return null;

        foreach (var acf in SafeEnumerate(steamapps, "appmanifest_*.acf"))
        {
            try
            {
                var root = Vdf.Parse(File.ReadAllText(acf)).FirstOrDefault(n => n.Key.Equals("AppState", StringComparison.OrdinalIgnoreCase));
                var dir = root?.Find("installdir")?.Value;
                if (dir != null && dir.Equals(installDir, StringComparison.OrdinalIgnoreCase))
                {
                    var appid = root!.Find("appid")?.Value ?? ExtractAppIdFromName(acf);
                    var name = root.Find("name")?.Value ?? installDir;
                    if (appid != null) return (appid, name);
                }
            }
            catch {  }
        }
        return null;
    }

    private static string? ExtractAppIdFromName(string acfPath)
    {
        var name = Path.GetFileNameWithoutExtension(acfPath);
        int us = name.LastIndexOf('_');
        return us >= 0 && us + 1 < name.Length ? name[(us + 1)..] : null;
    }

    public static List<string> FindUserConfigs()
    {
        var list = new List<string>();
        var steam = FindSteamPath();
        if (steam == null) return list;
        var userdata = Path.Combine(steam, "userdata");
        if (!Directory.Exists(userdata)) return list;

        foreach (var dir in SafeEnumerateDirs(userdata))
        {
            var cfg = Path.Combine(dir, "config", "localconfig.vdf");
            if (File.Exists(cfg)) list.Add(cfg);
        }
        return list
            .OrderByDescending(f => { try { return File.GetLastWriteTime(f); } catch { return DateTime.MinValue; } })
            .ToList();
    }

    public static string? ReadLaunchOptions(string appId)
    {
        var cfg = FindUserConfigs().FirstOrDefault();
        if (cfg == null) return null;
        try
        {
            var apps = NavigateToApps(Vdf.Parse(File.ReadAllText(cfg)), create: false);
            return apps?.Find(appId)?.Find("LaunchOptions")?.Value;
        }
        catch { return null; }
    }

    public static bool IsSteamRunning() =>
        Process.GetProcessesByName("steam").Length > 0;

    public static bool RequestSteamShutdown()
    {
        var steam = FindSteamPath();
        var exe = steam != null ? Path.Combine(steam, "steam.exe") : "steam.exe";
        try
        {
            Process.Start(new ProcessStartInfo(exe, "-shutdown") { UseShellExecute = true });
            return true;
        }
        catch { return false; }
    }

    public static WriteResult WriteLaunchOptions(string appId, string launchOptions)
    {
        var res = new WriteResult();
        if (IsSteamRunning())
        {
            res.Error = "Steam запущен. Закрой Steam — иначе он перезапишет изменения при выходе.";
            return res;
        }

        var cfg = FindUserConfigs().FirstOrDefault();
        if (cfg == null)
        {
            res.Error = "Не найден localconfig.vdf — похоже, Steam ни разу не запускался под этим пользователем.";
            return res;
        }
        res.UserConfigPath = cfg;
        res.SteamUserId = Path.GetFileName(Path.GetDirectoryName(Path.GetDirectoryName(cfg))!);

        string text;
        try { text = File.ReadAllText(cfg); }
        catch (Exception ex) { res.Error = "Не удалось прочитать конфиг: " + ex.Message; return res; }

        List<VdfNode> tree;
        try { tree = Vdf.Parse(text); }
        catch (Exception ex) { res.Error = "Не удалось разобрать конфиг Steam: " + ex.Message; return res; }

        int leavesBefore = Vdf.CountLeaves(tree);

        var apps = NavigateToApps(tree, create: true);
        if (apps == null) { res.Error = "В конфиге нет ожидаемой секции apps."; return res; }

        res.PreviousValue = apps.Find(appId)?.Find("LaunchOptions")?.Value;
        var appNode = apps.GetOrAddObject(appId);
        appNode.SetLeaf("LaunchOptions", launchOptions);

        string serialized = Vdf.Serialize(tree);
        int leavesAfter;
        try { leavesAfter = Vdf.CountLeaves(Vdf.Parse(serialized)); }
        catch (Exception ex) { res.Error = "Проверка целостности не прошла: " + ex.Message; return res; }

        bool addedApp = res.PreviousValue == null && apps.Find(appId) != null;
        int expectedDelta = res.PreviousValue == null ? (addedApp ? 2 : 1) : 0;
        if (leavesAfter < leavesBefore)
        {
            res.Error = $"Запись отменена: проверка структуры показала потерю данных ({leavesBefore}→{leavesAfter}). Файл не тронут.";
            return res;
        }
        _ = expectedDelta;

        try
        {
            var backup = cfg + ".las-backup";
            if (!File.Exists(backup)) File.Copy(cfg, backup);
            res.BackupPath = backup;

            var tmp = cfg + ".tmp";
            File.WriteAllText(tmp, serialized);
            File.Copy(tmp, cfg, overwrite: true);
            File.Delete(tmp);
            res.Ok = true;
        }
        catch (Exception ex)
        {
            res.Error = "Не удалось записать конфиг: " + ex.Message;
        }
        return res;
    }

    private static VdfNode? NavigateToApps(List<VdfNode> tree, bool create)
    {

        var store = tree.FirstOrDefault(n => n.Key.Equals("UserLocalConfigStore", StringComparison.OrdinalIgnoreCase));
        if (store == null) return null;

        VdfNode? Step(VdfNode? parent, string key)
        {
            if (parent == null) return null;
            if (create) return parent.GetOrAddObject(key);
            return parent.Find(key);
        }

        var sw = Step(store, "Software");
        var valve = Step(sw, "Valve");
        var steam = Step(valve, "Steam");
        return Step(steam, "apps");
    }

    private static IEnumerable<string> SafeEnumerate(string dir, string pattern)
    {
        try { return Directory.EnumerateFiles(dir, pattern); }
        catch { return Enumerable.Empty<string>(); }
    }

    private static IEnumerable<string> SafeEnumerateDirs(string dir)
    {
        try { return Directory.EnumerateDirectories(dir); }
        catch { return Enumerable.Empty<string>(); }
    }
}

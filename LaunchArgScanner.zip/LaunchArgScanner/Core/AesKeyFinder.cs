using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;

namespace LaunchArgScanner.Core;

public static class AesKeyFinder
{
    private const uint PakMagic = 0x5A6F12E1;

    public sealed class Candidate
    {
        public string Hex = "";
        public double Entropy;
        public bool PakProven;
        public byte[] Key = Array.Empty<byte>();
    }

    public sealed class Result
    {
        public bool Found;
        public byte[]? Key;
        public string? Hex;
        public string? Base64;
        public string? PakFile;
        public string? Note;
        public bool ProvenByPak;
        public List<Candidate> Candidates = new();
    }

    private static readonly string[] Patterns =
    {
        "C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ?",
        "C7 ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ?",
        "C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? 48 ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ?",
        "C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? ? C7 ? ? ? ? ? C3",
    };

    private static readonly int[][] DwordOffsets =
    {
        new[] { 3, 10, 17, 24, 35, 42, 49, 56 },
        new[] { 2, 9, 16, 23, 30, 37, 44, 51 },
        new[] { 3, 10, 21, 28, 35, 42, 49, 56 },
        new[] { 51, 45, 38, 31, 24, 17, 10, 3 },
    };

    private static readonly HashSet<string> FalsePositives = new(StringComparer.OrdinalIgnoreCase)
    {
        "FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9FFD9",
        "67E6096A85AE67BB72F36E3C3AF54FA57F520E518C68059BABD9831F19CDE05B",
        "D89E05C107D57C3617DD703039590EF7310BC0FF11155868A78FF964A44FFABE",
        "9A99593F9A99593F0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53BAE47A13F",
        "6F168073B9B21449D742241700068ADABC306FA9AA3831164DEE8DE34E0EFBB0",
        "0AD7633FCDCC4C3DCDCCCC3D52B8BE3F9A99593F9A99593FC9767E3FE17A543F",
        "168073C7B21449C7430C00064310BC304314AA3843184DEE431C4E0E83C4205B",
        "E6096AC7AE67BBC7430C3AF543107F5243148C684318ABD9431C19CD436C2000",
        "9E05C1C7D57C36C7430C39594310310B431411154318A78F431CA44F436C1C00",
        "9E05C1C7D57C36C7DD7030C7590EF7C70BC0FFC7155868C78FF964C7A44FFABE",
        "168073C7B21449C7422417C7068ADAC7306FA9C7383116C7EE8DE3C74E0EFBB0",
        "0AD7633FCDCC4C3D00C742143DC742183FC7421C3FC742203FC742247E3FC742",
        "0000803F0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53B54AE47A1",
        "0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53BAE47A13F58583934",
        "0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53BAE47A13F38583934",
        "0000803F0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53B34AE47A1",
        "0000803F0000803F0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D2C4260E5",
        "0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53BAE47A13F5839343C4CC9767E",
        "07D57C3617DD703039590EF7310BC0FF11155868A78FF964A44FFABE6C1C0000",
        "85AE67BB72F36E3C3AF54FA57F520E518C68059BABD9831F19CDE05B6C200000",
        "E6096AC7AE67BBC7F36E3CC7F54FA5C7520E51C768059BC7D9831FC719CDE05B",
        "0AD7A33E0AD7633F52B8BE3FE17A543FCDCC4C3D4260E53BAE47A13F3C583934",
        "E4D6E74FE4D667500044AC47926595380080DC43000A9B46000080BF000080BF",
        "D04C8F7D71ECC047D8A60970FBA31C9E9EC1250BBBF6459AC480947212E1DB8C",
    };

    public static Result Find(IReadOnlyList<string> binaryPaths, string? pakPath,
                              Action<string>? status, CancellationToken ct)
    {
        var res = new Result { PakFile = pakPath };
        var byHex = new Dictionary<string, Candidate>(StringComparer.OrdinalIgnoreCase);

        foreach (var path in binaryPaths)
        {
            ct.ThrowIfCancellationRequested();
            byte[] data;
            try
            {
                var fi = new FileInfo(path);
                if (fi.Length == 0 || fi.Length > 400_000_000) continue;
                status?.Invoke("AES: сигнатуры в " + Path.GetFileName(path) + "…");
                data = File.ReadAllBytes(path);
            }
            catch { continue; }

            foreach (var (hex, key) in SignatureScan(data, ct))
            {
                if (FalsePositives.Contains(hex)) continue;
                if (byHex.ContainsKey(hex)) continue;
                double e = Entropy(hex);
                if (e < 3.0) continue;
                byHex[hex] = new Candidate { Hex = hex, Key = key, Entropy = e };
            }
            data = Array.Empty<byte>();
        }

        byte[]? sample = null;
        string? pakNote = null;
        if (!string.IsNullOrEmpty(pakPath))
        {
            try { ReadEncryptedIndexSample(pakPath, out sample, out pakNote); }
            catch (Exception ex) { pakNote = "Pak прочитать не удалось: " + ex.Message; sample = null; }
        }
        if (sample is { Length: > 0 })
        {
            using var aes = Aes.Create();
            aes.Mode = CipherMode.ECB; aes.Padding = PaddingMode.None; aes.KeySize = 256;
            var buf = new byte[sample.Length];
            foreach (var c in byHex.Values)
            {
                if (TestKey(aes, c.Key, sample, buf)) c.PakProven = true;
            }
        }

        res.Candidates = byHex.Values
            .OrderByDescending(c => c.PakProven)
            .ThenByDescending(c => c.Entropy)
            .ToList();

        var best = res.Candidates.FirstOrDefault();
        if (best != null)
        {
            res.Found = true;
            res.Key = best.Key;
            res.Hex = "0x" + best.Hex;
            res.Base64 = Convert.ToBase64String(best.Key);
            res.ProvenByPak = best.PakProven;
            if (sample == null && pakNote != null)
                res.Note = "Pak для проверки не использован: " + pakNote;
            return res;
        }

        res.Note = "Ключ по сигнатурам не найден. Возможно: exe упакован (VMProtect/Themida/Denuvo); " +
                   "другой компилятор/версия UE (нужна новая сигнатура); ключ в DLL, которой нет среди просканированных; " +
                   "либо ключ приходит с сервера." + (pakNote != null ? " " + pakNote : "");
        return res;
    }

    private static IEnumerable<(string hex, byte[] key)> SignatureScan(byte[] data, CancellationToken ct)
    {
        for (int p = 0; p < Patterns.Length; p++)
        {
            var toks = ParsePattern(Patterns[p]);
            var offs = DwordOffsets[p];
            int len = toks.Length;
            int maxOff = offs.Max() + 4;
            int end = data.Length - Math.Max(len, maxOff);

            for (int i = 0; i <= end; i++)
            {
                if (data[i] != 0xC7) continue;
                if ((i & 0xFFFFF) == 0) ct.ThrowIfCancellationRequested();

                bool ok = true;
                for (int k = 1; k < len; k++)
                {
                    int t = toks[k];
                    if (t >= 0 && data[i + k] != t) { ok = false; break; }
                }
                if (!ok) continue;

                var sb = new System.Text.StringBuilder(64);
                var key = new byte[32];
                for (int d = 0; d < 8; d++)
                {
                    int src = i + offs[d];
                    for (int b = 0; b < 4; b++)
                    {
                        byte v = data[src + b];
                        key[d * 4 + b] = v;
                        sb.Append(v.ToString("X2"));
                    }
                }
                yield return (sb.ToString(), key);
            }
        }
    }

    private static int[] ParsePattern(string pattern)
    {
        var parts = pattern.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var toks = new int[parts.Length];
        for (int i = 0; i < parts.Length; i++)
            toks[i] = parts[i] == "?" || parts[i] == "??" ? -1 : Convert.ToInt32(parts[i], 16);
        return toks;
    }

    private static double Entropy(string s)
    {
        var freq = new Dictionary<char, int>();
        foreach (var c in s) freq[c] = freq.TryGetValue(c, out var n) ? n + 1 : 1;
        double info = 0;
        foreach (var kv in freq)
        {
            double f = (double)kv.Value / s.Length;
            info += f * Math.Log2(f);
        }
        return -info;
    }

    private static bool TestKey(Aes aes, byte[] key, byte[] sample, byte[] buf)
    {
        try
        {
            using var dec = aes.CreateDecryptor(key, null);
            dec.TransformBlock(sample, 0, sample.Length, buf, 0);
            return LooksLikeIndex(buf);
        }
        catch { return false; }
    }

    public static string Verify(string keyText, string pakPath)
    {
        if (!TryParseKey(keyText, out var key))
            return "Ключ не распознан. Нужно 64 hex-символа (можно с 0x) или base64 от 32 байт.";

        if (!ReadEncryptedIndexSample(pakPath, out var sample, out var note))
            return note ?? "Не удалось прочитать индекс pak.";

        try
        {
            using var aes = Aes.Create();
            aes.Mode = CipherMode.ECB; aes.Padding = PaddingMode.None; aes.KeySize = 256;
            var outBuf = new byte[sample.Length];
            using var dec = aes.CreateDecryptor(key, null);
            dec.TransformBlock(sample, 0, sample.Length, outBuf, 0);
            return LooksLikeIndex(outBuf)
                ? "Ключ ВЕРНЫЙ — он расшифровывает индекс этого pak (индекс зашифрован)."
                : "Ключ НЕ подошёл к индексу этого pak. Либо это не тот ключ/формат (порядок байт), либо pak другой, либо индекс не зашифрован.";
        }
        catch (Exception ex) { return "Ошибка проверки: " + ex.Message; }
    }

    public static bool TryParseKey(string text, out byte[] key)
    {
        key = Array.Empty<byte>();
        if (string.IsNullOrWhiteSpace(text)) return false;
        var t = text.Trim();
        if (t.StartsWith("0x", StringComparison.OrdinalIgnoreCase)) t = t[2..];
        t = t.Replace(" ", "").Replace("-", "");

        if (t.Length == 64 && t.All(c => HexVal((byte)c) >= 0))
        {
            var k = new byte[32];
            for (int j = 0; j < 32; j++)
                k[j] = (byte)((HexVal((byte)t[j * 2]) << 4) | HexVal((byte)t[j * 2 + 1]));
            key = k;
            return true;
        }
        try
        {
            var b = Convert.FromBase64String(text.Trim());
            if (b.Length == 32) { key = b; return true; }
        }
        catch { }
        return false;
    }

    private static bool LooksLikeIndex(byte[] dec)
    {
        if (dec.Length < 8) return false;
        int len = BinaryPrimitives.ReadInt32LittleEndian(dec);
        if (len < 2 || len > 512) return false;
        int have = Math.Min(len, dec.Length - 4);
        for (int i = 0; i < have; i++)
        {
            byte b = dec[4 + i];
            bool last = i == len - 1;
            if (last) { if (b != 0) return false; }
            else if (b < 0x20 || b >= 0x7F) return false;
        }
        return dec[4] == (byte)'.' || dec[4] == (byte)'/';
    }

    public static bool IsPakEncrypted(string pakPath)
    {
        try { return ReadEncryptedIndexSample(pakPath, out _, out _); }
        catch { return false; }
    }

    private static bool ReadEncryptedIndexSample(string pakPath, out byte[] sample, out string? note)
    {
        sample = Array.Empty<byte>();
        note = null;
        using var fs = new FileStream(pakPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        long fileLen = fs.Length;
        int tail = (int)Math.Min(1024, fileLen);
        var buf = new byte[tail];
        fs.Seek(-tail, SeekOrigin.End);
        fs.ReadExactly(buf, 0, tail);

        for (int p = tail - 4; p >= 17; p--)
        {
            if (BinaryPrimitives.ReadUInt32LittleEndian(buf.AsSpan(p)) != PakMagic) continue;
            if (p + 24 > tail) continue;
            byte encrypted = buf[p - 1];
            long indexOffset = BinaryPrimitives.ReadInt64LittleEndian(buf.AsSpan(p + 8));
            long indexSize = BinaryPrimitives.ReadInt64LittleEndian(buf.AsSpan(p + 16));
            if (indexOffset <= 0 || indexSize <= 16 || indexOffset + indexSize > fileLen) continue;

            if (encrypted == 0)
            {
                note = "Индекс этого pak не зашифрован — проверить ключ по индексу нельзя (ключ шифрует только файлы).";
                return false;
            }

            int want = (int)Math.Min(80, indexSize);
            want -= want % 16;
            if (want < 16) continue;
            sample = new byte[want];
            fs.Seek(indexOffset, SeekOrigin.Begin);
            fs.ReadExactly(sample, 0, want);
            return true;
        }

        note = "Не найден футер pak (неподдерживаемая версия или это не pak).";
        return false;
    }

    private static int HexVal(byte b) => b switch
    {
        >= (byte)'0' and <= (byte)'9' => b - '0',
        >= (byte)'a' and <= (byte)'f' => b - 'a' + 10,
        >= (byte)'A' and <= (byte)'F' => b - 'A' + 10,
        _ => -1
    };
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LaunchArgScanner.Core;

public sealed class VdfNode
{
    public string Key = "";
    public string? Value;
    public List<VdfNode>? Children;
    public bool IsObject => Children != null;

    public VdfNode? Find(string key) =>
        Children?.FirstOrDefault(c => string.Equals(c.Key, key, StringComparison.OrdinalIgnoreCase));

    public VdfNode GetOrAddObject(string key)
    {
        Children ??= new List<VdfNode>();
        var n = Find(key);
        if (n == null)
        {
            n = new VdfNode { Key = key, Children = new List<VdfNode>() };
            Children.Add(n);
        }
        else
        {
            n.Children ??= new List<VdfNode>();
            n.Value = null;
        }
        return n;
    }

    public void SetLeaf(string key, string value)
    {
        Children ??= new List<VdfNode>();
        var n = Find(key);
        if (n == null)
            Children.Add(new VdfNode { Key = key, Value = value });
        else { n.Value = value; n.Children = null; }
    }
}

public static class Vdf
{
    public static List<VdfNode> Parse(string text)
    {
        int i = 0;
        return ParseNodes(text, ref i, top: true);
    }

    private static List<VdfNode> ParseNodes(string s, ref int i, bool top)
    {
        var nodes = new List<VdfNode>();
        while (true)
        {
            SkipTrivia(s, ref i);
            if (i >= s.Length) break;
            if (s[i] == '}')
            {
                if (!top) i++;
                break;
            }

            string key = ReadToken(s, ref i);
            SkipTrivia(s, ref i);
            if (i < s.Length && s[i] == '{')
            {
                i++;
                var children = ParseNodes(s, ref i, top: false);
                nodes.Add(new VdfNode { Key = key, Children = children });
            }
            else
            {
                string val = ReadToken(s, ref i);
                nodes.Add(new VdfNode { Key = key, Value = val });
                SkipConditional(s, ref i);
            }
        }
        return nodes;
    }

    private static void SkipTrivia(string s, ref int i)
    {
        while (i < s.Length)
        {
            char c = s[i];
            if (char.IsWhiteSpace(c)) { i++; continue; }
            if (c == '/' && i + 1 < s.Length && s[i + 1] == '/')
            {
                while (i < s.Length && s[i] != '\n') i++;
                continue;
            }
            break;
        }
    }

    private static void SkipConditional(string s, ref int i)
    {
        int save = i;
        SkipTrivia(s, ref i);
        if (i < s.Length && s[i] == '[')
        {
            while (i < s.Length && s[i] != ']') i++;
            if (i < s.Length) i++;
        }
        else i = save;
    }

    private static string ReadToken(string s, ref int i)
    {
        SkipTrivia(s, ref i);
        if (i >= s.Length) return "";
        if (s[i] == '"')
        {
            i++;
            var sb = new StringBuilder();
            while (i < s.Length && s[i] != '"')
            {
                if (s[i] == '\\' && i + 1 < s.Length)
                {
                    char n = s[i + 1];
                    sb.Append(n switch { 'n' => '\n', 't' => '\t', 'r' => '\r', '\\' => '\\', '"' => '"', _ => n });
                    i += 2;
                }
                else sb.Append(s[i++]);
            }
            if (i < s.Length) i++;
            return sb.ToString();
        }

        int start = i;
        while (i < s.Length && !char.IsWhiteSpace(s[i]) && s[i] != '{' && s[i] != '}') i++;
        return s[start..i];
    }

    public static string Serialize(List<VdfNode> nodes)
    {
        var sb = new StringBuilder();
        foreach (var n in nodes) Write(sb, n, 0);
        return sb.ToString();
    }

    private static void Write(StringBuilder sb, VdfNode n, int depth)
    {
        string ind = new('\t', depth);
        if (n.IsObject)
        {
            sb.Append(ind).Append('"').Append(Escape(n.Key)).Append("\"\n");
            sb.Append(ind).Append("{\n");
            foreach (var c in n.Children!) Write(sb, c, depth + 1);
            sb.Append(ind).Append("}\n");
        }
        else
        {
            sb.Append(ind).Append('"').Append(Escape(n.Key)).Append("\"\t\t\"")
              .Append(Escape(n.Value ?? "")).Append("\"\n");
        }
    }

    private static string Escape(string s) => s.Replace("\\", "\\\\").Replace("\"", "\\\"");

    public static int CountLeaves(IEnumerable<VdfNode> nodes)
    {
        int n = 0;
        foreach (var node in nodes)
            n += node.IsObject ? CountLeaves(node.Children!) + 1 : 1;
        return n;
    }
}

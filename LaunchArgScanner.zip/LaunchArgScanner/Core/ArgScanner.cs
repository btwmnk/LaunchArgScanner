using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace LaunchArgScanner.Core;

public static partial class ArgScanner
{
    private const int MinLen = 3;
    private const int MaxLen = 300;

    private static readonly string[] ThirdPartyPrefixes =
    {
        "api-ms-", "vcruntime", "msvcp", "ucrtbase", "concrt", "vccorlib", "mfc", "d3dcompiler", "dxcompiler", "dxil",
        "d3d12core", "d3d12sdklayers", "steam_api", "steamclient", "steamnetworking", "libcef", "chrome_elf", "cef",
        "nvngx", "sl.", "nvapi", "nvtoolsext", "nvrtc", "cudart", "gfsdk", "amd_ags", "amd_fidelityfx", "ffx_",
        "libxess", "xess", "physx", "apex", "nvcloth", "bink", "eossdk", "eosovh", "discord", "galaxy", "openal",
        "fmod", "wwise", "aksound", "libogg", "libvorbis", "tbb", "embree", "oo2core", "oo2net", "oo2tex", "openvr_api",
        "openxr_loader", "libovr", "ovrplugin", "easyanticheat", "beclient", "battleye", "sentry", "crashpad",
        "icu", "libssl", "libcrypto", "libcurl", "zlib", "dbghelp", "dbgcore", "mono-2.0", "monoposixhelper",
        "baselib", "winpixeventruntime", "dstorage", "microsoft.", "system.", "mscorlib", "netstandard",
        "unity.", "unityengine", "mono.", "newtonsoft", "dotnet", "coreclr", "clrjit", "hostfxr", "hostpolicy",
        "libglesv2", "libegl", "vulkan-1", "opengl32", "glew", "sdl2", "xinput", "x3daudio", "xaudio", "dxgi",
        "ffmpeg", "avcodec", "avformat", "avutil", "swscale", "swresample", "libvlc", "qt5", "qt6", "harfbuzz",
        "freetype", "libpng", "libjpeg", "libwebp", "steam_appid", "vivoxsdk", "ortp", "libvivox", "amfrt", "ispc_texcomp",
        "tobii", "razer", "logitech", "nvlowlatency", "nvperf", "dlss", "fsr", "intel"
    };

    private static readonly string[] ThirdPartyDirs =
    {
        @"\Engine\Binaries\ThirdParty\", @"\_CommonRedist\", @"\Redist\", @"\__Installer\", @"\EasyAntiCheat\",
        @"\BattlEye\", @"\DirectX\", @"\CEF3\", @"\CEF\", @"\Support\", @"\PhysX\", @"\Prerequisites\"
    };

    private static readonly HashSet<string> CVarPrefixes = new(StringComparer.OrdinalIgnoreCase)
    {
        "r", "sg", "t", "a", "au", "fx", "p", "net", "s", "gc", "foliage", "grass", "slate", "tick", "rhi", "vr", "xr",
        "D3D12", "D3D11", "ShowFlag", "Niagara", "landscape", "streaming", "lumen", "nanite", "ai", "Audio", "Input",
        "HLOD", "wp", "UI", "Physics", "Chaos", "MaterialQualityLevel", "Vulkan", "ShaderPipelineCache", "PSO", "Engine"
    };

    private static readonly HashSet<string> FileExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        "dll", "exe", "ini", "pak", "txt", "json", "png", "jpg", "jpeg", "dds", "tga", "bmp", "uasset", "umap", "log",
        "cfg", "xml", "bin", "dat", "so", "lib", "pdb", "cpp", "h", "hpp", "cs", "usf", "ush", "wav", "ogg", "mp4",
        "bik", "bk2", "ttf", "otf", "csv", "sav", "vdf", "vpk", "pck", "utoc", "ucas", "com", "net", "org", "html", "js"
    };

    private static readonly HashSet<string> JunkBodies = new(StringComparer.OrdinalIgnoreCase)
    {
        "nan", "inf", "infinity", "ind", "snan", "qnan", "nan(ind)", "Win64", "Win32", "Shipping", "Development", "Debug",
        "Test", "x64", "x86", "amd64", "arm64", "GameThread", "RenderThread"
    };

    [GeneratedRegex(@"^(?:--?|\+)[A-Za-z][A-Za-z0-9_.\-]{1,47}[=:]?$")]
    private static partial Regex PrefixedRx();

    [GeneratedRegex(@"^[A-Z][A-Za-z0-9_]{1,39}=$")]
    private static partial Regex ValueKeyRx();

    [GeneratedRegex(@"^([A-Za-z][A-Za-z0-9]{0,24})\.[A-Za-z][A-Za-z0-9_.]{2,79}$")]
    private static partial Regex CVarRx();

    [GeneratedRegex(@"\[\s*((?:--?|\+)[A-Za-z][A-Za-z0-9_\-]{1,40}=?)")]
    private static partial Regex UsageBracketRx();

    [GeneratedRegex(@"\+\+UE([345])\+Release-(\d+\.\d+)")]
    private static partial Regex UeBranchRx();

    [GeneratedRegex(@"^[0-9A-Fa-f]{6,}$")]
    private static partial Regex HexRx();

    public static ScanResult Scan(string path, ScanOptions opt, IProgress<ScanProgress>? progress, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var result = new ScanResult();
        string root = EngineDetector.NormalizeRoot(path);
        result.Root = root;

        var enumOpt = new EnumerationOptions
        {
            RecurseSubdirectories = true,
            IgnoreInaccessible = true,
            MaxRecursionDepth = 10,
            AttributesToSkip = FileAttributes.ReparsePoint | FileAttributes.System
        };

        var allFiles = Directory.EnumerateFiles(root, "*", enumOpt).ToList();
        ct.ThrowIfCancellationRequested();

        result.MainExe = File.Exists(path) && path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
            ? Path.GetFullPath(path)
            : EngineDetector.FindMainExe(root, allFiles);
        result.Engine = EngineDetector.Detect(root, allFiles, result.MainExe);

        try
        {
            var app = SteamIntegration.ResolveApp(root);
            if (app != null)
            {
                result.SteamAppId = app.Value.appId;
                result.SteamGameName = app.Value.name;
            }
        }
        catch {  }

        var targets = allFiles.Where(f =>
        {
            var name = Path.GetFileName(f);
            bool bin = name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
                    || name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)
                    || name.Equals("global-metadata.dat", StringComparison.OrdinalIgnoreCase);
            if (!bin) return false;
            if (opt.SkipThirdParty && IsThirdParty(f, name))
            {
                result.SkippedFiles.Add(Rel(root, f));
                return false;
            }
            return true;
        })

        .OrderByDescending(f => string.Equals(f, result.MainExe, StringComparison.OrdinalIgnoreCase))
        .ToList();

        var collector = new Collector(result.Engine, opt);
        var codeFiles = new List<(string rel, byte[] data)>();
        long codeFilesBytes = 0;
        const long CodeFilesBudget = 800_000_000;
        byte[]? mainExeData = null;

        for (int i = 0; i < targets.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var file = targets[i];
            var rel = Rel(root, file);
            progress?.Report(new ScanProgress(i, targets.Count, rel));

            long size;
            try { size = new FileInfo(file).Length; } catch { continue; }
            if (size > opt.MaxFileSize || size == 0)
            {
                result.SkippedFiles.Add(rel + " (слишком большой)");
                continue;
            }

            byte[] data;
            try { data = File.ReadAllBytes(file); }
            catch
            {
                result.SkippedFiles.Add(rel + " (нет доступа)");
                continue;
            }

            if (string.Equals(file, result.MainExe, StringComparison.OrdinalIgnoreCase)) mainExeData = data;

            bool core = IsCoreFile(file, result);
            collector.BeginFile(rel, core);

            if (Path.GetFileName(file).Equals("global-metadata.dat", StringComparison.OrdinalIgnoreCase))
                StringExtractor.ExtractIl2CppLiterals(data, MinLen, MaxLen, collector.Feed);

            StringExtractor.Extract(data, MinLen, MaxLen, collector.Feed, () => ct.IsCancellationRequested);

            if (opt.AnalyzeCode && core && size <= opt.MaxCodeAnalysisSize && codeFilesBytes + size <= CodeFilesBudget &&
                (file.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)))
            {
                codeFiles.Add((rel, data));
                codeFilesBytes += size;
            }

            result.FilesScanned++;
            result.BytesScanned += size;
        }
        ct.ThrowIfCancellationRequested();
        progress?.Report(new ScanProgress(targets.Count, targets.Count, "Готово"));

        if (collector.UeMajor is int major && (result.Engine.Family == EngineFamily.Unreal || result.Engine.Family == EngineFamily.Unknown))
        {
            result.Engine.Family = EngineFamily.Unreal;
            result.Engine.UnrealMajor = major;
            result.Engine.Version = collector.UeVersion;
            result.Engine.Evidence.Add($"++UE{major}+Release-{collector.UeVersion}");
        }

        var lookup = KnownArgs.BuildLookup(result.Engine.Mask);
        result.Candidates = collector.Finish(lookup);

        if (opt.AnalyzeCode && codeFiles.Count > 0)
        {
            var bareLookup = KnownArgs.BuildBareLookup(lookup);
            Action<string> st = msg => progress?.Report(new ScanProgress(targets.Count, targets.Count, msg));
            var code = CodeAnalyzer.Analyze(codeFiles, bareLookup, st, ct);
            result.CodeAnalysisRan = code.Ran;
            result.CodeAnalysisNote = code.Note;
            if (code.Ran)
                MergeCodeResults(result, code, lookup);
        }

        try { AssetScanner.Scan(root, allFiles, result.Engine.Family, result.Candidates); } catch { }

        try { AddDependenciesAndBuild(result, mainExeData); } catch { }

        try
        {
            var imports = mainExeData != null && PeImage.TryParse(mainExeData, out var mpe)
                ? mpe.ReadImportDllNames() : new List<string>();
            NetworkScanner.Scan(codeFiles, imports, result.Candidates);
        }
        catch { }

        result.Candidates = result.Candidates
            .OrderByDescending(c => c.Rank)
            .ThenBy(c => c.Category)
            .ThenBy(c => c.Arg, StringComparer.OrdinalIgnoreCase)
            .ToList();
        result.Elapsed = sw.Elapsed;
        return result;
    }

    private static void MergeCodeResults(ScanResult result, CodeAnalyzer.Result code, Dictionary<string, KnownArg> lookup)
    {
        var byArg = result.Candidates.ToDictionary(c => c.Arg, StringComparer.OrdinalIgnoreCase);

        var byBare = new Dictionary<string, ArgCandidate>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in result.Candidates)
            byBare.TryAdd(c.Arg.TrimStart('-', '+').TrimEnd('=', ':'), c);

        foreach (var ca in code.ByArg.Values)
        {
            if (ca.IsCVar || ca.IsCommand) { MergeConsole(result, ca, byArg); continue; }

            var bare = ca.Arg.TrimStart('-', '+').TrimEnd('=', ':');
            if (!byArg.TryGetValue(ca.Arg, out var cand))
                byBare.TryGetValue(bare, out cand);

            bool isNew = cand == null;
            if (cand == null)
            {
                lookup.TryGetValue(ca.Arg, out var known);
                cand = new ArgCandidate
                {
                    Arg = known?.Name ?? ca.Arg,
                    Category = known != null ? ArgCategory.Known : ArgCategory.Prefixed,
                    Description = known?.Description ?? "",
                    ValueHint = known?.ValueHint
                };
                result.Candidates.Add(cand);
                byArg[cand.Arg] = cand;
                byBare.TryAdd(bare, cand);
            }

            cand.VerifiedByCode = true;
            cand.CodeCallSites = ca.CallSites;
            cand.Confidence = Confidence.High;
            if (ca.Evidence != null) cand.CodeEvidence = ca.Evidence;
            foreach (var f in ca.Files) cand.Sources.Add(f);

            cand.IsValueParam = ca.IsValue || cand.ValueHint != null || cand.Arg.EndsWith('=');
            if (cand.IsValueParam)
            {
                cand.Category = ArgCategory.ValueKey;
                cand.ValueHint ??= "<значение>";
            }

            var kind = cand.IsValueParam ? "принимает значение после =" : "флаг, значение не нужно";

            if (isNew && string.IsNullOrEmpty(cand.Description))
                cand.Description = "Недокументированный параметр — описания в бинарнике нет, но игра его обрабатывает.";
            cand.Description = $"Игра обрабатывает этот параметр · {kind} · {ca.CallSites} мест в коде. " + cand.Description;
        }

        result.VerifiedByCode = result.Candidates.Count(c => c.VerifiedByCode);
    }

    private static void MergeConsole(ScanResult result, CodeAnalyzer.CodeArg ca, Dictionary<string, ArgCandidate> byArg)
    {
        if (!byArg.TryGetValue(ca.Arg, out var cand))
        {
            cand = new ArgCandidate { Arg = ca.Arg };
            result.Candidates.Add(cand);
            byArg[ca.Arg] = cand;
        }
        cand.VerifiedByCode = true;
        cand.Confidence = Confidence.High;
        cand.CodeCallSites = ca.CallSites;
        if (ca.Evidence != null) cand.CodeEvidence = ca.Evidence;
        foreach (var f in ca.Files) cand.Sources.Add(f);

        var help = string.IsNullOrWhiteSpace(ca.Help) ? "" : ca.Help!.Trim();

        if (ca.IsCVar)
        {
            cand.Category = ArgCategory.CVar;
            cand.IsValueParam = true;
            cand.ValueHint = "<значение>";
            cand.Description = $"Консольная переменная движка. {help} Задать: -dpcvars={ca.Arg}=<значение> (UE5) " +
                               $"или -ExecCmds=\"{ca.Arg} <значение>\".";
        }
        else
        {
            cand.Category = ArgCategory.ConsoleCommand;
            cand.IsValueParam = false;
            cand.Description = $"Консольная команда. {help} Выполнить при старте: -ExecCmds=\"{ca.Arg}\".";
        }
    }

    private static readonly (string needle, string label)[] KnownDlls =
    {
        ("EasyAntiCheat", "Античит: Easy Anti-Cheat"), ("eac_", "Античит: Easy Anti-Cheat"),
        ("BattlEye", "Античит: BattlEye"), ("BEClient", "Античит: BattlEye"),
        ("steamclient", "Steam"), ("steam_api", "Steam API"), ("GameOverlayRenderer", "Steam Overlay"),
        ("EOSSDK", "Epic Online Services"), ("eossdk", "Epic Online Services"),
        ("Galaxdule", "GOG Galaxy"), ("Galaxy", "GOG Galaxy"),
        ("nvngx_dlss", "NVIDIA DLSS"), ("sl.interposer", "NVIDIA Streamline"), ("nvngx", "NVIDIA DLSS/NGX"),
        ("amd_fidelityfx", "AMD FidelityFX"), ("ffx_", "AMD FidelityFX"), ("libxess", "Intel XeSS"),
        ("PhysX", "NVIDIA PhysX"), ("GFSDK", "NVIDIA GameWorks"),
        ("fmod", "FMOD (звук)"), ("wwise", "Wwise (звук)"), ("Ak", "Wwise (звук)"), ("OpenAL", "OpenAL (звук)"),
        ("bink", "Bink Video"), ("oo2", "Oodle (сжатие)"),
        ("d3d12", "Direct3D 12"), ("d3d11", "Direct3D 11"), ("vulkan", "Vulkan"), ("dxgi", "DXGI"),
        ("discord", "Discord SDK"), ("libcef", "CEF (встроенный Chromium)"), ("vivox", "Vivox (голос)"),
        ("XInput", "XInput (геймпад)"), ("openvr", "OpenVR"), ("openxr", "OpenXR"),
    };

    private static void AddDependenciesAndBuild(ScanResult result, byte[]? exeData)
    {
        if (exeData == null || !PeImage.TryParse(exeData, out var pe)) return;

        var bi = new List<string>();
        bi.Add(pe.Is64Bit ? "64-битная" : "32-битная");
        if (result.Engine.DisplayName is { Length: > 0 } en && en != "Не определён") bi.Add(en);
        if (pe.BuildDateUtc is { } d) bi.Add("собрано " + d.ToString("yyyy-MM-dd"));
        result.Candidates.Add(new ArgCandidate
        {
            Arg = Path.GetFileName(result.MainExe ?? "exe"),
            Category = ArgCategory.BuildInfo,
            FromGameFiles = true,
            Confidence = Confidence.High,
            Description = "Сведения о сборке: " + string.Join(", ", bi) + "."
        });

        var dlls = pe.ReadImportDllNames();
        var shown = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var dll in dlls)
        {
            foreach (var (needle, label) in KnownDlls)
            {
                if (dll.IndexOf(needle, StringComparison.OrdinalIgnoreCase) < 0) continue;
                if (!shown.Add(label)) break;
                result.Candidates.Add(new ArgCandidate
                {
                    Arg = label,
                    Category = ArgCategory.Dependency,
                    FromGameFiles = true,
                    Confidence = Confidence.High,
                    Description = "Подключено в игре (" + dll + ")."
                });
                break;
            }
        }
    }

    private static string Rel(string root, string file) => Path.GetRelativePath(root, file);

    private static bool IsThirdParty(string full, string name)
    {
        foreach (var d in ThirdPartyDirs)
            if (full.Contains(d, StringComparison.OrdinalIgnoreCase)) return true;
        foreach (var p in ThirdPartyPrefixes)
            if (name.StartsWith(p, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    private static readonly string[] CoreNames =
    {
        "UnityPlayer.dll", "GameAssembly.dll", "global-metadata.dat", "engine.dll", "engine2.dll", "client.dll",
        "server.dll", "launcher.dll", "tier0.dll", "CrySystem.dll", "CryGameSDK.dll"
    };

    private static bool IsCoreFile(string file, ScanResult r)
    {
        var name = Path.GetFileName(file);
        if (string.Equals(file, r.MainExe, StringComparison.OrdinalIgnoreCase)) return true;
        if (name.EndsWith("-Shipping.exe", StringComparison.OrdinalIgnoreCase)) return true;
        if (name.StartsWith("Assembly-CSharp", StringComparison.OrdinalIgnoreCase)) return true;
        if (name.StartsWith("UnrealEditor-", StringComparison.OrdinalIgnoreCase) || name.StartsWith("UE4-", StringComparison.OrdinalIgnoreCase)) return true;
        return CoreNames.Any(c => c.Equals(name, StringComparison.OrdinalIgnoreCase));
    }

    private sealed class Collector
    {
        private readonly EngineInfo _engine;
        private readonly ScanOptions _opt;
        private readonly Dictionary<string, KnownArg> _known;
        private readonly Dictionary<string, KnownArg> _bare;
        private readonly Dictionary<string, ArgCandidate> _map = new(StringComparer.OrdinalIgnoreCase);
        private readonly bool _unreal;
        private readonly bool _bareEnabled;
        private string _file = "";
        private bool _core;

        public int? UeMajor { get; private set; }
        public string? UeVersion { get; private set; }

        public Collector(EngineInfo engine, ScanOptions opt)
        {
            _engine = engine;
            _opt = opt;
            _known = KnownArgs.BuildLookup(engine.Mask);
            _bare = KnownArgs.BuildBareLookup(_known);
            _unreal = engine.Family == EngineFamily.Unreal;
            _bareEnabled = engine.Family is EngineFamily.Unreal or EngineFamily.Unity or EngineFamily.Unknown;
        }

        public void BeginFile(string rel, bool core)
        {
            _file = rel;
            _core = core;
        }

        public void Feed(string s)
        {
            char c0 = s[0];

            if (c0 == '+' && s.Length > 4 && s[1] == '+' && UeMajor is null)
            {
                var m = UeBranchRx().Match(s);
                if (m.Success)
                {
                    UeMajor = int.Parse(m.Groups[1].Value);
                    UeVersion = m.Groups[2].Value;
                }
                return;
            }

            if ((c0 == '-' || c0 == '+') && _known.TryGetValue(s, out var k))
            {
                Add(k.Name, ArgCategory.Known, Confidence.High, k.Description, k);
                return;
            }

            if (c0 == '-' || c0 == '+')
            {
                if (s.Length <= 50 && PrefixedRx().IsMatch(s) && !IsJunk(s))
                {
                    var conf = _core ? Confidence.Medium : Confidence.Low;
                    Add(s, ArgCategory.Prefixed, conf, "Строка-флаг найдена в бинарнике", null);
                    return;
                }
            }

            if (_bareEnabled && char.IsLetter(c0) && s.Length <= 48 && _bare.TryGetValue(s, out var bk) && !BareStopWords.Contains(s))
            {
                var conf = _unreal && bk.BareName.Length >= 5 ? Confidence.Medium : Confidence.Low;
                Add(bk.Name, ArgCategory.Known, conf, bk.Description + " · найдено без префикса", bk);
                return;
            }

            if (_opt.IncludeValueKeys && (_unreal || _engine.Family == EngineFamily.Unknown)
                && s[^1] == '=' && s.Length <= 41 && ValueKeyRx().IsMatch(s))
            {
                Add("-" + s, ArgCategory.ValueKey, Confidence.Low, "Значение вида -Name=... (FParse::Value); может читаться и из ini", null);
                return;
            }

            if (_opt.IncludeCVars && _unreal && _engine.UnrealMajor != 3 && s.Length <= 100 && s.IndexOf('.') > 0 && s.IndexOf(' ') < 0)
            {
                var m = CVarRx().Match(s);
                if (m.Success && CVarPrefixes.Contains(m.Groups[1].Value))
                {
                    var last = s[(s.LastIndexOf('.') + 1)..];
                    if (!FileExtensions.Contains(last))
                    {
                        Add(s, ArgCategory.CVar, Confidence.Low,
                            "Консольная переменная. Задать: -dpcvars=" + s + "=<знач> (UE5) или -ExecCmds=\"" + s + " <знач>\"", null);
                        return;
                    }
                }
            }

            if (_opt.IncludeHelpText && s.IndexOf(' ') >= 0)
                ParseHelp(s);
        }

        private void ParseHelp(string s)
        {
            var t = s.TrimStart();
            if (t.Length > 3 && (t[0] == '-' || t[0] == '+') && (char.IsLetter(t[1]) || (t[1] == '-' && t.Length > 2 && char.IsLetter(t[2]))))
            {
                int sp = t.IndexOfAny(new[] { ' ', '\t' });
                if (sp > 0)
                {
                    var token = t[..sp].TrimEnd(',', ';');
                    var rest = t[sp..].Trim().TrimStart(':', '-', '–', '=', ' ').Trim();

                    if (rest.StartsWith('<') || rest.StartsWith('['))
                    {
                        int close = rest.IndexOfAny(new[] { '>', ']' });
                        if (close > 0) rest = rest[(close + 1)..].Trim().TrimStart(':', '-', ' ');
                    }
                    if (PrefixedRx().IsMatch(token) && !IsJunk(token) && rest.Length >= 4 && rest.Any(char.IsLower))
                    {
                        if (_known.TryGetValue(token, out var k))
                            Add(k.Name, ArgCategory.Known, Confidence.High, k.Description, k);
                        else
                            Add(token, ArgCategory.HelpText, Confidence.Medium, rest, null, helpDesc: true);
                        return;
                    }
                }
            }

            if (s.IndexOf("[-", StringComparison.Ordinal) >= 0 || s.IndexOf("[+", StringComparison.Ordinal) >= 0)
            {
                foreach (Match m in UsageBracketRx().Matches(s))
                {
                    var token = m.Groups[1].Value;
                    if (IsJunk(token)) continue;
                    if (_known.TryGetValue(token, out var k))
                        Add(k.Name, ArgCategory.Known, Confidence.High, k.Description, k);
                    else
                        Add(token, ArgCategory.HelpText, Confidence.Low, "Упомянут в строке usage: " + Shorten(s), null);
                }
            }
        }

        private static string Shorten(string s) => s.Length <= 120 ? s : s[..117] + "...";

        private void Add(string arg, ArgCategory cat, Confidence conf, string desc, KnownArg? known, bool helpDesc = false)
        {
            if (!_map.TryGetValue(arg, out var c))
            {
                c = new ArgCandidate
                {
                    Arg = arg,
                    Category = cat,
                    Confidence = conf,
                    Description = desc,
                    ValueHint = known?.ValueHint
                };
                _map[arg] = c;
            }
            else
            {
                if (conf > c.Confidence) c.Confidence = conf;
                if (cat == ArgCategory.Known && c.Category != ArgCategory.Known)
                {
                    c.Category = ArgCategory.Known;
                    c.Description = desc;
                    c.ValueHint = known?.ValueHint;
                }
                else if (helpDesc && c.Category != ArgCategory.Known && c.Category != ArgCategory.HelpText)
                {

                    c.Category = ArgCategory.HelpText;
                    c.Description = desc;
                }
                else if (known != null && c.Description.EndsWith("найдено без префикса") && !desc.EndsWith("найдено без префикса"))
                {
                    c.Description = desc;
                }
            }
            c.Hits++;
            if (c.Sources.Count < 20) c.Sources.Add(_file);
        }

        public List<ArgCandidate> Finish(Dictionary<string, KnownArg> lookup)
        {

            foreach (var k in lookup.Values)
            {
                if (_engine.Family == EngineFamily.Unknown) break;
                if (_map.ContainsKey(k.Name)) continue;
                if (k.Engines == EngineMask.Generic) continue;
                _map[k.Name] = new ArgCandidate
                {
                    Arg = k.Name,
                    Category = ArgCategory.Known,
                    Confidence = Confidence.NotFound,
                    Description = k.Description + " · в бинарниках не найден, но движок обычно его поддерживает",
                    ValueHint = k.ValueHint
                };
            }

            return _map.Values
                .OrderByDescending(c => c.Confidence)
                .ThenBy(c => c.Category)
                .ThenBy(c => c.Arg, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
    }

    private static readonly HashSet<string> BareStopWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "game", "server", "ini", "ini:", "exec", "exec=", "log", "high", "console", "debug", "language", "monitor",
        "adapter", "threads", "installed", "fullscreen", "windowed", "refresh", "connect", "map"
    };

    private static bool IsJunk(string s)
    {
        var body = s.TrimStart('-', '+').TrimEnd('=', ':');
        if (body.Length < 2) return true;
        if (body.EndsWith('-') || body.EndsWith('.') || body.Contains("..") || body.Contains("--")) return true;
        if (JunkBodies.Contains(body)) return true;
        if (HexRx().IsMatch(body)) return true;
        int digits = 0;
        foreach (var ch in body) if (char.IsDigit(ch)) digits++;
        if (digits * 2 > body.Length) return true;
        int dot = body.LastIndexOf('.');
        if (dot > 0 && FileExtensions.Contains(body[(dot + 1)..])) return true;
        if (body.Contains("Shipping", StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }
}

using System;
using System.Threading.Tasks;
using Microsoft.UI.Xaml;

namespace LaunchArgScanner;

public partial class App : Application
{
    public static MainWindow? MainWindow { get; private set; }

    public static Action<string>? StatusSink;

    public static string? LastAesKeyHex;

    public static string? PendingPakPath;

    public App()
    {
        Crash.Trace("App ctor start");
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Crash.Report(e.ExceptionObject as Exception, "Необработанная ошибка");
        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            Crash.Log(e.Exception, "Ошибка в фоновой задаче");
            e.SetObserved();
        };

        Crash.Trace("InitializeComponent before");
        InitializeComponent();
        Crash.Trace("InitializeComponent after");

        UnhandledException += (_, e) =>
        {
            Crash.Report(e.Exception, "Ошибка интерфейса");
            e.Handled = true;
        };
        Crash.Trace("App ctor end");
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        Crash.Trace("OnLaunched start");
        try
        {
            MainWindow = new MainWindow();
            Crash.Trace("MainWindow created");
            MainWindow.Activate();
            Crash.Trace("MainWindow activated");
        }
        catch (Exception ex)
        {
            Crash.Report(ex, "Ошибка при создании окна");
            throw;
        }
    }

    public static nint Hwnd
    {
        get
        {
            try { return MainWindow is null ? 0 : WinRT.Interop.WindowNative.GetWindowHandle(MainWindow); }
            catch { return 0; }
        }
    }
}

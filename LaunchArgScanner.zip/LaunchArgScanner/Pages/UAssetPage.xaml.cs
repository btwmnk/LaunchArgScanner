using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using LaunchArgScanner.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;

namespace LaunchArgScanner.Pages;

public sealed partial class UAssetPage : Page
{
    private UAssetInfo? _info;
    private EditSession? _session;
    private string _path = "";
    private bool _dirty;

    private List<NameNode> _names = new();
    private List<ImportNode> _imports = new();
    private List<ExportNode> _exports = new();

    public UAssetPage()
    {
        InitializeComponent();
    }

    private static void Status(string t) => App.StatusSink?.Invoke(t);

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var path = Win32Dialogs.OpenFile(App.Hwnd, "Unreal asset (*.uasset;*.umap)", "*.uasset;*.umap");
            if (path != null) AssetBox.Text = path;
        }
        catch (Exception ex) { Status("Не удалось открыть диалог: " + ex.Message); }
    }

    private (int ue4, int ue5) ForcedVersion() => VersionBox.SelectedIndex switch
    {
        1 => (504, 0),
        2 => (513, 0),
        3 => (516, 0),
        4 => (518, 0),
        5 => (522, 0),
        6 => (522, 1004),
        7 => (522, 1008),
        8 => (522, 1012),
        _ => (0, 0)
    };

    private async void Open_Click(object sender, RoutedEventArgs e)
    {
        var path = AssetBox.Text.Trim().Trim('"');
        if (!File.Exists(path)) { Status("Укажи существующий .uasset"); return; }

        OpenButton.IsEnabled = false;
        try
        {
            Status("Читаю uasset…");
            var (fu4, fu5) = ForcedVersion();
            var info = await Task.Run(() => UAssetReader.Read(path, fu4, fu5));
            _info = info;
            _path = path;
            _dirty = false;
            SaveButton.IsEnabled = false;
            SaveAsButton.IsEnabled = false;
            _session = null;

            if (!info.MagicOk)
            {
                SummaryCard.Visibility = Visibility.Visible;
                ToolRow.Visibility = Visibility.Collapsed;
                SummaryText.Text = string.IsNullOrEmpty(info.Error) ? "Не удалось разобрать файл." : info.Error;
                ClearLists();
                Status("Это не похоже на .uasset");
                return;
            }

            int verIndex = VersionBox.SelectedIndex;
            EditSession? session = null;
            string editErr = "";
            try { session = await Task.Run(() => UAssetEditor.Load(path, verIndex)); }
            catch (Exception ex) { editErr = ex.Message; }

            _session = session;
            if (session != null)
            {
                _names = session.Names;
                _imports = session.Imports;
                _exports = session.Exports;
                SaveAsButton.IsEnabled = true;
            }
            else
            {
                _names = info.Names.Select(n => new NameNode { Index = n.Index, Name = n.Name }).ToList();
                _imports = info.Imports.Select(i => new ImportNode { Name = i.Name, ClassName = i.ClassName }).ToList();
                _exports = info.Exports.Select(x => new ExportNode { Name = x.Name, ClassName = x.ClassName }).ToList();
            }

            SummaryCard.Visibility = Visibility.Visible;
            ToolRow.Visibility = Visibility.Visible;
            SummaryText.Text = BuildSummary(info, path, session != null, editErr);

            ExportsTab.Header = "Экспорты (" + _exports.Count + ")";
            NamesTab.Header = "Имена (" + _names.Count + ")";
            ImportsTab.Header = "Импорты (" + _imports.Count + ")";

            ExportPicker.ItemsSource = _exports;
            if (_exports.Count > 0) ExportPicker.SelectedIndex = 0;
            ApplyFilter();

            if (session != null)
                Status($"Открыт для правки: {Path.GetFileName(path)} · экспортов {_exports.Count} · имён {_names.Count}");
            else
                Status($"Открыт только для чтения: {Path.GetFileName(path)}. Чтобы править — выбери версию движка и открой снова.");
        }
        catch (Exception ex)
        {
            Status("Не удалось прочитать: " + ex.Message);
        }
        finally { OpenButton.IsEnabled = true; }
    }

    private void ClearLists()
    {
        _names = new(); _imports = new(); _exports = new();
        ExportPicker.ItemsSource = null;
        PropsList.ItemsSource = null;
        NamesList.ItemsSource = null;
        ImportsList.ItemsSource = null;
    }

    private static string BuildSummary(UAssetInfo info, string path, bool editable, string editErr)
    {
        var lines = new List<string>
        {
            "Файл: " + Path.GetFileName(path) + "  (" + info.FileSize + " B)",
            "Движок: " + info.EngineText,
            "Версии: legacy " + info.LegacyVersion + " · UE4 " + info.FileVersionUE4 + " · UE5 " + info.FileVersionUE5 + " · licensee " + info.LicenseeVersion,
            "Хэши имён: " + (info.NameHashes ? "да" : "нет") + "  ·  PackageFlags: 0x" + info.PackageFlags.ToString("X8"),
            "Имена: " + info.NameCount + "  ·  импорты: " + info.ImportCount + "  ·  экспорты: " + info.ExportCount,
            editable ? "Режим: правка доступна (двойной клик по свойству или имени)" : "Режим: только чтение"
        };
        if (!editable)
        {
            if (info.Unversioned) lines.Add("ℹ файл без версии — выбери версию движка слева от «Открыть» и открой снова, чтобы править");
            if (!string.IsNullOrEmpty(editErr)) lines.Add("UAssetAPI: " + editErr);
        }
        return string.Join(Environment.NewLine, lines);
    }

    private void ExportPicker_Changed(object sender, SelectionChangedEventArgs e)
    {
        var exp = ExportPicker.SelectedItem as ExportNode;
        PropsList.ItemsSource = exp == null ? null : FilterProps(exp.Props);
    }

    private void Search_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();

    private void ApplyFilter()
    {
        var q = SearchBox.Text.Trim();
        NamesList.ItemsSource = Filter(_names, q, n => n.Name);
        ImportsList.ItemsSource = Filter(_imports, q, o => o.Name + " " + o.ClassName);
        if (ExportPicker.SelectedItem is ExportNode exp)
            PropsList.ItemsSource = FilterProps(exp.Props);
    }

    private List<PropNode> FilterProps(List<PropNode> props)
    {
        var q = SearchBox.Text.Trim();
        return string.IsNullOrEmpty(q) ? props : props.Where(p => (p.Name + " " + p.Value).Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    private static List<T> Filter<T>(List<T> src, string q, Func<T, string> key)
    {
        if (string.IsNullOrEmpty(q)) return src;
        return src.Where(x => key(x).Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    private async void Props_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        if (_session == null) { Status("Открой с выбранной версией движка, чтобы править"); return; }
        if ((e.OriginalSource as FrameworkElement)?.DataContext is not PropNode node) return;
        if (!node.Editable) { Status($"Свойство «{node.Name}» ({node.Type}) здесь не редактируется"); return; }

        var input = new TextBox { Text = node.Value, AcceptsReturn = false };
        var dialog = new ContentDialog
        {
            Title = node.Name + "  (" + node.Type + ")",
            Content = input,
            PrimaryButtonText = "OK",
            CloseButtonText = "Отмена",
            DefaultButton = ContentDialogButton.Primary,
            XamlRoot = XamlRoot
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;
        if (input.Text == node.Value) return;

        if (UAssetEditor.SetProp(node, input.Text, out var err))
        {
            MarkDirty();
            if (ExportPicker.SelectedItem is ExportNode exp) PropsList.ItemsSource = FilterProps(exp.Props);
            Status($"Изменено свойство «{node.Name}»");
        }
        else Status("Не удалось изменить: " + err);
    }

    private async void Names_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        if (_session == null) { Status("Открой с выбранной версией движка, чтобы править"); return; }
        if ((e.OriginalSource as FrameworkElement)?.DataContext is not NameNode node) return;

        var input = new TextBox { Text = node.Name, AcceptsReturn = false };
        var dialog = new ContentDialog
        {
            Title = "Переименовать имя #" + node.Index,
            Content = input,
            PrimaryButtonText = "OK",
            CloseButtonText = "Отмена",
            DefaultButton = ContentDialogButton.Primary,
            XamlRoot = XamlRoot
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;
        if (input.Text == node.Name) return;

        if (UAssetEditor.SetName(_session, node.Index, input.Text, out var err))
        {
            MarkDirty();
            ApplyFilter();
            Status($"Изменено имя #{node.Index}");
        }
        else Status("Не удалось изменить: " + err);
    }

    private void MarkDirty()
    {
        _dirty = true;
        SaveButton.IsEnabled = true;
    }

    private async void Save_Click(object sender, RoutedEventArgs e) => await SaveTo(_path);

    private async void SaveAs_Click(object sender, RoutedEventArgs e)
    {
        if (_session == null) { Status("Открой с выбранной версией движка, чтобы сохранять"); return; }
        try
        {
            var outPath = Win32Dialogs.SaveFile(App.Hwnd, "Unreal asset (*.uasset)", "*.uasset", "uasset", Path.GetFileNameWithoutExtension(_path));
            if (outPath != null) await SaveTo(outPath);
        }
        catch (Exception ex) { Status("Не удалось открыть диалог сохранения: " + ex.Message); }
    }

    private async Task SaveTo(string outPath)
    {
        if (_session == null) { Status("Нет открытого файла для правки"); return; }

        var session = _session;
        SaveButton.IsEnabled = false;
        try
        {
            Status("Сохраняю uasset…");
            await Task.Run(() => UAssetEditor.Save(session, outPath));
            Status($"Сохранено: {outPath} (и .uexp рядом, если он есть)");
            _dirty = false;
        }
        catch (Exception ex)
        {
            SaveButton.IsEnabled = _dirty;
            Status("Не удалось сохранить: " + ex.Message);
        }
    }
}

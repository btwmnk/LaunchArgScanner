using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using LaunchArgScanner.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Windows.Storage;
using Windows.Storage.Pickers;

namespace LaunchArgScanner.Pages;

public sealed partial class UnpackPage : Page
{
    private PakArchive? _pak;
    private List<PakEntry> _all = new();
    private string _dir = "";

    public UnpackPage()
    {
        InitializeComponent();
    }

    protected override void OnNavigatedTo(Microsoft.UI.Xaml.Navigation.NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);
        if (string.IsNullOrEmpty(KeyBox.Text) && App.LastAesKeyHex != null) KeyBox.Text = App.LastAesKeyHex;
        if (App.PendingPakPath != null)
        {
            PakBox.Text = App.PendingPakPath;
            App.PendingPakPath = null;
        }
    }

    private static void Status(string t) => App.StatusSink?.Invoke(t);

    private void BrowsePak_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var path = Win32Dialogs.OpenFile(App.Hwnd, "Unreal pak (*.pak)", "*.pak");
            if (path != null) PakBox.Text = path;
        }
        catch (Exception ex) { Status("Не удалось открыть диалог: " + ex.Message); }
    }

    private async void Open_Click(object sender, RoutedEventArgs e)
    {
        var path = PakBox.Text.Trim().Trim('"');
        if (!File.Exists(path)) { Status("Укажи существующий .pak"); return; }

        byte[]? key = null;
        if (!string.IsNullOrWhiteSpace(KeyBox.Text) && !AesKeyFinder.TryParseKey(KeyBox.Text, out key))
        {
            Status("Ключ не распознан: нужно 64 hex-символа (с 0x) или base64");
            return;
        }

        OpenButton.IsEnabled = false;
        try
        {
            Status("Открываю pak…");
            _pak = await Task.Run(() => PakArchive.Open(path, key));
            _all = _pak.Entries.OrderBy(x => x.Path, StringComparer.OrdinalIgnoreCase).ToList();
            _dir = "";
            Refresh();
            Status($"Открыт: {Path.GetFileName(path)} · файлов: {_all.Count} · mount: {_pak.MountPoint}");
        }
        catch (Exception ex)
        {
            _pak = null; _all = new();
            Refresh();
            Status("Не удалось открыть pak: " + ex.Message);
        }
        finally { OpenButton.IsEnabled = true; }
    }

    private void Search_Changed(object sender, TextChangedEventArgs e) => Refresh();

    private void Refresh()
    {
        if (FilesList == null) return;
        var search = SearchBox.Text.Trim();

        List<PakNode> nodes;
        if (search.Length > 0)
        {
            nodes = _all.Where(x => x.Path.Contains(search, StringComparison.OrdinalIgnoreCase))
                        .OrderBy(x => x.Path, StringComparer.OrdinalIgnoreCase)
                        .Select(x => new PakNode { Name = x.Path, IsFolder = false, Entry = x })
                        .ToList();
            Breadcrumb.Text = "Поиск: " + search;
            UpButton.IsEnabled = false;
        }
        else
        {
            nodes = BuildNodes(_dir);
            Breadcrumb.Text = "/" + _dir;
            UpButton.IsEnabled = _dir.Length > 0;
        }

        FilesList.ItemsSource = nodes;
        EmptyPanel.Visibility = nodes.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        EmptyText.Text = _all.Count == 0 ? "Открой .pak, чтобы увидеть файлы" : "Здесь пусто";
    }

    private List<PakNode> BuildNodes(string dir)
    {
        var folders = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        var files = new List<PakNode>();
        foreach (var e in _all)
        {
            if (!e.Path.StartsWith(dir, StringComparison.OrdinalIgnoreCase)) continue;
            var rest = e.Path.Substring(dir.Length);
            int slash = rest.IndexOf('/');
            if (slash >= 0) folders.Add(rest.Substring(0, slash));
            else if (rest.Length > 0) files.Add(new PakNode { Name = rest, IsFolder = false, Entry = e });
        }
        var result = new List<PakNode>();
        foreach (var f in folders) result.Add(new PakNode { Name = f, IsFolder = true, FullDir = dir + f + "/" });
        result.AddRange(files.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase));
        return result;
    }

    private void Up_Click(object sender, RoutedEventArgs e)
    {
        if (_dir.Length == 0) return;
        var trimmed = _dir.TrimEnd('/');
        int slash = trimmed.LastIndexOf('/');
        _dir = slash >= 0 ? trimmed.Substring(0, slash + 1) : "";
        Refresh();
    }

    private async void List_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        if ((e.OriginalSource as FrameworkElement)?.DataContext is not PakNode node) return;
        if (node.IsFolder)
        {
            _dir = node.FullDir;
            SearchBox.Text = "";
            Refresh();
        }
        else if (node.Entry != null)
        {
            await SaveSingle(node.Entry);
        }
    }

    private async Task SaveSingle(PakEntry entry)
    {
        if (_pak == null) return;
        if (!entry.CanExtract) { Status($"{entry.Name}: сжатие {entry.MethodText} пока не распаковывается (нужен repak)"); return; }

        var ext = Path.GetExtension(entry.Name);
        var fname = string.IsNullOrEmpty(ext) ? "Файл (*.*)" : ext.TrimStart('.').ToUpperInvariant() + " (*" + ext + ")";
        var fpat = string.IsNullOrEmpty(ext) ? "*.*" : "*" + ext;
        var defExt = string.IsNullOrEmpty(ext) ? "" : ext.TrimStart('.');

        string? outPath;
        try { outPath = Win32Dialogs.SaveFile(App.Hwnd, fname, fpat, defExt, entry.Name); }
        catch (Exception ex) { Status("Не удалось открыть диалог сохранения: " + ex.Message); return; }
        if (outPath == null) return;

        try
        {
            var pak = _pak;
            var data = await Task.Run(() => pak.Extract(entry));
            await File.WriteAllBytesAsync(outPath, data);
            Status($"Сохранён: {outPath}");
        }
        catch (Exception ex) { Status("Не удалось сохранить: " + ex.Message); }
    }

    private List<PakEntry> SelectedEntries()
    {
        var nodes = FilesList.SelectedItems.OfType<PakNode>().ToList();
        if (nodes.Count == 0) nodes = (FilesList.ItemsSource as IEnumerable<PakNode>)?.ToList() ?? new();
        var result = new List<PakEntry>();
        foreach (var n in nodes)
        {
            if (n.IsFolder)
                result.AddRange(_all.Where(x => x.Path.StartsWith(n.FullDir, StringComparison.OrdinalIgnoreCase)));
            else if (n.Entry != null)
                result.Add(n.Entry);
        }
        return result.Distinct().ToList();
    }

    private async void ExtractSelected_Click(object sender, RoutedEventArgs e) => await ExtractAsync(SelectedEntries());

    private async void ExtractAll_Click(object sender, RoutedEventArgs e) => await ExtractAsync(_all);

    private async Task ExtractAsync(List<PakEntry> items)
    {
        if (_pak == null || items.Count == 0) { Status("Нечего извлекать"); return; }

        string? outRoot;
        try { outRoot = Win32Dialogs.PickFolder(App.Hwnd, "Куда извлечь файлы"); }
        catch (Exception ex) { Status("Не удалось открыть диалог папки: " + ex.Message); return; }
        if (outRoot == null) return;
        var pak = _pak;

        Progress.Visibility = Visibility.Visible;
        Progress.Value = 0;
        OpenButton.IsEnabled = false;

        int ok = 0, skipped = 0, failed = 0;
        try
        {
            await Task.Run(() =>
            {
                for (int i = 0; i < items.Count; i++)
                {
                    var entry = items[i];
                    try
                    {
                        if (!entry.CanExtract) { skipped++; continue; }
                        var data = pak.Extract(entry);
                        var rel = SanitizeRelPath(entry.Path);
                        var dest = Path.Combine(outRoot, rel);
                        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                        File.WriteAllBytes(dest, data);
                        ok++;
                    }
                    catch { failed++; }

                    if ((i & 7) == 0)
                    {
                        int pct = (int)((i + 1) * 100.0 / items.Count);
                        DispatcherQueue.TryEnqueue(() =>
                        {
                            Progress.Value = pct;
                            Status($"Извлечение… {i + 1}/{items.Count}");
                        });
                    }
                }
            });
            Status($"Готово: извлечено {ok}, пропущено (Oodle/Zstd) {skipped}, ошибок {failed}. Папка: {outRoot}");
        }
        catch (Exception ex)
        {
            Status("Ошибка извлечения: " + ex.Message);
        }
        finally
        {
            Progress.Visibility = Visibility.Collapsed;
            OpenButton.IsEnabled = true;
        }
    }

    private static string SanitizeRelPath(string path)
    {
        var p = path.Replace('/', Path.DirectorySeparatorChar).TrimStart(Path.DirectorySeparatorChar);
        foreach (var c in Path.GetInvalidFileNameChars())
            if (c != Path.DirectorySeparatorChar) p = p.Replace(c, '_');

        p = p.Replace(".." + Path.DirectorySeparatorChar, "");
        return p.Length == 0 ? "file.bin" : p;
    }
}

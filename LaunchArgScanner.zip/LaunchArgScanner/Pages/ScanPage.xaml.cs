using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LaunchArgScanner.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;

namespace LaunchArgScanner.Pages;

public sealed partial class ScanPage : Page
{
    private List<ArgCandidate> _all = new();
    private List<ArgCandidate> _visible = new();
    private ScanResult? _last;
    private CancellationTokenSource? _cts;

    public ScanPage()
    {
        InitializeComponent();

        StatusText.RegisterPropertyChangedCallback(TextBlock.TextProperty,
            (s, dp) => App.StatusSink?.Invoke(StatusText.Text));
    }

    private void BrowseFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var folder = Win32Dialogs.PickFolder(App.Hwnd, "Выбери папку игры");
            if (folder != null) PathBox.Text = folder;
        }
        catch (Exception ex) { StatusText.Text = "Не удалось открыть диалог папки: " + ex.Message; }
    }

    private void BrowseExe_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var path = Win32Dialogs.OpenFile(App.Hwnd, "Программы (*.exe)", "*.exe");
            if (path != null) PathBox.Text = path;
        }
        catch (Exception ex) { StatusText.Text = "Не удалось открыть диалог выбора exe: " + ex.Message; }
    }

    private async void PathBox_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == Windows.System.VirtualKey.Enter && _cts == null)
        {
            e.Handled = true;
            await StartScanAsync();
        }
    }

    private void Page_DragOver(object sender, DragEventArgs e)
    {
        if (e.DataView.Contains(StandardDataFormats.StorageItems))
        {
            e.AcceptedOperation = DataPackageOperation.Link;
            e.DragUIOverride.Caption = "Сканировать";
        }
    }

    private async void Page_Drop(object sender, DragEventArgs e)
    {
        if (!e.DataView.Contains(StandardDataFormats.StorageItems) || _cts != null) return;
        var items = await e.DataView.GetStorageItemsAsync();
        var item = items.FirstOrDefault();
        if (item == null) return;
        PathBox.Text = item.Path;
    }

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (_cts != null)
        {
            _cts.Cancel();
            return;
        }
        await StartScanAsync();
    }

    private async Task StartScanAsync()
    {
        if (_cts != null) return;

        var path = PathBox.Text.Trim().Trim('"');
        if (path.Length == 0 || (!Directory.Exists(path) && !File.Exists(path)))
        {
            StatusText.Text = "Путь не найден. Укажи папку игры или её .exe.";
            return;
        }

        var opt = new ScanOptions
        {
            SkipThirdParty = SkipThirdPartyBox.IsChecked == true,
            IncludeHelpText = HelpTextBox.IsChecked == true,
            IncludeValueKeys = ValueKeysBox.IsChecked == true,
            IncludeCVars = CVarsBox.IsChecked == true,
            AnalyzeCode = AnalyzeCodeBox.IsChecked == true
        };

        _cts = new CancellationTokenSource();
        SetBusy(true);
        StatusText.Text = "Собираю список файлов…";

        var progress = new Progress<ScanProgress>(p =>
        {
            ScanProgressBar.Value = p.Percent;
            StatusText.Text = $"[{p.Current}/{p.Total}] {p.FileName}";
        });

        var token = _cts.Token;
        try
        {
            var result = await Task.Run(() => ArgScanner.Scan(path, opt, progress, token), token);
            _last = result;
            _all = result.Candidates;
            ShowSummary(result);
            ApplyFilter();

            var tail = result.CodeAnalysisRan
                ? $" · проверено кодом: {result.VerifiedByCode}"
                : result.CodeAnalysisNote != null ? $" · анализ кода: {result.CodeAnalysisNote}" : "";
            var steam = result.SteamAppId != null ? $" · Steam: {result.SteamGameName} (AppID {result.SteamAppId})" : "";
            StatusText.Text = $"Готово за {result.Elapsed.TotalSeconds:0.0} с{tail}{steam}" +
                              (result.SkippedFiles.Count > 0 ? $" · пропущено: {result.SkippedFiles.Count}" : "");
        }
        catch (OperationCanceledException)
        {
            StatusText.Text = "Сканирование отменено";
        }
        catch (Exception ex)
        {
            StatusText.Text = "Ошибка: " + ex.Message;
        }
        finally
        {
            _cts.Dispose();
            _cts = null;
            SetBusy(false);
            ApplyFilter();
        }
    }

    private void SetBusy(bool busy)
    {
        ProgressPanel.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        ScanProgressBar.Value = 0;
        ScanText.Text = busy ? "Отмена" : "Сканировать";
        ScanIcon.Glyph = busy ? "" : "";
        PathBox.IsEnabled = !busy;
        if (busy)
        {
            EmptyText.Text = "Сканирую…";
            EmptyPanel.Visibility = Visibility.Visible;
            ResultsList.ItemsSource = null;
        }
    }

    private void ShowSummary(ScanResult r)
    {
        EngineText.Text = r.Engine.DisplayName;
        ToolTipService.SetToolTip(EngineText, r.Engine.Evidence.Count > 0 ? "Признаки: " + string.Join(", ", r.Engine.Evidence) : null);

        ExeText.Text = r.MainExe != null ? Path.GetRelativePath(r.Root, r.MainExe) : "не найден";
        ToolTipService.SetToolTip(ExeText, r.MainExe);
        RunButton.IsEnabled = r.MainExe != null;
        RunLogButton.IsEnabled = r.MainExe != null;

        SteamButton.IsEnabled = r.SteamAppId != null;
        ToolTipService.SetToolTip(SteamButton, r.SteamAppId != null
            ? $"Записать строку запуска в Steam для «{r.SteamGameName}» (AppID {r.SteamAppId})"
            : "Игра не найдена в Steam (не в папке steamapps\\common)");

        FilesText.Text = $"{r.FilesScanned} файлов · {FormatSize(r.BytesScanned)}";
        ToolTipService.SetToolTip(FilesText, r.SkippedFiles.Count > 0
            ? "Пропущены:\n" + string.Join("\n", r.SkippedFiles.Take(40)) + (r.SkippedFiles.Count > 40 ? "\n…" : "")
            : null);

        int exact = r.Candidates.Count(c => c.IsExact);
        int C(ArgCategory cat) => r.Candidates.Count(c => c.IsExact && c.Category == cat);
        int sw = r.Candidates.Count(c => c.VerifiedByCode && c.Category is ArgCategory.Known or ArgCategory.Prefixed or ArgCategory.ValueKey);
        FoundText.Text = $"✓{exact} точных";
        ToolTipService.SetToolTip(FoundText,
            $"Параметры запуска: {sw}\nCVar: {C(ArgCategory.CVar)}\nКоманды: {C(ArgCategory.ConsoleCommand)}\n" +
            $"Ключи конфигов: {C(ArgCategory.ConfigKey)}\nКарты: {C(ArgCategory.Map)}\nЯзыки: {C(ArgCategory.Culture)}\n" +
            $"Зависимости: {C(ArgCategory.Dependency)}" +
            (r.CodeAnalysisRan ? "" : "\n\n" + (r.CodeAnalysisNote ?? "Код не разобран")));
    }

    private static string FormatSize(long bytes)
    {
        string[] u = { "Б", "КБ", "МБ", "ГБ" };
        double v = bytes;
        int i = 0;
        while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
        return $"{v:0.#} {u[i]}";
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();

    private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilter();

    private void ApplyFilter()
    {

        if (ResultsList == null || CountText == null || SearchBox == null || CategoryBox == null || ConfidenceBox == null) return;

        IEnumerable<ArgCandidate> q = _all;

        var s = SearchBox.Text.Trim();
        if (s.Length > 0)
            q = q.Where(c => c.Arg.Contains(s, StringComparison.OrdinalIgnoreCase) || c.Description.Contains(s, StringComparison.OrdinalIgnoreCase));

        q = CategoryBox.SelectedIndex switch
        {
            1 => q.Where(c => c.Category is ArgCategory.Known or ArgCategory.Prefixed or ArgCategory.HelpText or ArgCategory.ValueKey),
            2 => q.Where(c => c.Category == ArgCategory.CVar),
            3 => q.Where(c => c.Category == ArgCategory.ConsoleCommand),
            4 => q.Where(c => c.Category == ArgCategory.ConfigKey),
            5 => q.Where(c => c.Category == ArgCategory.Map),
            6 => q.Where(c => c.Category == ArgCategory.Culture),
            7 => q.Where(c => c.Category == ArgCategory.Dependency),
            8 => q.Where(c => c.Category == ArgCategory.BuildInfo),
            9 => q.Where(c => c.Category == ArgCategory.Endpoint),
            10 => q.Where(c => c.Category == ArgCategory.Network),
            _ => q
        };

        if (ConfidenceBox.SelectedIndex == 4)
        {
            q = q.Where(c => c.IsExact);
        }
        else
        {
            var min = ConfidenceBox.SelectedIndex switch
            {
                0 => Confidence.NotFound,
                2 => Confidence.Medium,
                3 => Confidence.High,
                _ => Confidence.Low
            };
            q = q.Where(c => c.IsExact || c.SeenAtRuntime || c.Confidence >= min);
        }

        _visible = q.ToList();
        ResultsList.ItemsSource = _visible;
        CountText.Text = _all.Count == 0 ? "" : $"{_visible.Count} из {_all.Count}";

        if (EmptyPanel != null && _cts == null)
        {
            EmptyPanel.Visibility = _visible.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            if (_all.Count == 0)
                EmptyText.Text = "Здесь появятся найденные параметры";
            else if (ConfidenceBox.SelectedIndex == 4 && !_all.Any(c => c.IsExact))
                EmptyText.Text = _last?.CodeAnalysisNote
                    ?? "Точных параметров из кода не найдено. Переключи фильтр, чтобы увидеть эвристические догадки.";
            else
                EmptyText.Text = "Ничего не подходит под фильтр";
        }
    }

    private IEnumerable<ArgCandidate> SelectedOrVisible()
    {
        var sel = ResultsList.SelectedItems.OfType<ArgCandidate>().ToList();
        return sel.Count > 0 ? sel : _visible;
    }

    private void CopySelected_Click(object sender, RoutedEventArgs e)
    {
        var items = SelectedOrVisible().ToList();
        if (items.Count == 0) return;
        CopyText(string.Join(Environment.NewLine, items.Select(i => i.ArgWithHint)));
        StatusText.Text = $"Скопировано параметров: {items.Count}";
    }

    private async void Export_Click(object sender, RoutedEventArgs e)
    {
        if (_visible.Count == 0)
        {
            StatusText.Text = "Нечего экспортировать — сначала просканируй игру";
            return;
        }
        var kind = (sender as MenuFlyoutItem)?.Tag as string ?? "txt";
        var suggested = "launch-args" + (_last != null ? "-" + SafeName(Path.GetFileName(_last.Root)) : "");
        var (fname, fpat, fext) = kind switch
        {
            "csv" => ("CSV (*.csv)", "*.csv", "csv"),
            "json" => ("JSON (*.json)", "*.json", "json"),
            _ => ("Текст (*.txt)", "*.txt", "txt")
        };

        string? outPath;
        try { outPath = Win32Dialogs.SaveFile(App.Hwnd, fname, fpat, fext, suggested); }
        catch (Exception ex) { StatusText.Text = "Не удалось открыть диалог сохранения: " + ex.Message; return; }
        if (outPath == null) return;

        string content = kind switch
        {
            "csv" => Exporter.ToCsv(_visible),
            "json" => Exporter.ToJson(_visible, _last),
            _ => Exporter.ToText(_visible, _last)
        };
        try
        {
            await File.WriteAllTextAsync(outPath, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: kind == "csv"));
            StatusText.Text = $"Сохранено: {outPath}";
        }
        catch (Exception ex)
        {
            StatusText.Text = "Не удалось сохранить: " + ex.Message;
        }
    }

    private static string SafeName(string s)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
        return s;
    }

    private static void CopyText(string text)
    {
        var dp = new DataPackage();
        dp.SetText(text);
        Clipboard.SetContent(dp);
    }

    private void ResultsList_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        if ((e.OriginalSource as FrameworkElement)?.DataContext is ArgCandidate c)
            AppendArg(c);
    }

    private void AddSelected_Click(object sender, RoutedEventArgs e)
    {
        foreach (var c in ResultsList.SelectedItems.OfType<ArgCandidate>())
            AppendArg(c);
    }

    private void AppendArg(ArgCandidate c)
    {
        switch (c.Category)
        {
            case ArgCategory.CVar:
                AppendCVar(c.Arg);
                StatusText.Text = $"{c.Arg} добавлен в -dpcvars= — впиши значение вместо <значение>";
                return;
            case ArgCategory.ConsoleCommand:
                AppendExecCmd(c.Arg);
                StatusText.Text = $"{c.Arg} добавлен в -ExecCmds= (выполнится при старте)";
                return;
            case ArgCategory.Map:
                AppendToken("-map=" + c.Arg);
                return;
            case ArgCategory.Culture:
                AppendToken("-culture=" + c.Arg);
                return;
            case ArgCategory.ConfigKey:
                StatusText.Text = $"{c.Arg}: переопределяется через -ini: (см. описание), не как обычный флаг";
                return;
            case ArgCategory.Dependency:
            case ArgCategory.BuildInfo:
                StatusText.Text = c.Description;
                return;
        }

        AppendToken(c.Arg);
        if (c.ValueHint != null)
            StatusText.Text = $"{c.Arg} требует значение: {c.ValueHint}";
    }

    private void AppendToken(string token)
    {
        var current = LaunchBox.Text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (current.Any(t => t.Equals(token, StringComparison.OrdinalIgnoreCase))) return;
        LaunchBox.Text = (LaunchBox.Text.TrimEnd() + " " + token).Trim();
    }

    private void AppendExecCmd(string cmd)
    {
        var text = LaunchBox.Text;
        int i = text.IndexOf("-ExecCmds=", StringComparison.OrdinalIgnoreCase);
        if (i >= 0)
        {

            int q = text.IndexOf('"', i);
            int q2 = q >= 0 ? text.IndexOf('"', q + 1) : -1;
            if (q >= 0 && q2 > q)
            {
                if (text[(q + 1)..q2].Contains(cmd, StringComparison.OrdinalIgnoreCase)) return;
                LaunchBox.Text = text[..q2] + ", " + cmd + text[q2..];
                return;
            }
        }
        LaunchBox.Text = (text.TrimEnd() + $" -ExecCmds=\"{cmd}\"").Trim();
    }

    private void AppendCVar(string name)
    {
        var token = $"{name}=<значение>";
        var text = LaunchBox.Text;
        int i = text.IndexOf("-dpcvars=", StringComparison.OrdinalIgnoreCase);
        if (i >= 0)
        {

            int end = text.IndexOf(' ', i);
            if (end < 0) end = text.Length;
            var seg = text[i..end];
            if (seg.Contains(name + "=", StringComparison.OrdinalIgnoreCase)) return;
            LaunchBox.Text = text[..end] + "," + token + text[end..];
        }
        else
        {
            LaunchBox.Text = (text.TrimEnd() + " -dpcvars=" + token).Trim();
        }
    }

    private void ClearLine_Click(object sender, RoutedEventArgs e) => LaunchBox.Text = "";

    private void CopyLine_Click(object sender, RoutedEventArgs e)
    {
        if (LaunchBox.Text.Length == 0) return;
        CopyText(LaunchBox.Text);
        StatusText.Text = "Строка запуска скопирована";
    }

    private void Run_Click(object sender, RoutedEventArgs e)
    {
        if (_last?.MainExe is not { } exe) return;
        try
        {
            Process.Start(new ProcessStartInfo(exe, LaunchBox.Text)
            {
                WorkingDirectory = Path.GetDirectoryName(exe)!,
                UseShellExecute = true
            });
            StatusText.Text = $"Запущено: {Path.GetFileName(exe)} {LaunchBox.Text}";
        }
        catch (Exception ex)
        {
            StatusText.Text = "Не удалось запустить: " + ex.Message;
        }
    }

    private async void RunAndLog_Click(object sender, RoutedEventArgs e)
    {
        if (_last?.MainExe is not { } exe) return;

        if (await ConfirmRuntimeAsync() != ContentDialogResult.Primary) return;

        RunLogButton.IsEnabled = false;
        try
        {
            var at = DateTime.Now;
            RuntimeCapture.Launch(exe, LaunchBox.Text, _last.Engine.Family, out var eff);
            StatusText.Text = $"Запущено: {Path.GetFileName(exe)} {eff}. Жду лог движка…";

            var res = await RuntimeCapture.ReadLogAsync(_last.Root, exe, _last.Engine.Family, at, CancellationToken.None);

            if (res.Tokens.Count > 0)
            {
                MergeRuntime(res.Tokens);
                ApplyFilter();
            }
            await ShowLogDialogAsync(res);
            StatusText.Text = res.LogPath != null
                ? $"Лог прочитан: {res.LogPath}"
                : res.Note ?? "Лог не найден";
        }
        catch (Exception ex)
        {
            StatusText.Text = "Запуск/чтение лога не удалось: " + ex.Message;
        }
        finally
        {
            RunLogButton.IsEnabled = _last?.MainExe != null;
        }
    }

    private void MergeRuntime(List<string> tokens)
    {
        var set = new HashSet<string>(tokens, StringComparer.OrdinalIgnoreCase);
        var byArg = new Dictionary<string, ArgCandidate>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in _all) byArg[c.Arg] = c;

        foreach (var t in tokens)
        {
            if (byArg.TryGetValue(t, out var c))
                c.SeenAtRuntime = true;
            else
            {
                var nc = new ArgCandidate
                {
                    Arg = t,
                    Category = ArgCategory.Prefixed,
                    Confidence = Confidence.High,
                    SeenAtRuntime = true,
                    Description = "Замечен в командной строке, которую движок записал в лог при запуске"
                };
                _all.Add(nc);
                byArg[t] = nc;
            }
        }
        _ = set;
        _all = _all.OrderByDescending(c => c.Rank).ThenBy(c => c.Category).ThenBy(c => c.Arg, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private async Task<ContentDialogResult> ConfirmRuntimeAsync()
    {
        var dlg = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "Запустить игру и прочитать лог?",
            Content = "Игра запустится с текущей строкой запуска. Приложение затем прочитает лог, который движок пишет сам, " +
                      "и отметит параметры, которые движок зарегистрировал.\n\n" +
                      "В процесс игры ничего не внедряется. Но для онлайн-игр с античитом (EAC, BattlEye, VAC) запускать " +
                      "с нестандартными параметрами стоит на свой риск. Для офлайн-игр и своих проектов ограничений нет.",
            PrimaryButtonText = "Запустить",
            CloseButtonText = "Отмена",
            DefaultButton = ContentDialogButton.Close
        };
        return await dlg.ShowAsync();
    }

    private async void AesKey_Click(object sender, RoutedEventArgs e)
    {

        var path = PathBox.Text.Trim().Trim('"');
        if (path.Length == 0) path = _last?.Root ?? "";
        if (path.Length == 0 || (!File.Exists(path) && !Directory.Exists(path)))
        {
            StatusText.Text = "Укажи exe или папку игры (кнопкой «Exe»/«Папка» или вписав путь)";
            return;
        }

        AesButton.IsEnabled = false;
        try
        {
            StatusText.Text = "Ищу AES-ключ в коде…";
            var (paths, root) = await Task.Run(() => CollectBinaryPaths(path));
            if (paths.Count == 0)
            {
                StatusText.Text = "Не нашёл exe/dll для поиска ключа по этому пути";
                return;
            }

            string? pak = await Task.Run(() => FindEncryptedPak(root));

            var progress = new Progress<string>(m => StatusText.Text = m);
            var res = await Task.Run(() => AesKeyFinder.Find(paths, pak,
                p => ((IProgress<string>)progress).Report(p), CancellationToken.None));
            _aes = res;
            ShowAesResult(res);
            StatusText.Text = res.Found
                ? (res.ProvenByPak ? "AES-ключ найден и проверен на pak" : "AES-ключ найден (по сигнатуре кода)")
                : (res.Note ?? "Ключ не найден");
            if (!res.Found) await ShowAesDialogAsync(res);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Поиск ключа не удался: " + ex.Message;
        }
        finally
        {
            AesButton.IsEnabled = true;
        }
    }

    private static (List<string> paths, string root) CollectBinaryPaths(string input)
    {
        var paths = new List<string>();
        string root;
        string? exe = null;

        if (File.Exists(input) && input.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
        {
            exe = Path.GetFullPath(input);
            root = EngineDetector.NormalizeRoot(exe);
        }
        else
        {
            root = EngineDetector.NormalizeRoot(input);
        }

        var dirs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (exe != null) dirs.Add(Path.GetDirectoryName(exe)!);
        try
        {
            foreach (var f in Directory.EnumerateFiles(root, "*.exe", SearchOption.AllDirectories))
            {
                dirs.Add(Path.GetDirectoryName(f)!);
                if (dirs.Count > 8) break;
            }
        }
        catch { }

        if (exe != null) paths.Add(exe);
        foreach (var d in dirs)
        {
            try
            {
                foreach (var f in Directory.EnumerateFiles(d, "*.exe"))
                    if (!paths.Contains(f, StringComparer.OrdinalIgnoreCase)) paths.Add(f);
                foreach (var f in Directory.EnumerateFiles(d, "*.dll"))
                    if (!paths.Contains(f, StringComparer.OrdinalIgnoreCase)) paths.Add(f);
            }
            catch { }
        }
        return (paths.Take(40).ToList(), root);
    }

    private async void AesVerify_Click(object sender, RoutedEventArgs e)
    {
        var root = _last?.Root;
        if (string.IsNullOrEmpty(root) || !Directory.Exists(root))
        {
            StatusText.Text = "Сначала просканируй игру";
            return;
        }

        var input = new TextBox
        {
            PlaceholderText = "0x…64 hex… или base64",
            AcceptsReturn = false,
            MinWidth = 560,
            FontFamily = (Microsoft.UI.Xaml.Media.FontFamily)Application.Current.Resources["MonoFont"]
        };
        var ask = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "Проверить AES-ключ на pak",
            Content = new StackPanel
            {
                Spacing = 8,
                Children =
                {
                    new TextBlock { Text = "Вставь ключ, который нашёл другой программой:", TextWrapping = TextWrapping.Wrap },
                    input
                }
            },
            PrimaryButtonText = "Проверить",
            CloseButtonText = "Отмена",
            DefaultButton = ContentDialogButton.Primary
        };
        if (await ask.ShowAsync() != ContentDialogResult.Primary) return;

        var keyText = input.Text;
        try
        {
            var pak = await Task.Run(() => FindEncryptedPak(root) ?? FindAnyPak(root));
            if (pak == null) { StatusText.Text = "Не найден ни один .pak в папке игры"; return; }

            var msg = await Task.Run(() => AesKeyFinder.Verify(keyText, pak));
            var res = new ContentDialog
            {
                XamlRoot = XamlRoot,
                Title = "Результат проверки",
                Content = new TextBlock { Text = $"Pak: {Path.GetFileName(pak)}\n\n{msg}", TextWrapping = TextWrapping.Wrap },
                CloseButtonText = "Закрыть"
            };
            await res.ShowAsync();
            StatusText.Text = "Проверка ключа завершена";
        }
        catch (Exception ex) { StatusText.Text = "Проверка не удалась: " + ex.Message; }
    }

    private AesKeyFinder.Result? _aes;

    private void ShowAesResult(AesKeyFinder.Result res)
    {
        if (!res.Found)
        {
            AesResultPanel.Visibility = Visibility.Collapsed;
            return;
        }
        AesHexBox.Text = res.Hex ?? "";
        AesB64Box.Text = res.Base64 ?? "";
        App.LastAesKeyHex = res.Hex;
        AesStatusLabel.Text = res.ProvenByPak
            ? "✓ Проверен на pak — ключ точно подходит. Выдели или нажми копировать."
            : $"Самый вероятный по энтропии (pak для доказательства не использован). Кандидатов: {res.Candidates.Count}.";
        AesMoreButton.Visibility = res.Candidates.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
        AesResultPanel.Visibility = Visibility.Visible;
    }

    private void CopyAesHex_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(AesHexBox.Text)) return;
        CopyText(AesHexBox.Text);
        StatusText.Text = "HEX-ключ скопирован";
    }

    private void CopyAesB64_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(AesB64Box.Text)) return;
        CopyText(AesB64Box.Text);
        StatusText.Text = "Base64-ключ скопирован";
    }

    private void AesCollapse_Click(object sender, RoutedEventArgs e)
    {
        AesResultPanel.Visibility = Visibility.Collapsed;
    }

    private async void AesMore_Click(object sender, RoutedEventArgs e)
    {
        if (_aes != null) await ShowAesDialogAsync(_aes);
    }

    private string? ResolveRoot()
    {
        var path = PathBox.Text.Trim().Trim('"');
        if (path.Length == 0) return _last?.Root;
        if (File.Exists(path) && path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            return EngineDetector.NormalizeRoot(path);
        if (Directory.Exists(path)) return EngineDetector.NormalizeRoot(path);
        return _last?.Root;
    }

    private void OpenInUnpack_Click(object sender, RoutedEventArgs e)
    {

        var root = ResolveRoot();
        if (root != null)
        {
            var pak = FindEncryptedPak(root) ?? FindAnyPak(root);
            if (pak != null) App.PendingPakPath = pak;
        }
        App.MainWindow?.NavigateTo("unpack");
    }

    private static string? FindAnyPak(string root)
    {
        try
        {
            return Directory.EnumerateFiles(root, "*.pak", new EnumerationOptions
            {
                RecurseSubdirectories = true,
                IgnoreInaccessible = true
            }).FirstOrDefault();
        }
        catch { return null; }
    }

    private static string? FindEncryptedPak(string root)
    {
        IEnumerable<string> paks;
        try
        {
            paks = Directory.EnumerateFiles(root, "*.pak", new EnumerationOptions
            {
                RecurseSubdirectories = true,
                IgnoreInaccessible = true
            });
        }
        catch { return null; }

        foreach (var p in paks)
        {
            try { if (AesKeyFinder.IsPakEncrypted(p)) return p; } catch { }
        }
        return null;
    }

    private async Task ShowAesDialogAsync(AesKeyFinder.Result res)
    {
        var sb = new StringBuilder();
        if (res.Found)
        {
            sb.AppendLine(res.ProvenByPak
                ? "Ключ найден и ПРОВЕРЕН на pak — он точно расшифровывает паки."
                : "Ключ найден по сигнатуре кода. Это самый вероятный (по энтропии); pak для доказательства " +
                  (res.PakFile == null ? "не найден." : "не подошёл или индекс не зашифрован.")).AppendLine();
            sb.AppendLine("HEX (для UnrealPak crypto.json / FModel):").AppendLine("  " + res.Hex).AppendLine();
            sb.AppendLine("Base64:").AppendLine("  " + res.Base64).AppendLine();

            if (res.Candidates.Count > 1)
            {
                sb.AppendLine().AppendLine($"Другие кандидаты ({res.Candidates.Count - 1}):");
                foreach (var c in res.Candidates.Skip(1).Take(8))
                    sb.AppendLine($"  0x{c.Hex}  (энтропия {c.Entropy:0.00}{(c.PakProven ? ", проверен" : "")})");
            }
            if (res.Note != null) sb.AppendLine().AppendLine(res.Note);
        }
        else
        {
            sb.AppendLine(res.Note ?? "Ключ не найден.");
        }

        var box = new TextBox
        {
            Text = sb.ToString(),
            IsReadOnly = true,
            TextWrapping = TextWrapping.Wrap,
            AcceptsReturn = true,
            FontFamily = (Microsoft.UI.Xaml.Media.FontFamily)Application.Current.Resources["MonoFont"],
            FontSize = 12,
            MinWidth = 600,
            MaxHeight = 440
        };

        var dlg = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = res.Found ? "AES-ключ pak" : "AES-ключ не найден",
            Content = box,
            CloseButtonText = "Закрыть",
            PrimaryButtonText = res.Found ? "Копировать HEX" : null,
            SecondaryButtonText = res.Found ? "Копировать Base64" : null
        };
        var r = await dlg.ShowAsync();
        if (r == ContentDialogResult.Primary && res.Hex != null) CopyText(res.Hex);
        else if (r == ContentDialogResult.Secondary && res.Base64 != null) CopyText(res.Base64);
    }

    private async void SteamAdd_Click(object sender, RoutedEventArgs e)
    {
        if (_last?.SteamAppId is not { } appId) return;

        var line = LaunchBox.Text.Trim();
        if (line.Length == 0)
        {
            StatusText.Text = "Строка запуска пустая — сначала собери параметры";
            return;
        }

        string? current = null;
        try { current = SteamIntegration.ReadLaunchOptions(appId); } catch { }

        var running = SteamIntegration.IsSteamRunning();
        var body = new StringBuilder();
        body.AppendLine($"Игра: {_last.SteamGameName}  (AppID {appId})");
        body.AppendLine();
        body.AppendLine("Текущие параметры: " + (string.IsNullOrEmpty(current) ? "(пусто)" : current));
        body.AppendLine("Новые параметры:   " + line);
        body.AppendLine();
        body.AppendLine("Будет сделана резервная копия конфига (localconfig.vdf.las-backup).");
        if (running)
            body.AppendLine("\nSteam запущен. Его нужно закрыть, иначе он перезапишет изменения при выходе.");

        var dlg = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "Записать в параметры запуска Steam?",
            Content = body.ToString(),
            PrimaryButtonText = running ? "Закрыть Steam и записать" : "Записать",
            CloseButtonText = "Отмена",
            DefaultButton = ContentDialogButton.Close
        };
        if (await dlg.ShowAsync() != ContentDialogResult.Primary) return;

        SteamButton.IsEnabled = false;
        try
        {
            if (SteamIntegration.IsSteamRunning())
            {
                StatusText.Text = "Закрываю Steam…";
                SteamIntegration.RequestSteamShutdown();
                for (int i = 0; i < 20 && SteamIntegration.IsSteamRunning(); i++)
                    await Task.Delay(500);
                if (SteamIntegration.IsSteamRunning())
                {
                    StatusText.Text = "Steam всё ещё запущен — закрой его вручную и повтори";
                    return;
                }
            }

            var res = await Task.Run(() => SteamIntegration.WriteLaunchOptions(appId, line));
            if (res.Ok)
            {
                StatusText.Text = $"Записано в Steam (аккаунт {res.SteamUserId}). Резервная копия: {res.BackupPath}. " +
                                  "Открой Steam — параметры уже в свойствах игры.";
            }
            else
            {
                StatusText.Text = "Steam: " + res.Error;
            }
        }
        catch (Exception ex)
        {
            StatusText.Text = "Не удалось записать в Steam: " + ex.Message;
        }
        finally
        {
            SteamButton.IsEnabled = _last?.SteamAppId != null;
        }
    }

    private async Task ShowLogDialogAsync(RuntimeCapture.Result res)
    {
        var sb = new StringBuilder();
        if (res.CommandLine != null) sb.AppendLine("Командная строка из лога:\n  " + res.CommandLine).AppendLine();
        if (res.Tokens.Count > 0) sb.AppendLine("Параметры, замеченные движком:\n  " + string.Join("  ", res.Tokens)).AppendLine();
        if (res.UnknownOrErrors.Count > 0)
            sb.AppendLine("Неизвестные/ошибки:\n" + string.Join("\n", res.UnknownOrErrors.Select(x => "  " + x))).AppendLine();
        if (res.Note != null) sb.AppendLine(res.Note).AppendLine();
        if (res.Excerpt != null) sb.AppendLine("Начало лога:\n" + res.Excerpt);

        var box = new TextBox
        {
            Text = sb.ToString(),
            IsReadOnly = true,
            TextWrapping = TextWrapping.Wrap,
            AcceptsReturn = true,
            FontFamily = (Microsoft.UI.Xaml.Media.FontFamily)Application.Current.Resources["MonoFont"],
            FontSize = 12,
            MinWidth = 640,
            Height = 420
        };

        var dlg = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "Лог запуска",
            Content = new ScrollViewer { Content = box },
            CloseButtonText = "Закрыть",
            PrimaryButtonText = res.LogPath != null ? "Открыть файл лога" : null
        };
        var r = await dlg.ShowAsync();
        if (r == ContentDialogResult.Primary && res.LogPath != null)
        {
            try { Process.Start(new ProcessStartInfo(res.LogPath) { UseShellExecute = true }); } catch { }
        }
    }
}

using Microsoft.UI.Xaml.Controls;

namespace LaunchArgScanner.Pages;

public sealed partial class AboutPage : Page
{
    public AboutPage()
    {
        InitializeComponent();
    }
}

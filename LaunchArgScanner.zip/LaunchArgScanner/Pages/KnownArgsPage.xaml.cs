using System;
using System.Linq;
using LaunchArgScanner.Core;
using Microsoft.UI.Xaml.Controls;

namespace LaunchArgScanner.Pages;

public sealed partial class KnownArgsPage : Page
{
    private bool _ready;

    public KnownArgsPage()
    {
        InitializeComponent();
        foreach (var n in KnownArgs.EngineFilterNames) EngineBox.Items.Add(n);
        EngineBox.SelectedIndex = 0;
        _ready = true;
        Apply();
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => Apply();

    private void EngineBox_SelectionChanged(object sender, SelectionChangedEventArgs e) => Apply();

    private void Apply()
    {
        if (!_ready) return;
        var mask = KnownArgs.EngineFilterMask(EngineBox.SelectedIndex);
        var s = SearchBox.Text.Trim();
        var items = KnownArgs.All
            .Where(k => mask == EngineMask.All || (k.Engines & mask) != 0)
            .Where(k => s.Length == 0
                        || k.Name.Contains(s, StringComparison.OrdinalIgnoreCase)
                        || k.Description.Contains(s, StringComparison.OrdinalIgnoreCase))
            .ToList();
        ArgsList.ItemsSource = items;
        CountText.Text = $"{items.Count} параметров";
    }
}

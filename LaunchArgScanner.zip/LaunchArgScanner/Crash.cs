using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace LaunchArgScanner;

public static class Crash
{
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(nint hWnd, string text, string caption, uint type);

    private static bool _shown;

    public static string LogPath
    {
        get
        {
            try
            {
                var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LaunchArgScanner");
                Directory.CreateDirectory(dir);
                return Path.Combine(dir, "crash.log");
            }
            catch
            {
                return Path.Combine(AppContext.BaseDirectory, "crash.log");
            }
        }
    }

    public static void Trace(string step)
    {
        try
        {
            var line = $"[{DateTime.Now:HH:mm:ss.fff}] {step}{Environment.NewLine}";
            try { File.AppendAllText(Path.Combine(AppContext.BaseDirectory, "startup.log"), line); } catch { }
            try
            {
                var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LaunchArgScanner");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "startup.log"), line);
            }
            catch { }
        }
        catch { }
    }

    public static void Log(Exception? ex, string where)
    {
        try
        {
            var text = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {where}{Environment.NewLine}{ex}{Environment.NewLine}{Environment.NewLine}";
            File.AppendAllText(LogPath, text);
            try { File.AppendAllText(Path.Combine(AppContext.BaseDirectory, "crash.log"), text); } catch { }
        }
        catch {  }
    }

    public static void Report(Exception? ex, string where)
    {
        Log(ex, where);
        if (_shown) return;
        _shown = true;
        try
        {
            var stack = string.Join("\n", (ex?.ToString() ?? "").Split('\n').Take(8));
            var msg = $"{where}:\n\n{stack}\n\nПолный текст записан в:\n{LogPath}";
            MessageBoxW(App.Hwnd, msg, "Launch Args Scanner — ошибка", 0x10 );
        }
        catch { }
    }
}

using LaunchArgScanner.Core;
using Microsoft.UI;
using Microsoft.UI.Xaml.Media;

namespace LaunchArgScanner;

public static class Ui
{
    private static readonly SolidColorBrush VerifiedBrush = new(ColorHelper.FromArgb(0xFF, 0x16, 0x8F, 0x46));
    private static readonly SolidColorBrush RuntimeBrush = new(ColorHelper.FromArgb(0xFF, 0x0E, 0x8A, 0x9B));
    private static readonly SolidColorBrush HighBrush = new(ColorHelper.FromArgb(0xFF, 0x2F, 0x80, 0xED));
    private static readonly SolidColorBrush MediumBrush = new(ColorHelper.FromArgb(0xFF, 0x5A, 0x74, 0x9A));
    private static readonly SolidColorBrush LowBrush = new(ColorHelper.FromArgb(0xFF, 0xB2, 0x7A, 0x12));
    private static readonly SolidColorBrush NoneBrush = new(ColorHelper.FromArgb(0xFF, 0x5A, 0x5A, 0x5A));

    private static readonly SolidColorBrush FileBrush = new(ColorHelper.FromArgb(0xFF, 0x6B, 0x4F, 0xC9));

    public static Brush StatusBrush(bool verified, bool fromFiles, bool runtime, Confidence c)
    {
        if (verified) return VerifiedBrush;
        if (fromFiles) return FileBrush;
        if (runtime) return RuntimeBrush;
        return c switch
        {
            Confidence.High => HighBrush,
            Confidence.Medium => MediumBrush,
            Confidence.Low => LowBrush,
            _ => NoneBrush
        };
    }

    public static double StatusOpacity(bool verified, bool fromFiles, bool runtime, Confidence c)
        => !verified && !fromFiles && !runtime && c == Confidence.NotFound ? 0.55 : 1.0;
}

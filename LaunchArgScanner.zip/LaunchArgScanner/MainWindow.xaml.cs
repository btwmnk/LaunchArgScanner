using System;
using LaunchArgScanner.Pages;
using Microsoft.UI;
using Microsoft.UI.Composition.SystemBackdrops;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;

namespace LaunchArgScanner;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        Crash.Trace("MainWindow ctor start");
        InitializeComponent();
        Crash.Trace("MainWindow InitializeComponent after");
        ApplyBackdrop();
        Crash.Trace("MainWindow backdrop after");

        try
        {
            ExtendsContentIntoTitleBar = true;
            SetTitleBar(AppTitleBar);
            AppWindow.Resize(new Windows.Graphics.SizeInt32(1320, 860));
        }
        catch (Exception ex)
        {
            Crash.Log(ex, "Настройка заголовка окна");
        }

        App.StatusSink = t =>
        {
            try { WindowStatus.Text = string.IsNullOrEmpty(t) ? "Готов к работе" : t; } catch { }
        };

        ContentFrame.Navigated += (s, e) => DispatcherQueue.TryEnqueue(() => Loc.Apply(ContentFrame));

        LangBox.SelectedIndex = 0;
        _ready = true;

        try { Nav.SelectedItem = Nav.MenuItems[0]; }
        catch (Exception ex) { Crash.Log(ex, "Выбор первой вкладки"); }
        Crash.Trace("MainWindow ctor end");
    }

    private bool _ready;

    private void Lang_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready || Loc.IsApplying) return;
        Loc.Current = LangBox.SelectedIndex == 1 ? Lang.En : Lang.Ru;
        try { Loc.Apply(RootGrid); } catch { }
        if (App.StatusSink != null) WindowStatus.Text = Loc.Tr("Готов к работе");
    }

    private void ApplyBackdrop()
    {
        try
        {
            if (MicaController.IsSupported())
            {
                SystemBackdrop = new MicaBackdrop();
                return;
            }
            if (DesktopAcrylicController.IsSupported())
            {
                SystemBackdrop = new DesktopAcrylicBackdrop();
                return;
            }
        }
        catch (Exception ex)
        {
            Crash.Log(ex, "Backdrop");
        }
        RootGrid.Background =
            Application.Current.Resources.TryGetValue("ApplicationPageBackgroundThemeBrush", out var b) && b is Brush brush
                ? brush
                : new SolidColorBrush(ColorHelper.FromArgb(0xFF, 0x20, 0x20, 0x20));
    }

    public void NavigateTo(string tag)
    {
        foreach (var item in Nav.MenuItems)
            if (item is NavigationViewItem nvi && (nvi.Tag as string) == tag)
            {
                Nav.SelectedItem = nvi;
                return;
            }
    }

    private void Nav_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        var tag = (args.SelectedItem as NavigationViewItem)?.Tag as string;
        Type page = tag switch
        {
            "unpack" => typeof(UnpackPage),
            "uasset" => typeof(UAssetPage),
            "db" => typeof(KnownArgsPage),
            "about" => typeof(AboutPage),
            _ => typeof(ScanPage)
        };
        if (ContentFrame.CurrentSourcePageType != page)
            ContentFrame.Navigate(page, null, new EntranceNavigationTransitionInfo());
    }
}

using System;
using System.Collections.Generic;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace LaunchArgScanner;

public enum Lang { Ru, En }

public static class Loc
{
    public static Lang Current = Lang.Ru;

    private static readonly Dictionary<string, string> Ru2En = Build();
    private static readonly Dictionary<string, string> En2Ru = Invert(Ru2En);

    private static Dictionary<string, string> Invert(Dictionary<string, string> d)
    {
        var r = new Dictionary<string, string>();
        foreach (var kv in d) r[kv.Value] = kv.Key;
        return r;
    }

    public static string Tr(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;
        if (Current == Lang.En) return Ru2En.TryGetValue(s, out var e) ? e : s;
        return En2Ru.TryGetValue(s, out var r) ? r : s;
    }

    public static bool IsApplying { get; private set; }

    public static void Apply(DependencyObject? root)
    {
        if (IsApplying) return;
        IsApplying = true;
        try { Walk(root); }
        finally { IsApplying = false; }
    }

    private static void Walk(DependencyObject? root)
    {
        if (root == null) return;
        try { TranslateOne(root); } catch { }
        int n = VisualTreeHelper.GetChildrenCount(root);
        for (int i = 0; i < n; i++) Walk(VisualTreeHelper.GetChild(root, i));
    }

    private static void TranslateOne(DependencyObject d)
    {
        switch (d)
        {
            case TextBox tx:
                tx.PlaceholderText = Tr(tx.PlaceholderText);
                break;
            case TextBlock tb:
                tb.Text = Tr(tb.Text);
                break;
            case ComboBox cb:
                int sel = cb.SelectedIndex;
                bool changed = false;
                for (int i = 0; i < cb.Items.Count; i++)
                    if (cb.Items[i] is string s)
                    {
                        var t = Tr(s);
                        if (!ReferenceEquals(t, s) && t != s) { cb.Items[i] = t; changed = true; }
                    }
                if (changed) cb.SelectedIndex = sel;
                break;
            case ContentControl cc when cc.Content is string cs:
                cc.Content = Tr(cs);
                break;
        }
        if (d is UIElement ue)
        {
            var tt = ToolTipService.GetToolTip(ue);
            if (tt is string ts) ToolTipService.SetToolTip(ue, Tr(ts));
        }
    }

    private static Dictionary<string, string> Build()
    {
        var p = new (string ru, string en)[]
        {
            ("Сканер", "Scanner"),
            ("Распаковка pak", "Pak unpacker"),
            ("База параметров", "Parameters database"),
            ("Как это работает", "How it works"),
            ("Готов к работе", "Ready"),
            ("Готов к сканированию", "Ready to scan"),

            ("Сканер параметров запуска", "Launch parameters scanner"),
            ("Выбери папку игры или её .exe (или перетащи сюда) — приложение найдёт параметры, которые проверяет игра.",
             "Pick the game folder or its .exe (or drag it here) — the app finds the parameters the game checks."),
            ("Папка", "Folder"),
            ("Выбрать папку игры", "Pick game folder"),
            ("Выбрать .exe игры", "Pick game .exe"),
            ("Сканировать", "Scan"),
            ("Анализ кода (точно)", "Code analysis (exact)"),
            ("Дизассемблирует exe/dll и помечает параметры, которые игра реально проверяет в коде (а не просто похожие строки). Чуть медленнее.",
             "Disassembles exe/dll and marks the parameters the game actually checks in code (not just similar strings). A bit slower."),
            ("Пропускать сторонние DLL", "Skip third-party DLLs"),
            ("CEF/Chromium, PhysX, рантаймы, античиты и т.п. — в них много чужих флагов",
             "CEF/Chromium, PhysX, runtimes, anti-cheats, etc. — they contain many unrelated flags"),
            ("Строки справки (usage)", "Help (usage) strings"),
            ("Unreal: параметры Name=", "Unreal: Name= parameters"),
            ("Строки вида ResX= — так Unreal читает значения через FParse::Value",
             "Strings like ResX= — how Unreal reads values via FParse::Value"),
            ("Unreal: консольные переменные (CVar)", "Unreal: console variables (CVar)"),
            ("r.*, t.*, sg.* … — их тысячи; задаются через -dpcvars= или -ExecCmds=",
             "r.*, t.*, sg.* … — thousands of them; set via -dpcvars= or -ExecCmds="),

            ("Движок", "Engine"),
            ("Главный exe", "Main exe"),
            ("Просканировано", "Scanned"),
            ("Точно из кода", "Exact from code"),

            ("Поиск по параметру или описанию", "Search by parameter or description"),
            ("Все категории", "All categories"),
            ("Параметры запуска", "Launch parameters"),
            ("Консольные команды", "Console commands"),
            ("Ключи конфигов", "Config keys"),
            ("Карты / уровни", "Maps / levels"),
            ("Языки", "Languages"),
            ("Зависимости", "Dependencies"),
            ("Сборка", "Build"),
            ("Серверные адреса", "Server addresses"),
            ("Сетевой стек", "Network stack"),
            ("Включая не найденные", "Including not found"),
            ("Все найденные", "All found"),
            ("Средняя и выше", "Medium and up"),
            ("Только высокая", "High only"),
            ("Только точные: код + файлы ✓", "Exact only: code + files ✓"),
            ("Копировать выбранные (или все видимые)", "Copy selected (or all visible)"),
            ("Копировать", "Copy"),
            ("Экспорт", "Export"),
            ("Текст (.txt)", "Text (.txt)"),
            ("Таблица (.csv)", "Table (.csv)"),

            ("Параметр", "Parameter"),
            ("Уверенность", "Confidence"),
            ("Описание · файлы", "Description · files"),
            ("Здесь появятся найденные параметры", "Found parameters will appear here"),

            ("Строка запуска", "Launch string"),
            ("Двойной клик по параметру добавит его сюда. Затем вставь в Steam → Свойства → Параметры запуска",
             "Double-click a parameter to add it here. Then paste into Steam → Properties → Launch Options"),
            ("Добавить выбранные параметры", "Add selected parameters"),
            ("Очистить", "Clear"),
            ("Копировать строку", "Copy string"),
            ("Запустить", "Run"),
            ("Запустить главный exe с этой строкой", "Run the main exe with this string"),
            ("Запуск + лог", "Run + log"),
            ("Запустить игру и прочитать её лог — показать, какие параметры движок зарегистрировал. Только читает лог, в процесс игры не вмешивается.",
             "Launch the game and read its log — show which parameters the engine registered. Only reads the log, does not touch the game process."),
            ("В Steam", "To Steam"),
            ("Записать эту строку в параметры запуска игры в Steam (нужен закрытый Steam; делается резервная копия конфига).",
             "Write this string into the game's Steam launch options (Steam must be closed; the config is backed up)."),
            ("UE4/UE5 · ключ из кода. Распаковка — на вкладке «Распаковка pak».",
             "UE4/UE5 · key from code. Unpacking is on the «Pak unpacker» tab."),
            ("Найти AES-ключ pak", "Find pak AES key"),
            ("Найти AES-ключ шифрования pak и проверить его на настоящем .pak игры. Нужно для распаковки своих/возрождаемых игр.",
             "Find the pak AES encryption key and verify it against a real .pak. Needed for unpacking your own / revived games."),
            ("Проверить ключ", "Verify key"),
            ("Вставить уже известный ключ и проверить его на .pak — покажет, зашифрован ли индекс.",
             "Paste a known key and verify it against a .pak — shows whether the index is encrypted."),
            ("Свернуть", "Collapse"),
            ("Копировать HEX", "Copy HEX"),
            ("Копировать Base64", "Copy Base64"),
            ("Распаковать паки", "Unpack paks"),
            ("Открыть распаковку с этим ключом", "Open the unpacker with this key"),
            ("Другие кандидаты", "Other candidates"),

            ("Открой .pak и ходи по папкам. Двойной клик по папке — войти, по файлу — сохранить его отдельно. Ключ берётся из найденного на «Сканере».",
             "Open a .pak and browse folders. Double-click a folder to enter, a file to save it separately. The key comes from the one found on the «Scanner»."),
            ("Путь к .pak", "Path to .pak"),
            ("Выбрать .pak", "Pick .pak"),
            ("Открыть", "Open"),
            ("0x… (для зашифрованных паков)", "0x… (for encrypted paks)"),
            ("Вверх", "Up"),
            ("Поиск по всему паку", "Search the whole pak"),
            ("Извлечь выбранное (папку — целиком)", "Extract selected (folders fully)"),
            ("Извлечь выбранное", "Extract selected"),
            ("Извлечь всё", "Extract all"),
            ("Извлечь все файлы pak", "Extract all pak files"),
            ("Имя", "Name"),
            ("Размер", "Size"),
            ("Сжатие", "Compression"),
            ("Открой .pak, чтобы увидеть файлы", "Open a .pak to see files"),

            ("Известные параметры движков. Сканер сверяет с ними строки из бинарников и подставляет описания.",
             "Known engine parameters. The scanner matches binary strings against them and fills in descriptions."),
            ("Поиск", "Search"),

            ("Идея", "Idea"),
            ("Что делает сканер", "What the scanner does"),
            ("Ограничения", "Limitations"),
            ("Подсказки", "Hints"),
            ("Точно из кода — главный режим", "Exact from code — the main mode"),
            ("Флаг или параметр со значением", "Flag or value parameter"),
            ("Что ещё вытаскивается", "What else is extracted"),
            ("Сеть и доказательства", "Network and proof"),
            ("Запись в Steam", "Writing to Steam"),
            ("Запуск + лог — что движок принял на деле", "Run + log — what the engine actually accepted"),
            ("Поиск AES-ключа pak", "Pak AES key search"),

            ("Редактор uasset", "uasset editor"),
            ("Открой .uasset: выбери экспорт и меняй значения его свойств двойным кликом, правь имена. «Сохранить» пишет .uasset и .uexp вместе (через UAssetAPI). Для файлов без версии выбери версию движка.",
             "Open a .uasset: pick an export and edit its property values by double-click, edit names. «Save» writes the .uasset and .uexp together (via UAssetAPI). For unversioned files pick an engine version."),
            ("Путь к .uasset", "Path to .uasset"),
            ("Выбрать .uasset", "Pick .uasset"),
            ("Сохранить", "Save"),
            ("Сохранить как", "Save as"),
            ("Свойство : тип", "Property : type"),
            ("Значение", "Value"),
            ("Сводка", "Summary"),
            ("Поиск по имени", "Search by name"),
            ("Имена", "Names"),
            ("Импорты", "Imports"),
            ("Экспорты", "Exports"),
            ("Объект", "Object"),
            ("Класс", "Class"),

            ("Игра проверяет параметры, сравнивая командную строку с жёстко прописанными строками (в Unreal это FParse::Param / FParse::Value, в Unity — встроенные флаги плеера и Environment.GetCommandLineArgs). Эти строки лежат прямо в .exe и .dll — приложение их вытаскивает и классифицирует.",
             "The game checks parameters by comparing the command line against hard-coded strings (in Unreal that's FParse::Param / FParse::Value, in Unity the built-in player flags and Environment.GetCommandLineArgs). Those strings sit right inside the .exe and .dll — the app pulls them out and classifies them."),
            ("1. Определяет движок по файлам (UnityPlayer.dll, Content\\Paks, CookedPC, engine2.dll, *.pck…) и версию Unreal по строке ++UE5+Release-x.y.",
             "1. Detects the engine from files (UnityPlayer.dll, Content\\Paks, CookedPC, engine2.dll, *.pck…) and the Unreal version from the ++UE5+Release-x.y string."),
            ("2. Читает все .exe/.dll игры (и global-metadata.dat для Unity IL2CPP) и достаёт строки в ASCII и UTF-16 на любом выравнивании.",
             "2. Reads all of the game's .exe/.dll (and global-metadata.dat for Unity IL2CPP) and extracts ASCII and UTF-16 strings at any alignment."),
            ("3. Отбирает: известные параметры движка (в т.ч. «голые», без дефиса), строки-флаги -x / --x / +x, строки справки usage, Unreal-параметры Name= и, по желанию, CVar'ы.",
             "3. Selects: known engine parameters (including bare ones, without a dash), flag strings -x / --x / +x, usage help strings, Unreal Name= parameters and, optionally, CVars."),
            ("4. Ставит уверенность: высокая — точное совпадение с известным параметром; средняя — флаг в главном exe или движковом модуле; низкая — в прочих файлах или эвристика.",
             "4. Assigns confidence: high — an exact match with a known parameter; medium — a flag in the main exe or an engine module; low — in other files or heuristic."),
            ("По умолчанию приложение показывает только параметры, подтверждённые дизассемблером (зелёная метка «Проверено кодом»). Это не вероятность: дизассемблер нашёл место, где код игры сам сверяет командную строку с этой строкой. Эвристические догадки по умолчанию скрыты — их можно показать переключателем уверенности справа.",
             "By default the app shows only parameters confirmed by the disassembler (the green «Verified by code» tag). This is not a probability: the disassembler found the place where the game's code itself compares the command line against this string. Heuristic guesses are hidden by default — you can show them with the confidence toggle on the right."),
            ("Вытаскиваются две вещи. Параметры командной строки: строки, которые код передаёт в разборщик (в Unreal — FParse::Param для флагов и FParse::Value для параметров со значением; разборщик опознаётся по тому, что ему передают много известных флагов). И консольные переменные (CVar): движок регистрирует их как (имя, значение по умолчанию, справка, флаги) — приложение берёт имя И текст справки прямо из exe.",
             "Two things are extracted. Command-line parameters: strings the code passes to the parser (in Unreal — FParse::Param for flags and FParse::Value for value parameters; the parser is recognised by the fact that many known flags are passed to it). And console variables (CVars): the engine registers them as (name, default value, help, flags) — the app takes the name AND the help text straight from the exe."),
            ("Поэтому описание у CVar — настоящее, из самой игры, а не из интернета. У недокументированных параметров командной строки описания в бинарнике нет, и приложение честно пишет об этом, а не выдумывает.",
             "That's why a CVar's description is the real one, from the game itself, not from the internet. Undocumented command-line parameters have no description in the binary, and the app says so honestly instead of making one up."),
            ("Работает для нативных движков x64 (Unreal, Source, CryEngine). Unity на Mono хранит логику в управляемом Assembly-CSharp.dll — там нужен dnSpy. Упакованный exe (Denuvo, VMProtect) разобрать нельзя.",
             "Works for native x64 engines (Unreal, Source, CryEngine). Mono-based Unity keeps its logic in the managed Assembly-CSharp.dll — that needs dnSpy. A packed exe (Denuvo, VMProtect) cannot be disassembled."),
            ("Ключ pak зашит в exe не подряд, а россыпью в инструкциях «mov …, imm32» (опкод C7). Кнопка «Найти AES-ключ pak» ищет сигнатуры этих инструкций (метод AESDumpster), собирает ключ по таблице смещений и ранжирует кандидатов по энтропии — самый «случайный» вероятнее всего и есть ключ. Pak для этого не нужен.",
             "The pak key is not stored in the exe contiguously but scattered across «mov …, imm32» instructions (opcode C7). The «Find pak AES key» button searches for the signatures of these instructions (the AESDumpster method), reassembles the key from the offset table and ranks candidates by entropy — the most «random» one is most likely the key. No pak is needed for this."),
            ("Если рядом есть зашифрованный .pak, кандидат дополнительно проверяется расшифровкой его индекса — тогда ключ помечается «проверен на pak» (доказан, а не вероятен). Результат — в HEX (UnrealPak crypto.json) и base64 (FModel); показываются и запасные кандидаты.",
             "If an encrypted .pak is nearby, the candidate is additionally verified by decrypting its index — the key is then marked «verified against pak» (proven, not just likely). The result is shown in HEX (UnrealPak crypto.json) and base64 (FModel); fallback candidates are shown too."),
            ("Не сработает, если exe упакован (VMProtect/Themida/Denuvo), если нужна сигнатура под другой компилятор/версию UE, или если ключ приходит с сервера. Проверка по pak — формат v8–v11; IoStore (.utoc) пока не поддерживается.",
             "Won't work if the exe is packed (VMProtect/Themida/Denuvo), if a signature for a different compiler/UE version is needed, or if the key comes from a server. Pak verification covers format v8–v11; IoStore (.utoc) is not supported yet."),
            ("Серверные адреса (категория «Адрес»): URL, хосты и IP:порт из строк бинарника — видно, куда игра стучится. Полезно для перенаправления на приватный сервер при возрождении онлайн-игры.",
             "Server addresses (the «Address» category): URLs, hosts and IP:port from the binary's strings — you can see where the game reaches out. Useful for redirecting to a private server when reviving an online game."),
            ("Сетевой стек (категория «Сеть»): онлайн-подсистема (Steam/EOS/Null), сетевой драйвер, транспорт, шифрование и сжатие трафика, сокеты — из строк и таблицы импорта. Подсказывает, что эмулировать на сервере.",
             "Network stack (the «Network» category): online subsystem (Steam/EOS/Null), net driver, transport, traffic encryption and compression, sockets — from strings and the import table. Hints at what to emulate on the server."),
            ("Доказательство: у параметров, подтверждённых кодом, под описанием показывается адрес вызова и кусок дизассемблера (lea строки → call парсера). Наведи курсор — покажет полностью.",
             "Proof: for code-confirmed parameters, the call address and a disassembly snippet (lea of the string → call of the parser) are shown under the description. Hover to see it in full."),
            ("Кроме параметров запуска приложение собирает (всё — точные данные из кода или файлов игры, фильтр по категориям справа):",
             "Besides launch parameters the app collects (all of it exact data from the game's code or files, filter by category on the right):"),
            ("• Консольные переменные (CVar) и консольные команды — с настоящей справкой из exe.",
             "• Console variables (CVars) and console commands — with the real help text from the exe."),
            ("• Ключи конфигов — все [Секции] и ключи из ini, с текущим значением и готовой строкой -ini: для переопределения.",
             "• Config keys — all [Sections] and keys from the ini, with the current value and a ready -ini: string for overriding."),
            ("• Карты и уровни — из распакованных .umap (Unreal) и .bsp (Source), готовые для -map=.",
             "• Maps and levels — from unpacked .umap (Unreal) and .bsp (Source), ready for -map=."),
            ("• Языки сборки, зависимости и middleware (Steam, EOS, DLSS/FSR, PhysX, античит EAC/BattlEye) и сведения о сборке (разрядность, движок, дата).",
             "• Build languages, dependencies and middleware (Steam, EOS, DLSS/FSR, PhysX, EAC/BattlEye anti-cheat) and build info (bitness, engine, date)."),
            ("Содержимое pak/vpk-архивов не вскрывается — карты и конфиги видны только у распакованных игр.",
             "The contents of pak/vpk archives are not opened — maps and configs are only visible for unpacked games."),
            ("Анализ кода теперь различает два вида параметров. Флаг (FParse::Param) включается сам по себе: -nosound. Параметр со значением (FParse::Value) требует значение после знака =: -ResX=1920. В коде образец значения хранится со знаком = на конце, по этому и определяется вид. У параметров со значением в строке запуска подставляется =<значение>, которое нужно заполнить.",
             "Code analysis now distinguishes two kinds of parameters. A flag (FParse::Param) is turned on by itself: -nosound. A value parameter (FParse::Value) requires a value after the = sign: -ResX=1920. In the code the value sample is stored with a trailing = sign, which is how the kind is determined. For value parameters a =<value> placeholder is inserted into the launch string for you to fill in."),
            ("Если игра установлена через Steam, приложение определяет её AppID (по appmanifest рядом с папкой) и кнопкой «В Steam» записывает собранную строку прямо в параметры запуска игры — не нужно копировать вручную в свойства.",
             "If the game is installed through Steam, the app determines its AppID (from the appmanifest next to the folder) and the «To Steam» button writes the assembled string straight into the game's launch options — no need to copy it manually into properties."),
            ("Steam при этом должен быть закрыт, иначе он перезапишет изменения при выходе — приложение предложит закрыть его. Перед записью создаётся резервная копия конфига (localconfig.vdf.las-backup), а структура файла проверяется, чтобы ничего не потерять.",
             "Steam must be closed for this, otherwise it will overwrite the changes on exit — the app will offer to close it. Before writing, a backup of the config is made (localconfig.vdf.las-backup), and the file structure is validated so nothing is lost."),
            ("Кнопка «Запуск + лог» запускает игру с собранной строкой (для Unreal добавляет -log) и читает лог, который движок пишет сам. Из лога берётся командная строка, которую движок записал, и параметры в ней помечаются бирюзовым «Видно при запуске».",
             "The «Run + log» button launches the game with the assembled string (for Unreal it adds -log) and reads the log the engine writes itself. The command line the engine recorded is taken from the log, and the parameters in it are marked teal «Seen at launch»."),
            ("Это только чтение лог-файла — в процесс игры ничего не внедряется. Но запускать игру с нестандартными параметрами при активном античите (EAC, BattlEye, VAC) стоит на свой риск. Для офлайн-игр и своих проектов ограничений нет.",
             "This only reads the log file — nothing is injected into the game process. But launching a game with non-standard parameters while an anti-cheat is active (EAC, BattlEye, VAC) is at your own risk. For offline games and your own projects there are no limits."),
            ("• Гарантировать 100% полный список нельзя: часть параметров собирается динамически или читается из конфигов.",
             "• A 100% complete list cannot be guaranteed: some parameters are built dynamically or read from configs."),
            ("• Упакованные/защищённые exe (Themida, VMProtect, Denuvo) скрывают строки до запуска — найдено будет меньше.",
             "• Packed/protected exes (Themida, VMProtect, Denuvo) hide strings until launch — fewer will be found."),
            ("• Ложные срабатывания возможны — ориентируйся на уверенность и проверяй параметр запуском.",
             "• False positives are possible — rely on confidence and verify a parameter by running it."),
            ("• Сканер только читает файлы на диске и не трогает процесс игры — это безопасно для игр с античитом.",
             "• The scanner only reads files on disk and does not touch the game process — this is safe for games with anti-cheat."),
            ("• Unreal: любой CVar можно задать через -dpcvars=r.Foo=1 (UE5) или -ExecCmds=\"r.Foo 1\". Полный список CVar'ов даёт консольная команда DumpConsoleCommands.",
             "• Unreal: any CVar can be set via -dpcvars=r.Foo=1 (UE5) or -ExecCmds=\"r.Foo 1\". The full list of CVars is produced by the DumpConsoleCommands console command."),
            ("• Unity Mono: для поиска своих параметров игры открой Managed\\Assembly-CSharp.dll в dnSpy/ILSpy и найди GetCommandLineArgs.",
             "• Unity Mono: to find a game's own parameters open Managed\\Assembly-CSharp.dll in dnSpy/ILSpy and look for GetCommandLineArgs."),
            ("• Source: + перед именем — консольная переменная (+fps_max 144), - — флаг движка.",
             "• Source: a + before the name is a console variable (+fps_max 144), a - is an engine flag."),
        };
        var d = new Dictionary<string, string>();
        foreach (var (ru, en) in p) d[ru] = en;
        return d;
    }
}
